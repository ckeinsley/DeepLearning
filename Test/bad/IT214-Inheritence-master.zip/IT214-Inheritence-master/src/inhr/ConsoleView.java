package inhr;

public class ConsoleView {
	public void print(String aMessage) {
		System.out.println(aMessage);
	}
}