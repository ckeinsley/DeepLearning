
package chatty.util.settings;

/**
 *
 * @author tduva
 */
public interface SettingsListener {
    public void aboutToSaveSettings(Settings settings);
}
