
package chatty.util;

/**
 *
 * @author tduva
 */
public interface ActivityListener {
    public void activity();
}
