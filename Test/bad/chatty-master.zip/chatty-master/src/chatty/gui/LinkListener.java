
package chatty.gui;

/**
 *
 * @author tduva
 */
public interface LinkListener {
    public void linkClicked(String url);
}
