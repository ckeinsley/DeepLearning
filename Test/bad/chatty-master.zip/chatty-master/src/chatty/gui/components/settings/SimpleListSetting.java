
package chatty.gui.components.settings;

/**
 * 
 * 
 * @author tduva
 */
public class SimpleListSetting {
    
}
