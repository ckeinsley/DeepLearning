
package chatty.gui.components;

import chatty.util.api.StreamInfo;

/**
 *
 * @author tduva
 */
public interface LiveStreamListener {
    public void liveStreamClicked(StreamInfo stream);
}
