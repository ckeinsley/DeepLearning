
package chatty.gui.components.settings;

/**
 *
 * @author tduva
 */
public interface ColorSettingListener {
    public void colorUpdated();
}
