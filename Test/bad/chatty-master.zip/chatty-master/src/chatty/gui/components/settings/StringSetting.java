
package chatty.gui.components.settings;

/**
 *
 * @author tduva
 */
public interface StringSetting {
    public String getSettingValue();
    public void setSettingValue(String value);
}
