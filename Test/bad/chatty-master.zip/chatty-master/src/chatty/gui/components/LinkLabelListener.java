
package chatty.gui.components;

/**
 *
 * @author tduva
 */
public interface LinkLabelListener {
    public void linkClicked(String type, String ref);
}
