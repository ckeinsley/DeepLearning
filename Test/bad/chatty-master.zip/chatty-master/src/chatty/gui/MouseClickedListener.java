
package chatty.gui;

/**
 *
 * @author tduva
 */
public interface MouseClickedListener {
    public void mouseClicked();
}
