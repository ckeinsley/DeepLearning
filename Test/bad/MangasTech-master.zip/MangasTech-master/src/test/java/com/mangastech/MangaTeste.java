package com.mangastech;

public class MangaTeste {
	
	public static void main(String [] args) {
		
	}
}
