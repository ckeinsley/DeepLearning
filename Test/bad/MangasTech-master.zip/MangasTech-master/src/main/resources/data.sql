
INSERT INTO usuario(id,nome,password,username)
VALUES(1,'Braian','admin','admin');

INSERT INTO usuario_entity_roles(usuario_entity_id,roles)
VALUES(1,'ADMIN'),(1,'USER');

SELECT * FROM usuario;