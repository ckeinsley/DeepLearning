package com.mangastech.model;

/**
 * @author Braian
 *
 */
public enum AuthorityName {
	ADMIN,USER
}
