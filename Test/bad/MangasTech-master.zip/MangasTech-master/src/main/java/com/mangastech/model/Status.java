package com.mangastech.model;

/**
 * @author Braian
 *
 */
public enum Status {
	COMPLETO,
	LANCANDO,
	PAUSADO	
}
