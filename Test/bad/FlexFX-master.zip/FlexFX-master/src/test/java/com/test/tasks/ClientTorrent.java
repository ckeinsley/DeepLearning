/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.tasks;

import com.grupoad3.flexfx.clientbit.ClientBittorrent;
import com.grupoad3.flexfx.clientbit.Qbittorrent41;
import org.junit.Test;

/**
 *
 * @author daniel_serna
 */
public class ClientTorrent {
    
    @Test
    public void testTorrent(){
        ClientBittorrent cliente = new Qbittorrent41("URL");
        
        
    }
    
}
