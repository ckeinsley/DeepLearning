/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * HybridTrajectoryElement.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.trajectory;

import java.lang.reflect.Field;
import java.util.ArrayList;

import edu.ucsc.cross.jheq.object.DataStructure;

/**
 * /** The hybrid trajectory data for a single element within a data structure
 * trajectory.
 * 
 * Intended Operator: System
 * 
 * @param <X>
 *            specific class of stored data structure
 */
public class HybridTrajectoryElement<X> {

	/**
	 * Trajectory element field
	 */
	private Field child;

	/**
	 * Data structure containing the element field
	 */
	private DataStructure parent;

	/**
	 * List of stored values
	 */
	private ArrayList<X> storedData;

	/**
	 * List of data store time indices
	 */
	private ArrayList<HybridTime> storeTimes;

	/**
	 * Construct a new hybrid trajectory element
	 * 
	 * @param store_times
	 *            list to store time indices
	 * @param parent
	 *            field parent
	 * @param element
	 *            field
	 */
	public HybridTrajectoryElement(ArrayList<HybridTime> store_times, DataStructure parent, Field element) {

		storedData = new ArrayList<X>();
		this.storeTimes = store_times;
		this.child = element;
		this.parent = parent;
	}

	/**
	 * Get all of the trajectory data for the specified element of the hybrid object
	 * 
	 * @return list of all element values along the trajectory
	 */
	public ArrayList<X> getAllStoredData() {

		return storedData;
	}

	/**
	 * Get element field
	 * 
	 * @return element field
	 */
	public Field getChild() {

		return child;
	}

	/**
	 * Get parent data structure of element field
	 * 
	 * @return data structure
	 */
	public DataStructure getParent() {

		return parent;
	}

	/**
	 * Get another element trajectory that has the same parent, used to plot two
	 * element values against each other
	 * 
	 * @param element_name
	 *            variable name of element to search for
	 * @param series_list
	 *            of potential element trajectories to be checked
	 * 
	 * @return an element trajectory if a match is found, otherwise null
	 */
	public HybridTrajectoryElement<?> getSeriesWithSameParent(String element_name,
			ArrayList<HybridTrajectoryElement<?>> series_list) {

		for (HybridTrajectoryElement<?> series : series_list) {
			if (series.parent.toString().equals(parent.toString())) {
				if (series.child.getName().equals(element_name)) {
					return series;
				}

			}
		}
		return null;
	}

	/**
	 * Get value for the specified time index
	 * 
	 * @param store_time
	 *            time index to fetch data
	 * @return value
	 */
	public X getStoredData(HybridTime store_time) {

		Integer ind = storeTimes.indexOf(store_time);
		if (ind >= 0) {
			return storedData.get(ind);
		} else {
			return null;
		}
	}

	/**
	 * Get the list of store time indices
	 * 
	 * @return list of stored data times
	 */
	public ArrayList<HybridTime> getStoreTimes() {

		return storeTimes;
	}

	/**
	 * Create a new hybrid trajectory element
	 * 
	 * @param store_times
	 *            list to store time indices
	 * @param parent
	 *            field parent
	 * @param element
	 *            field
	 * @param data_class
	 *            class of element
	 * @return new hybrid trajectory element
	 * @param <C>
	 *            specific class of data to be fetched
	 */
	public static <C> HybridTrajectoryElement<C> getSeries(ArrayList<HybridTime> store_times, DataStructure parent,
			Field element, Class<C> data_class) {

		return new HybridTrajectoryElement<C>(store_times, parent, element);
	}
}
