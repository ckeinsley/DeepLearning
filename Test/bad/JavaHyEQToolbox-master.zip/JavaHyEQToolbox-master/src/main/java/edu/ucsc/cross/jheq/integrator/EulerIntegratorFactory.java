/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * EulerIntegratorFactory.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.integrator;

import org.apache.commons.math3.ode.FirstOrderIntegrator;
import org.apache.commons.math3.ode.nonstiff.EulerIntegrator;

/**
 * Euler integrator factory that creates the integrator based on the specified
 * parameters.
 * 
 * Intended Operator: User
 */
public class EulerIntegratorFactory implements FirstOrderIntegratorFactory {

	/**
	 * Integrator step size.
	 */
	public double integratorStepSize = 1E-3;

	/**
	 * Constructor with default parameters
	 */
	public EulerIntegratorFactory() {

	}

	/**
	 * Constructor with specified parameters
	 * 
	 * @param integrator_step_size
	 *            integrator step size
	 */
	public EulerIntegratorFactory(double integrator_step_size) {

		integratorStepSize = integrator_step_size;

	}

	/**
	 * Create Euler integrator from specified step size
	 */
	@Override
	public FirstOrderIntegrator createIntegrator() {

		EulerIntegrator integrator = new EulerIntegrator(integratorStepSize);
		return integrator;
	}

	/**
	 * Determine the minimum step size of the integrator
	 * 
	 * @return minimum step size value
	 */
	@Override
	public double getMaxStepSize() {

		return integratorStepSize;
	}

}
