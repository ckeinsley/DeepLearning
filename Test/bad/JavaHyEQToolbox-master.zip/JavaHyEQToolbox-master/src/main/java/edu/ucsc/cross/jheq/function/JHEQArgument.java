package edu.ucsc.cross.jheq.function;


public interface JHEQArgument {

}
