
package edu.ucsc.cross.jheq.builder;

import java.io.File;
import java.util.HashMap;

import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.application.JHEQLibrary;
import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.function.JHEQFeature;
import edu.ucsc.cross.jheq.function.JHEQOperation;
import edu.ucsc.cross.jheq.model.HybridSystem;

public class ContentBuilder extends JHEQOperation {

	public static HashMap<String, Object> globalVariables = new HashMap<String, Object>();

	public HashMap<String, ObjectBuilder<?>> globalVariableBuilderMap;

	public HashMap<String, SystemBuilder<?>> systemBuilderMap;

	public String[] vertexSet;

	public int[][] adjacencyMatrix;

	public String postProcessingTaskFilePaths[];

	public ContentBuilder() {

		super();
		this.globalVariableBuilderMap = new HashMap<String, ObjectBuilder<?>>();
		this.systemBuilderMap = new HashMap<String, SystemBuilder<?>>();
		postProcessingTaskFilePaths = new String[]
			{};
	}

	public void setupAdjacency() {

	}

	public void postProcess(JHEQToolbox exe, String input) {

		for (String process : postProcessingTaskFilePaths) {
			JHEQFeature post;
			try {
				if (process.length() > 0) {
					File path = new File(process);
					post = JHEQLibrary.loadFeature(path);
					if (post != null) {
						post.perform(exe, input);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void setupSystems(JHEQToolbox exe) {

		JHEQEnvironment env = exe.getEnvironment();
		Object[] verts = new Object[vertexSet.length];
		for (int ind = 0; ind < vertexSet.length; ind++) {
			try {

				SystemBuilder<?> gen = this.systemBuilderMap.get(vertexSet[ind]);

				HybridSystem generate = gen.generateSystem(env, null);

				verts[ind] = generate;

			} catch (Exception badSys) {
				badSys.printStackTrace();
			}
		}

		env.getNetwork().connect(verts, adjacencyMatrix);

	}

	public void setupGlobalGens() {

		for (String globalVar : this.globalVariableBuilderMap.keySet()) {
			try {

				ObjectBuilder<?> gen = this.globalVariableBuilderMap.get(globalVar);
				Object genObj = gen.generate();
				globalVariables.put(globalVar, genObj);

			} catch (Exception badPath) {
				badPath.printStackTrace();
			}
		}
	}

	@Override
	public void perform(JHEQToolbox app, String input) {

		try {
			setupGlobalGens();
			setupSystems(app);
			setupAdjacency();
			postProcess(app, input);
		} catch (Exception badPath) {
			badPath.printStackTrace();
		}
	}

}
