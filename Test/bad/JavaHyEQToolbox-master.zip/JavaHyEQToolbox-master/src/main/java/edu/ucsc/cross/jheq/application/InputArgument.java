
package edu.ucsc.cross.jheq.application;

import java.io.File;

public class InputArgument<V> {

	V value;

	private String flag;

	private Class<V> valueClass;

	public InputArgument(String str, Class<V> classs) {

		this.flag = str;
		this.valueClass = classs;
	}

	public Object getValue(Class<V> arg, String str)

	{

		Object val = null;

		if (valueClass.equals(File.class)) {
			val = new File(str);
		} else if (valueClass.equals(Double.class) || valueClass.equals(double.class)) {
			val = Double.parseDouble(str);
		} else if (valueClass.equals(Integer.class) || valueClass.equals(int.class)) {
			val = Integer.parseInt(str);
		} else if (valueClass.equals(Boolean.class) || valueClass.equals(boolean.class)) {
			val = Boolean.parseBoolean(str);
		} else if (valueClass.equals(String.class)) {
			val = str;
		}
		return val;
	}

	/**
	 * @return the value
	 */
	public V getValue() {

		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(V value) {

		this.value = value;
	}

	/**
	 * @return the flag
	 */
	public String getFlag() {

		return flag;
	}

	/**
	 * @param flag
	 *            the flag to set
	 */
	public void setFlag(String flag) {

		this.flag = flag;
	}

	/**
	 * @return the valueClass
	 */
	public Class<V> getValueClass() {

		return valueClass;
	}

	/**
	 * @param valueClass
	 *            the valueClass to set
	 */
	public void setValueClass(Class<V> valueClass) {

		this.valueClass = valueClass;
	}

}
