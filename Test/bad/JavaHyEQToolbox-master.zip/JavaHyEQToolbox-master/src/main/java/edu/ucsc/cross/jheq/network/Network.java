/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * ------------------------------------------------ Network.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS); 06-August-2018 : Version 2 - redesigned as class instead of
 * interface (BS); 25-August-2018 : Added capability to define connections by vertex and edge set with new constructors
 * (BS);
 *
 */

package edu.ucsc.cross.jheq.network;

import java.util.ArrayList;

import org.jgrapht.Graph;

import com.be3short.obj.access.FieldFinder;

import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.object.DataStructure;

/**
 * A network that connects elements of type N.
 * 
 * Intended Operator: User
 * 
 * @param <Object>
 *            the type of objects connected by the network
 */
public class Network extends DataStructure {

	// private static HashMap<Object, ArrayList<Network>> networks = new
	// HashMap<Object, ArrayList<Network>>();

	// private static HashMap<Network, HashMap<Object, Network>> // // networkMap =
	// new
	// HashMap<Network, HashMap<Object, Network>>();

	private Topology topology;

	/**
	 * Constructor for a new network with the default graph type
	 * 
	 * @param directed
	 *            flag indicating if the network topology should be directed
	 */
	public Network(boolean directed) {

		topology = new Topology(directed);
		// // networkMap.put(this, new HashMap<Object, Network>());
	}

	/**
	 * Constructor for a new directed or undirected network with the specified graph
	 * type
	 * 
	 * @param directed
	 *            flag indicating if the network topology should be directed
	 * @param graph
	 *            graph type to use
	 */
	public Network(boolean directed, Graph<Object, Connection<Object, Object>> graph) {

		topology = new Topology(directed, graph);
		// // networkMap.put(this, new HashMap<Object, Network>());
	}

	/**
	 * Constructor for a new network with the default graph type
	 * 
	 * @param directed
	 *            flag indicating if the network topology should be directed
	 * @param vertices
	 *            array of objects in the vertex set in order of the index used in
	 *            the adjacency matrix, ie vertices[0] is the first object,
	 *            vertices[1] the second, etc
	 * @param adjacency_matrix
	 *            adjacency matrix defining the connections between verticies, an
	 *            entry adjacency_matrix[i][j] is equal to 1 if a connection exists
	 *            between vertex i and vertex j, and 0 if no connection exists
	 */
	public Network(boolean directed, Object[] vertices, int[][] adjacency_matrix) {

		topology = new Topology(directed);
		connect(vertices, adjacency_matrix);
		// // networkMap.put(this, new HashMap<Object, Network>());
	}

	/**
	 * /** Constructor for a new directed or undirected network with the specified
	 * graph type
	 * 
	 * @param directed
	 *            flag indicating if the network topology should be directed
	 * @param graph
	 *            graph type to use
	 * @param vertices
	 *            array of objects in the vertex set in order of the index used in
	 *            the adjacency matrix, ie vertices[0] is the first object,
	 *            vertices[1] the second, etc
	 * @param adjacency_matrix
	 *            adjacency matrix defining the connections between verticies, an
	 *            entry adjacency_matrix[i][j] is equal to 1 if a connection exists
	 *            between vertex i and vertex j, and 0 if no connection exists
	 */
	public Network(boolean directed, Graph<Object, Connection<Object, Object>> graph, Object[] vertices,
			int[][] adjacency_matrix) {

		topology = new Topology(directed, graph);
		connect(vertices, adjacency_matrix);
		// // networkMap.put(this, new HashMap<Object, Network>());
	}

	/**
	 * Define connections in a network by defining the vertex set as an array and
	 * the edge set as an adjacency matrix. The vertex set should have a dimension
	 * of N and the adjacency matrix should have a dimension of N by N
	 * 
	 * @param vertices
	 *            array of objects in the vertex set in order of the index used in
	 *            the adjacency matrix, ie vertices[0] is the first object,
	 *            vertices[1] the second, etc
	 * @param adjacency_matrix
	 *            adjacency matrix defining the connections between verticies, an
	 *            entry adjacency_matrix[i][j] is equal to 1 if a connection exists
	 *            between vertex i and vertex j, and 0 if no connection exists
	 */
	public void connect(Object[] vertices, int[][] adjacency_matrix) {

		if (vertices.length != adjacency_matrix.length) {
			Console.error("vertex set dimensions don't match adjacency matrix, connections not established",
					new Exception());
		} else {
			for (Object vertex : vertices) {
				topology.addVertex(vertex);
				// // networkMap.get(this).put(vertex, this);

			}
			for (int sourceInd = 0; sourceInd < adjacency_matrix.length; sourceInd++) {
				try {

					Object source = vertices[sourceInd];
					for (int targInd = 0; targInd < adjacency_matrix[sourceInd].length; targInd++) {
						if (adjacency_matrix[sourceInd][targInd] > 0) {
							Object target = vertices[targInd];
							connect(source, target);
						}
					}

				} catch (Exception invalidAdjacencyMatrix) {
					Console.error("invalid adjacency matrix, some connections not established " + adjacency_matrix,
							invalidAdjacencyMatrix);
				}

			}
		}
	}

	/**
	 * Get all of the vertices in the network
	 * 
	 * @param <X>
	 * 
	 * @return array list containing all objects that are vertices of the network
	 */
	@SuppressWarnings("unchecked")
	public <X> ArrayList<X> getAllVertices(HybridSystem sys, Class<X> vertex_class) {

		ArrayList<X> filteredVertices = new ArrayList<X>();
		ArrayList<Object> connections = sys.network().getAllVertices();
		for (Object connection : connections) {
			if (FieldFinder.containsSuper(connection, vertex_class)) {
				if (!filteredVertices.contains(connection)) {
					filteredVertices.add((X) connection);
				}
			}
		}
		return filteredVertices;
	}

	/**
	 * Get all of the objects connected to a specified object
	 * 
	 * @param <S>
	 * 
	 * @param <T>
	 *            class type of connected object to search for
	 * @param <S>
	 * 
	 * @param source
	 *            source vertex
	 * @param connected_class
	 *            class of connected object to search for
	 * @return array list containing all objects that the source is connected to
	 */
	public <S> ArrayList<Connection<Object, Object>> getConnections(S source, Integer direction) {

		ArrayList<Connection<Object, Object>> connections = new ArrayList<Connection<Object, Object>>();
		for (Connection<Object, Object> conn : topology.edgesOf(source)) {
			if (Connection.INCOMING + direction > 0 && conn.getTarget().equals(source)
					|| Connection.OUTGOING + direction < 0 && conn.getSource().equals(source)) {
				try {
					connections.add(conn);
				} catch (Exception badCast) {
					Console.error("unable to cast object " + conn + " with source " + source, badCast);
				}
			}
		}
		return connections;

	}

	/**
	 * Get all of the vertices in the network
	 * 
	 * @return array list containing all objects that are vertices of the network
	 */
	public ArrayList<Object> getAllVertices() {

		ArrayList<Object> connections = new ArrayList<Object>();
		for (Object connection : getTopology().vertexSet()) {
			connections.add(connection);
		}
		return connections;
	}

	/**
	 * Connect two nodes
	 * 
	 * @param source
	 *            node
	 * @param target
	 *            node
	 * @param properties
	 *            list of properties of the connection
	 */
	public Connection<Object, Object> connect(Object source, Object target) {

		Connection<Object, Object> connection = null;
		try {
			if (source != null && target != null) {
				if (!topology.containsVertex(source)) {
					topology.addVertex(source);

				}
				if (!topology.containsVertex(target)) {
					topology.addVertex(target);

				}
				connection = topology.addEdge(source, target);
				if (!topology.isDirected()) {
					connection = topology.addEdge(target, source);

				}
			}
		} catch (Exception badConnection) {
			Console.error("Unable to connect " + source + " and " + target, badConnection);
		}
		return connection;
	}

	/**
	 * Attempt to disconnect specified source and destination
	 * 
	 * @param source
	 *            start vertex
	 * @param target
	 *            end vertex
	 */
	public void disconnect(Object source, Object target) {

		try {
			if (source != null && target != null) {
				if (!topology.containsVertex(source)) {
					topology.addVertex(source);
				}
				if (!topology.containsVertex(target)) {
					topology.addVertex(target);
				}
				topology.removeEdge(source, target);
				if (!topology.isDirected()) {
					topology.removeEdge(target, source);
				}
			}
		} catch (Exception badConnection) {
			Console.error("Unable to connect " + source + " and " + target, badConnection);
		}
	}

	/**
	 * Get the network topology graph
	 * 
	 * @return the network topology graph
	 */
	public Topology getTopology() {

		return topology;
	}

}
