package edu.ucsc.cross.jheq.integrator;

import org.apache.commons.math3.ode.FirstOrderIntegrator;
import org.apache.commons.math3.ode.nonstiff.DormandPrince853Integrator;
import org.apache.commons.math3.ode.nonstiff.EulerIntegrator;

public class VariableIntegratorFactory implements FirstOrderIntegratorFactory
{

	/**
	 * Type of integrator to be created
	 */
	public IntegratorType integratorType = IntegratorType.DORMAND_PRINCE_853;
	/**
	 * Ode step size if using a fixed step integrator
	 */
	public double odeFixedStepSize = 1E-3;

	/**
	 * Maximum step size for variable step integrator.
	 */
	public double odeMaximumStepSize = 1E-2;

	/**
	 * Minimum ode step size of a variable step integrator.
	 */
	public double odeMinimumStepSize = 1E-9;

	/**
	 * Absolute tolerance of the ode solver: AbsTol(i) is a threshold below which the value of the ith solution
	 * component is unimportant. The absolute error tolerances determine the accuracy when the solution approaches zero.
	 */
	public double odeSolverAbsoluteTolerance = 1.0e-6;

	/**
	 * Relative tolerance of the ode solver: This tolerance is a measure of the error relative to the size of each
	 * solution component. Roughly, it controls the number of correct digits in all solution components, except those
	 * smaller than thresholds AbsTol(i).The default, 1e-3, corresponds to 0.1% accuracy.
	 */
	double odeRelativeTolerance = 1.0e-6;

	/**
	 * Constructor with default parameters
	 */
	public VariableIntegratorFactory()
	{

	}

	/**
	 * Constructor with specified parameters
	 * 
	 * @param ode_max_step_size
	 *            ode minimum step size
	 * @param ode_min_step_size
	 *            ode maximum step size
	 * @param ode_rel_tol
	 *            ode relative tolerance
	 * @param ode_abs_tol
	 *            ode absolute tolerance
	 */
	public VariableIntegratorFactory(double ode_min_step_size, double ode_max_step_size, double ode_rel_tol,
	double ode_abs_tol, IntegratorType integrator_type)
	{

		odeMinimumStepSize = ode_min_step_size;
		odeMaximumStepSize = ode_max_step_size;

		odeRelativeTolerance = ode_rel_tol;
		odeSolverAbsoluteTolerance = ode_abs_tol;
		integratorType = integrator_type;
	}

	/**
	 * Create a Dormand prince 853 integrator
	 * 
	 * @return first order integrator
	 */
	@Override
	public FirstOrderIntegrator createIntegrator()
	{
		FirstOrderIntegrator integrator = null;
		switch (integratorType)
		{
		case DORMAND_PRINCE_853:
			integrator = new DormandPrince853Integrator(odeMinimumStepSize, odeMaximumStepSize,
			odeSolverAbsoluteTolerance, odeRelativeTolerance);
			break;
		case EULER:
			integrator = new EulerIntegrator(odeFixedStepSize);
			break;
		default:
			integrator = new DormandPrince853Integrator(odeMinimumStepSize, odeMaximumStepSize,
			odeSolverAbsoluteTolerance, odeRelativeTolerance);
			break;
		}
		return integrator;
	}

	/**
	 * Determine the minimum step size of the integrator
	 * 
	 * @return minimum step size value
	 */
	@Override
	public double getMaxStepSize()
	{

		return odeMaximumStepSize;
	}
}
