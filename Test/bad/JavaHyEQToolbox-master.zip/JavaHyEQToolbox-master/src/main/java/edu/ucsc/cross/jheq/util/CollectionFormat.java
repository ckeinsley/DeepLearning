
package edu.ucsc.cross.jheq.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;

import edu.ucsc.cross.jheq.object.IndexedObject;

@SuppressWarnings("unchecked")
public class CollectionFormat {

	public static ArrayList<Object> list(Object... objects) {

		ArrayList<Object> list = new ArrayList<Object>();

		for (Object obj : objects) {
			if (!list.contains(obj)) {
				list.add(obj);
			}
		}
		return list;
	}

	public static Object[] array(Object... objects) {

		if (objects == null) {
			return new Object[]
				{};
		}
		Object[] list = new Object[objects.length];
		int i = 0;
		for (Object obj : objects) {
			list[i++] = (obj);
		}
		return list;
	}

	public static <T> ArrayList<T> getArrayList(Collection<T> set) {

		ArrayList<T> list = new ArrayList<T>(set);

		return list;
	}

	public static <T> ArrayList<T> getArrayList(T... objects) {

		ArrayList<T> list = new ArrayList<T>();
		for (T obj : objects) {
			list.add(obj);
		}
		return list;
	}

	public static <T> T[] getArray(ArrayList<T> objects) {

		T[] arr = (T[]) objects.toArray(new Object[objects.size()]);
		return arr;
	}

	public static Object[] getObjArray(ArrayList<Object> objects) {

		Object[] arr = objects.toArray(new Object[objects.size()]);
		return arr;
	}

	public static <T> ArrayList<String> sortKeys(HashMap<String, T> map) {

		ArrayList<String> list = new ArrayList<String>(map.keySet());
		Collections.sort(list);
		return list;
	}

	public static ArrayList<Object> getObjectArrayist(Object... objects) {

		ArrayList<Object> list = getArrayList(objects);

		return list;
	}

	public static String[] getStringListWithBlankEntriesFiltered(String[] objects) {

		ArrayList<String> list = new ArrayList<String>();
		for (String obj : objects) {
			if (!IndexedObject.BLANK_INDEX.contains(obj)) {
				list.add(obj);
			}
		}
		return list.toArray(new String[list.size()]);
	}
}
