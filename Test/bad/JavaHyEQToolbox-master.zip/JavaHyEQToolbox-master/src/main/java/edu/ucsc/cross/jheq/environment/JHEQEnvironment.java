/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ HSEnvironment.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS); 01-August-2018 : Added save/load file method without compression
 * argument to compress by default (save), and select path using file browser when unspecified (BS);
 *
 */

package edu.ucsc.cross.jheq.environment;

import java.io.File;
import java.util.HashMap;

import com.be3short.data.cloning.ObjectCloner;

import edu.ucsc.cross.jheq.file.FileBrowser;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.network.Network;
import edu.ucsc.cross.jheq.trajectory.HybridTime;
import edu.ucsc.cross.jheq.trajectory.TrajectorySet;
import edu.ucsc.cross.jheq.worker.EngineSupervisor;

/**
 * The environment that contains all of the components and provides
 * functionality for configuring/executing simulations. It organizes all of the
 * components that are relevant, keeping them separate from the system
 * components. It interacts with the user and the engine to perform tasks with
 * minimal user effort. Each environment is linked to an engine, which it uses
 * to perform these tasks and simulations.
 * 
 * Intended Operator: User
 */
public class JHEQEnvironment {

	protected String environmentId;

	/**
	 * The current environment settings.
	 */
	protected EnvironmentSettings settings;

	/**
	 * The set of all hybrid systems included in the environment.
	 */
	protected EnvironmentContents systems;

	/**
	 * The set of trajectories that are stored during a simulation.
	 */
	protected TrajectorySet trajectories;

	/**
	 * The global network of the environment
	 */
	protected Network network;

	public static HashMap<String, JHEQEnvironment> environmentMap = new HashMap<String, JHEQEnvironment>();

	/**
	 * Creates a new empty hybrid systems environment with the default settings. and
	 * parameters
	 */
	public JHEQEnvironment() {

		settings = new EnvironmentSettings();
		systems = new EnvironmentContents();
		trajectories = new TrajectorySet(systems);
		network = new Network(true);
		environmentId = this.toString() + "_" + System.currentTimeMillis();
		addEnvironment(this);
		getManager();
	}

	/**
	 * Clear the generated trajectories.
	 */
	public void clearTrajectories() {

		trajectories = new TrajectorySet(systems);
	}

	/**
	 * Make a copy of the environment.
	 * 
	 * @return environment a copy of the environment
	 */
	public JHEQEnvironment copy() {

		return ObjectCloner.deepInstanceClone(this);
	}

	/**
	 * Get the time within the environment
	 * 
	 * @return execution parameters of the environment
	 */
	public HybridTime getEnvironmentTime() {

		return getManager().getEnvironmentTime();

	}

	/**
	 * Get the engine operator that connects/operates all of the components that are
	 * used to run the environment.
	 * 
	 * @return engine the engine operator that runs everything behind the scenes
	 */
	protected EngineSupervisor getManager() {

		if (!EngineSupervisor.operatorMap.containsKey(this)) {
			EngineSupervisor.operatorMap.put(this, new EngineSupervisor(this));

		}
		addEnvironment(this);
		return EngineSupervisor.operatorMap.get(this);
	}

	/**
	 * Get the environment settings.
	 * 
	 * @return settings of the environment
	 */
	public EnvironmentSettings getSettings() {

		return settings;
	}

	/**
	 * Get the set of hybrid systems that are contained in the environment.
	 *
	 * @return the set of systems that are loaded into the environment
	 */
	public EnvironmentContents getSystems() {

		return systems;
	}

	/**
	 * Get the set of trajectories generated by the last execution of the
	 * environment.
	 * 
	 * @return the set of trajectories that have been generated by the environment
	 *         (or loaded)
	 */
	public TrajectorySet getTrajectories() {

		if (trajectories == null) {
			trajectories = new TrajectorySet(getSystems());
		}
		return trajectories;
	}

	/**
	 * Load the specified environment settings.
	 * 
	 * @param settings
	 *            of the environment
	 */
	public void loadEnvironment(JHEQEnvironment env) {

		if (env != null) {
			this.getManager().reset();

			this.settings = (env.settings);
			this.network = env.network;
			systems = env.getSystems();
			trajectories = new TrajectorySet(systems);
		}
	}

	/**
	 * Load the specified environment settings.
	 * 
	 * @param settings
	 *            of the environment
	 */
	public void loadSettings(EnvironmentSettings settings) {

		if (settings != null) {
			this.settings = (settings);
		}
	}

	/**
	 * Load the set of systems to include in the environment.
	 * 
	 * @param contents
	 *            the set of systems that will be loaded into the environment
	 */
	public void loadSystems(EnvironmentContents contents) {

		if (contents != null) {
			systems = contents;
			trajectories = new TrajectorySet(systems);
		}
	}

	/**
	 * Load the set of trajectories (and corresponding systems) contained in the
	 * environment.
	 * 
	 * @param data
	 *            the set of trajectories to be loaded into the environment (note:
	 *            this is not recommended, it is better to just save the whole
	 *            environment)
	 */
	public void loadTrajectories(TrajectorySet data) {

		if (data == null) {
			trajectories = null;
		} else {

			getSystems().add(data.getSystems());
			trajectories = data;
			getManager().getDataManager().initializeIndicies();

		}
	}

	/**
	 * Run the environment.
	 * 
	 * @return trajectory set the trajectory set generated during the simulation
	 */
	public TrajectorySet run() {

		Console.info("Starting environment");
		return getManager().run();
	}

	/**
	 * Run the environment.
	 * 
	 * @param maximum_time
	 *            maximum simulation time
	 * @param maximum_jumps
	 *            maximum number of jumps
	 * @return trajectory set the trajectory set generated during the simulation
	 */
	public TrajectorySet run(double maximum_time, int maximum_jumps) {

		settings.maximumTime = maximum_time;
		settings.maximumJumps = maximum_jumps;
		Console.info("Starting environment");
		return getManager().run();
	}

	/**
	 * Save the entire contents of the environment to a compressed file location
	 * selected by the file browser.
	 * 
	 * @param file
	 *            the location to save the environment
	 */
	public void saveToFile() {

		saveToFile(true);
	}

	/**
	 * Save the entire contents of the environment to a file location selected by
	 * the file browser.
	 * 
	 * @param file
	 *            the location to save the environment
	 */
	public void saveToFile(boolean compressed) {

		saveToFile(FileBrowser.save(), compressed);
	}

	/**
	 * Save the entire contents of the environment to a compressed file.
	 * 
	 * @param file
	 *            the location to save the environment
	 */
	public void saveToFile(File file) {

		saveToFile(file, true);
	}

	/**
	 * Save the entire contents of the environment to a file.
	 * 
	 * @param file
	 *            the location to save the environment
	 * @param compressed
	 *            flag indicating if file should be compressed
	 */
	public void saveToFile(File file, boolean compressed) {

		XMLFileTools.save(this, file, compressed);
		// TrajectorySet savedData = trajectories;
		// CollectionFile output = new CollectionFile();
		// output.addObject(this);
		// output.saveToFile(file, compressed);
		// trajectories = savedData;
	}

	/**
	 * Stop the current execution of the environment.
	 */
	public void stop() {

		getManager().getInterruptDetector().setPaused(true);

	}

	/**
	 * Creates a hybrid systems environment from the specified parameters.
	 * 
	 * @param systems
	 *            set of systems that will be loaded into the environment
	 * 
	 * @param settings
	 *            of the environment
	 * 
	 * @return env the hybrid system created by the parameters
	 */
	public static JHEQEnvironment create(EnvironmentContents systems, EnvironmentSettings settings) {

		JHEQEnvironment env = new JHEQEnvironment();
		env.loadSystems(systems);
		env.trajectories = new TrajectorySet(systems);
		env.loadSettings(settings);
		return env;
	}

	/**
	 * Creates a hybrid systems environment from the specified parameters, performs
	 * an execution, and returns the resulting trajectories.
	 * 
	 * 
	 * @param systems
	 *            set of systems that will be loaded into the environment
	 * 
	 * @param settings
	 *            of the environment
	 * 
	 * @return trajectories the set of trajectories generated by the simulation
	 */
	public static TrajectorySet createAndRun(EnvironmentContents systems, EnvironmentSettings settings) {

		JHEQEnvironment env = new JHEQEnvironment();
		env.loadSystems(systems);
		env.loadSettings(settings);
		return env.run();
	}

	/**
	 * Creates a hybrid systems environment from the saved file selected using file
	 * browser.
	 * 
	 * @param file
	 *            the file to attempt to load the environment from
	 * @return env the environment loaded from the file (if it able to be loaded)
	 */
	public static JHEQEnvironment loadFromFile() {

		return loadFromFile(FileBrowser.load());
	}

	/**
	 * Creates a hybrid systems environment from the saved file specified.
	 * 
	 * @param file
	 *            the file to attempt to load the environment from
	 * @return env the environment loaded from the file (if it able to be loaded)
	 */
	public static JHEQEnvironment loadFromFile(File file) {

		JHEQEnvironment env = XMLFileTools.loadContent(JHEQEnvironment.class, file);// CollectionFile.loadObjectFromFile(file,
		if (env != null) {
			env.getManager();

			return env;

		} else {
			return null;
		}

	}

	public String getEnvironmentId() {

		return environmentId;
	}

	public Network getNetwork() {

		return network;
	}

	public static void addEnvironment(JHEQEnvironment env) {

		JHEQEnvironment.environmentMap.put(env.getEnvironmentId(), env);
	}
}
