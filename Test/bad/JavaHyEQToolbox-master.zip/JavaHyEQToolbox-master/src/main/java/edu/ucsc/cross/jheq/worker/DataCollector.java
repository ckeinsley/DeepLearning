/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * DataCollector.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.worker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import com.be3short.obj.manipulation.DynamicObjectManipulator;
import com.be3short.obj.manipulation.ObjectManipulator;

import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.object.DataStructure;
import edu.ucsc.cross.jheq.object.DataStructureProperties;
import edu.ucsc.cross.jheq.specification.JumpStatus;
import edu.ucsc.cross.jheq.trajectory.HybridTime;
import edu.ucsc.cross.jheq.trajectory.HybridTrajectoryElement;
import edu.ucsc.cross.jheq.trajectory.HybridTrajectoryInterface;
import edu.ucsc.cross.jheq.trajectory.TrajectorySet;

/**
 * Monitors the system to store data at correct times depending on
 * configuration.
 * 
 * Intended Operator: System
 */
public class DataCollector {

	/**
	 * The mapping of all element trajectories being stored indexed by their parent
	 * directories
	 */
	public static HashMap<TrajectorySet, ArrayList<HybridTrajectoryElement<?>>> seriesListMap = new HashMap<TrajectorySet, ArrayList<HybridTrajectoryElement<?>>>();

	/**
	 * Hybrid systems engine
	 */
	private EngineSupervisor engine;

	/**
	 * Current environment hybrid time time
	 */
	private HybridTime environmentTime;

	/**
	 * Initial values of each object in the environment
	 */
	private HashMap<DynamicObjectManipulator, Object> initialData;

	/**
	 * Constructor for the data collector
	 * 
	 * @param manager
	 *            engine supervisor that this collector instance will be working for
	 */
	public DataCollector(EngineSupervisor manager) {

		this.engine = manager;
		environmentTime = new HybridTime(0.0, 0);
		// nextStoreTime = 0.0;
	}

	/**
	 * Create a hybrid arc for a data structure object
	 * 
	 * @param parent
	 *            data structure that the object belongs to
	 * @param state
	 *            object manipulator corresponding to the object
	 */
	public void createHybridArc(DataStructure parent, ObjectManipulator state) {

		boolean store = state.getField().getType().isPrimitive();

		if (engine.getEnvironmentSettings().storeNonPrimativeData) {
			store = true;
		}
		if (store) {
			HybridTrajectoryInterface<?> solution = HybridTrajectoryInterface
					.createArc(engine.getEnvironmentTrajectories().getTrajectory(parent));
			solution.addSeries(state.getField(),
					HybridTrajectoryElement.getSeries(engine.getEnvironmentTrajectories().getTimeDomain(), parent,
							state.getField(), state.getField().getType()));
		}
	}

	/**
	 * Get the current environment hybrid time
	 * 
	 * @return current time
	 */
	public HybridTime getEnvironmentTime() {

		return environmentTime;
	}

	/**
	 * Get the initial values of each object in the environment
	 * 
	 * @return map with initial data
	 */
	public HashMap<DynamicObjectManipulator, Object> getInitialData() {

		return initialData;
	}

	/**
	 * Initialize the index of each data structure in the environment, each
	 * duplicate will get a unique index.
	 */
	public void initializeIndicies() {

		ArrayList<DataStructure> duplicateNames = new ArrayList<DataStructure>();
		for (ObjectManipulator state : engine.getObjectManipulator().getFieldParentMap().values())// .getSimulatedObjectAccessVector())
		{
			try {
				DataStructure parent = (DataStructure) state.getParent();
				if (!duplicateNames.contains(parent)) {
					int dup = 1;
					for (DataStructure set : duplicateNames) {
						if (parent.properties().getName().equals(set.properties().getName())) {
							dup++;
						}
					}
					DataStructureProperties.setIndex(parent.properties(), dup);
					duplicateNames.add(parent);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		removeIndicesFromNonDuplicateNames(duplicateNames);
	}

	/**
	 * Get the last time that data has been stored at
	 * 
	 * @return last time value
	 */
	private Double lastTime() {

		return engine.getEnvironmentTrajectories().getFinalTime().getTime();
	}

	/**
	 * Attempt to load the new state data from the vector
	 * 
	 * @param state_vector
	 *            new state vector from integrator
	 * @param jump_status
	 *            current jump status of the domain evaluator
	 */
	private void loadData(double state_vector[], JumpStatus jump_status) {

		if (jump_status.equals(JumpStatus.JUMP_OCCURRED)) {
			engine.getObjectManipulator().updateValueVector(state_vector);
		} else {

			engine.getObjectManipulator().readStateValues(state_vector);
		}
	}

	/**
	 * Load hybrid trajectories using the object manipulators prepared by the engine
	 */
	public void loadTrajectoryMap() {

		DataCollector.getHybridTrajectoryMap(engine.getEnvironmentTrajectories()).clear();
		for (ObjectManipulator state : engine.getObjectManipulator().getFieldParentMap().values())// .getSimulatedObjectAccessVector())
		{

			try {
				DataStructure parent = (DataStructure) state.getParent();
				if (parent.properties().isTrajectoryStored()) {
					if (!engine.getEnvironmentTrajectories().getHybridTrajectoryMap().containsKey(parent)) {

						engine.getEnvironmentTrajectories().getHybridTrajectoryMap().put(parent,
								HybridTrajectoryInterface.createArc(parent,
										engine.getEnvironmentTrajectories().getTimeDomain()));
					}
					createHybridArc(parent, state);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		initializeIndicies();
		DataCollector.populateListMap(engine.getEnvironmentTrajectories());
	}

	/**
	 * Attempt to update the simulation time, read new data from the integrator, and
	 * store new values.
	 * 
	 * @param time
	 *            current simulation time
	 * @param state_vector
	 *            new values from integrator
	 * @param jump_status
	 *            current status of the domain monitor
	 */
	public void performDataActions(double time, double state_vector[], JumpStatus jump_status) {

		performDataActions(time, state_vector, jump_status, false);
	}

	/**
	 * Attempt to update the simulation time, read new data from the integrator, and
	 * store new values.
	 * 
	 * @param time
	 *            current simulation time
	 * @param state_vector
	 *            new values from integrator
	 * @param jump_status
	 *            current status of the domain monitor
	 * @param override_store
	 *            flag to store data regardless of settings or previous store time
	 */
	public void performDataActions(double time, double state_vector[], JumpStatus jump_status, boolean override_store) {

		updateTime(time, jump_status);

		loadData(state_vector, jump_status);
		if (override_store) {
			storeNewData(time);

		} else {
			updateData(time, jump_status);
		}
	}

	/**
	 * Removes the index number appended to a unique name that was already unique.
	 * 
	 * @param objects
	 *            list of data structures that will be processed
	 */
	private void removeIndicesFromNonDuplicateNames(ArrayList<DataStructure> objects) {

		for (DataStructure obj : objects) {
			boolean nameAlreadyUnique = true;
			for (DataStructure otherObj : objects) {
				if (!otherObj.equals(obj)) {
					if (otherObj.properties().getName().equals(obj.properties().getName())) {
						nameAlreadyUnique = false;

					}
				}
			}
			if (nameAlreadyUnique) {
				DataStructureProperties.setIndex(obj.properties(), 0);
			}

		}
	}

	/**
	 * Remove the last stored value
	 */
	private void removeLastValue() {

		int i = engine.getEnvironmentTrajectories().getTimeDomain()
				.indexOf(engine.getEnvironmentTrajectories().getFinalTime());

		if (engine.getEnvironmentTrajectories().getTimeDomain().size() > i) {
			for (Integer objIndex = 0; objIndex < DataCollector.getAllDataSeries(engine.getEnvironmentTrajectories())
					.size(); objIndex++) {
				HybridTrajectoryElement<?> data = DataCollector.getAllDataSeries(engine.getEnvironmentTrajectories())
						.get(objIndex);
				if (data.getAllStoredData().size() > i) {
					data.getAllStoredData().remove(i);
				}
			}
			engine.getEnvironmentTrajectories().getTimeDomain().remove(i);
		}

	}

	/**
	 * Remove all values stored before the specified time, typically used for
	 * resolving errors.
	 * 
	 * @param time
	 *            time to clear all data until
	 */
	public void removePreviousVals(Double time) {

		try {
			if (lastTime() > 0.0) {
				while (lastTime() >= time) {
					try {
						{
							removeLastValue();
						}
					} catch (Exception removeLastValueFail) {
						removeLastValueFail.printStackTrace();
					}
				}
			}
		} catch (Exception removeValsFail) {
			removeValsFail.printStackTrace();
		}
	}

	/**
	 * Reload the previously stored values
	 * 
	 * @return the time that the values reverted back to
	 */
	public Double resetToLastData() {

		removePreviousVals(engine.getEnvironmentTrajectories().getFinalTime().getTime());
		HybridTime time = engine.getEnvironmentTrajectories().getFinalTime();
		for (HybridTrajectoryElement<?> data : DataCollector.getAllDataSeries(engine.getEnvironmentTrajectories()))
		// .getSimulatedObjectAccessVector().length; objIndex++)
		{
			ObjectManipulator obj = engine.getObjectManipulator().getFieldParentMap()
					.get(data.getParent().toString() + data.getChild().getName());// [objIndex];
			// DataSeries<?> data =
			// manager.getDataCollector().getGlobalStateData().get(objIndex);
			obj.updateObject(data.getStoredData(time));
		}
		return time.getTime();
	}

	/**
	 * Clear any stored data and reload the initial values
	 */
	public void restoreInitialData() {

		restoreInitialData(true);
	}

	/**
	 * Potentially clear any stored data and reload the initial values
	 * 
	 * @param clear
	 *            flag indicating if previous data should be cleared
	 */
	public void restoreInitialData(boolean clear) {

		for (DynamicObjectManipulator obj : engine.getObjectManipulator().getFieldParentMap().values()) {
			// DynamicObjectManipulator obj =
			// manager.getExecutionContent().getFieldParentMap()[objIndex];
			Object data = initialData.get(obj);//
			// DataMonitor.getAllDataSeries(manager.getDataCollector()).get(objIndex);

			try {
				obj.updateObject(data);
				if (data.getClass().equals(Double.class) || data.getClass().equals(double.class)) {
					obj.getField().set(obj.getChangeParent(), 0.0);
				}
			} catch (IllegalArgumentException | IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (clear) {
				// data.getAllStoredData().clear();
			}
		}
		if (clear) {
			engine.getEnvironmentTrajectories().getTimeDomain().clear();
		}
	}

	/**
	 * Sets the current environment time
	 * 
	 * @param environmentTime
	 *            time to be loaded
	 */
	public void setEnvironmentTime(HybridTime environmentTime) {

		this.environmentTime = environmentTime;
	}

	/**
	 * Store the initial values of each element
	 */
	public void storeInitialData() {

		initialData = new HashMap<DynamicObjectManipulator, Object>();
		for (DynamicObjectManipulator obj : engine.getObjectManipulator().getFieldParentMap().values()) {
			// DynamicObjectManipulator obj =
			// manager.getExecutionContent().getFieldParentMap()[objIndex];
			initialData.put(obj, obj.getObject());// DataMonitor.getAllDataSeries(manager.getDataCollector()).get(objIndex);
		}
	}

	/**
	 * Attempt to store the current data
	 * 
	 * @param time
	 *            current simulation time
	 */
	public void storeNewData(Double time) {

		// removePreviousVals(time);
		try {
			// if
			// (!time.equals(manager.getDataCollector().getStoreTimes().get(0).getTime()))
			// {
			for (HybridTrajectoryElement<?> data : DataCollector.getAllDataSeries(engine.getEnvironmentTrajectories()))
			// .getSimulatedObjectAccessVector().length; objIndex++)
			{
				ObjectManipulator obj = engine.getObjectManipulator().getFieldParentMap()
						.get(data.getParent().toString() + data.getChild().getName());// [objIndex];
				// DataSeries<?> data =
				// manager.getDataCollector().getGlobalStateData().get(objIndex);
				storeDataGeneral(data, obj.getObject());
			}
			// }
		} catch (

		Exception removeValsFail) {
			removeValsFail.printStackTrace();
		}
		engine.getEnvironmentTrajectories().getTimeDomain()
				.add(new HybridTime(time, engine.getObjectManipulator().getHybridSimTime().getJumps()));
	}

	/**
	 * Attempt to store new data if jump status permits or conditions are met.
	 * 
	 * @param time
	 *            current simulation time
	 * @param jump_status
	 *            current state of the domain monitor
	 */
	private void updateData(Double time, JumpStatus jump_status) {

		if (jump_status.equals(JumpStatus.JUMP_OCCURRED)) {
			Console.debug("Jump occurred : t = " + time + " j = "
					+ engine.getObjectManipulator().getHybridSimTime().getJumps());
			storeNewData(time);
		} else if (jump_status.equals(JumpStatus.JUMP_DETECTED)) {
			Console.debug("Jump detected : t = " + time + " j = "
					+ engine.getObjectManipulator().getHybridSimTime().getJumps());
			{
				storeNewData(time);
			}
		} else {
			if (jump_status.equals(JumpStatus.APPROACHING_JUMP)) {
				if (time > (lastTime() + engine.getEnvironmentSettings().dataPointInterval)) {
					removePreviousVals(time);
				}
			}
			if (time > (lastTime() + engine.getEnvironmentSettings().dataPointInterval)) {
				storeNewData(time);
			}
		}

	}

	/**
	 * Attempt to store new simulation time if jump status permits.
	 * 
	 * @param time
	 *            current simulation time
	 * @param jump_status
	 *            current state of the domain monitor
	 */
	private void updateTime(Double time, JumpStatus jump_status) {

		if (jump_status.equals(JumpStatus.JUMP_OCCURRED)) {
			engine.getObjectManipulator().updateSimulationTime(time, 1);

		} else {
			engine.getObjectManipulator().updateSimulationTime(time);
		}
	}

	/**
	 * Get all element trajectories within a trajectory set
	 * 
	 * @param dat
	 *            data to be used
	 * @return seriesListMap arraylist of element trajectories
	 */
	public static ArrayList<HybridTrajectoryElement<?>> getAllDataSeries(TrajectorySet dat) {

		// if (!seriesListMap.containsKey(dat))
		{
			populateListMap(dat);
		}
		return seriesListMap.get(dat);
	}

	/**
	 * Get all of the hybrid trajectories as a map indexed by the corresponding data
	 * structures
	 * 
	 * @param dat
	 *            data to be used
	 * @return map of trajectories
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static HashMap<DataStructure, HybridTrajectoryInterface<?>> getHybridTrajectoryMap(TrajectorySet dat) {

		HashMap<DataStructure, HybridTrajectoryInterface<?>> dataMap = new HashMap<DataStructure, HybridTrajectoryInterface<?>>();
		for (DataStructure objectSet : dat.getHybridTrajectoryMap().keySet()) {
			dataMap.put(objectSet, new HybridTrajectoryInterface(dat.getHybridTrajectoryMap().get(objectSet)));
		}
		return dataMap;
	}

	/**
	 * Get a list of all data structures sorted by name
	 * 
	 * @param dat
	 *            data to be used
	 * @return list of data structures
	 */
	public static ArrayList<DataStructure> getObjectSetListSortedByName(TrajectorySet dat) {

		ArrayList<DataStructure> sortedSets = new ArrayList<DataStructure>();
		HashMap<String, HashMap<Integer, DataStructure>> sortedNameMap = new HashMap<String, HashMap<Integer, DataStructure>>();
		for (DataStructure objectSet : dat.getHybridTrajectoryMap().keySet()) {
			if (!sortedNameMap.containsKey(objectSet.properties().getName())) {
				sortedNameMap.put(objectSet.properties().getName(), new HashMap<Integer, DataStructure>());
			}
			sortedNameMap.get(objectSet.properties().getName()).put(objectSet.properties().getIndex(), objectSet);
		}
		ArrayList<String> objectNames = new ArrayList<String>(sortedNameMap.keySet());
		Collections.sort(objectNames);
		for (String name : objectNames) {
			HashMap<Integer, DataStructure> sortedObjects = sortedNameMap.get(name);
			ArrayList<Integer> objectIndicies = new ArrayList<Integer>(sortedObjects.keySet());
			Collections.sort(objectIndicies);
			for (Integer obInd : objectIndicies) {
				sortedSets.add(sortedObjects.get(obInd));
			}
		}
		return sortedSets;

	}

	/**
	 * Populates the series list map with all of the data from the specified
	 * trajectory set
	 * 
	 * @param data
	 *            data to populate list with
	 */
	public static void populateListMap(TrajectorySet data) {

		seriesListMap.put(data, new ArrayList<HybridTrajectoryElement<?>>());
		for (HybridTrajectoryInterface<?> arc : DataCollector.getHybridTrajectoryMap(data).values()) {
			for (HybridTrajectoryElement<?> series : arc.getData().values()) {
				if (!seriesListMap.get(data).contains(series)) {
					seriesListMap.get(data).add(series);
				}
			}
		}
	}

	/**
	 * Store the current value of the data element
	 * 
	 * @param data
	 *            trajectory element where data will be stored
	 * @param value
	 *            value to store
	 * @param <X>
	 *            specific class of stored data element
	 */
	public static <X> void storeData(HybridTrajectoryElement<X> data, X value) {

		data.getAllStoredData().add(value);
	}

	/**
	 * Stores the object into an array of T elements
	 * 
	 * @param allStoredData
	 *            list of objects where value will be stored
	 * @param parseString
	 *            value to store
	 * @param <T>
	 *            specific class of stored data element
	 */
	@SuppressWarnings("unchecked")
	public static <T extends Object> void storeDataGeneral(ArrayList<T> allStoredData, Object parseString) {

		allStoredData.add((T) parseString);
	}

	/**
	 * Store the current value of to the the data element
	 * 
	 * @param data
	 *            trajectory element where value will be stored
	 * @param value
	 *            value to store
	 * 
	 * @param <X>
	 *            specific class of stored data element
	 */
	@SuppressWarnings("unchecked")
	public static <X> void storeDataGeneral(HybridTrajectoryElement<X> data, Object value) {

		data.getAllStoredData().add((X) value);
	}

}
