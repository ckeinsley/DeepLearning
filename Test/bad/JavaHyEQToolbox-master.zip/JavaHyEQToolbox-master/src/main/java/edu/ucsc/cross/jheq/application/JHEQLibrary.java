
package edu.ucsc.cross.jheq.application;

import java.io.File;
import java.util.HashMap;

import com.be3short.io.xml.XMLParser;

import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.file.FileBrowser;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.function.JHEQFeature;
import edu.ucsc.cross.jheq.logging.Console;

public class JHEQLibrary {

	public JHEQConfiguration config;

	public HashMap<JHEQFeature, File> contentLib;

	HashMap<String, JHEQFeature> taskList;

	/**
	 * @return the taskList
	 */
	public HashMap<String, JHEQFeature> getTaskList() {

		return taskList;
	}

	public HashMap<String, String> labelToFileMap;

	private HashMap<File, Boolean> rootFiles;

	public JHEQLibrary() {

		this(null);

	}

	public JHEQLibrary(File project) {

		this(project, true);
	}

	public JHEQLibrary(File project, boolean init) {

		if (rootFiles == null) {
			rootFiles = new HashMap<File, Boolean>();
		}
		if (contentLib == null) {
			contentLib = new HashMap<JHEQFeature, File>();
		}
		if (taskList == null) {
			taskList = new HashMap<String, JHEQFeature>();
		}

		initialize(project);
	}

	private void getConfig(File project) {

		if (project == null) {
			config = JHEQConfiguration.fetch();
		} else {
			config = JHEQConfiguration.fetch(project);
		}
	}

	public void initialize(File project) {

		getConfig(project);
		processFile(new File("tasks"));
		// setupContentIndex();
		setupContentLib();

	}

	private void setupContentLib() {

		if (config == null) {

			config = JHEQConfiguration.fetch();
		}
		for (File rootFile : rootFiles.keySet()) {
			processFile(rootFile, rootFile);
		}
	}

	private HashMap<File, Boolean> setupRootFiles() {

		HashMap<File, Boolean> files = new HashMap<File, Boolean>();
		for (String filePath : config.getFeaturePathVisibility().keySet()) {
			File file = new File(filePath);
			if (file.exists()) {
				if (file.isDirectory()) {
					files.put(file, config.isPathVisible(filePath));
				}
			}
		}
		return files;
	}

	public void runContent(String label, JHEQEnvironment env, String input, JHEQToolbox app) {

		JHEQFeature cg = taskList.get(label);
		cg.perform(app, input);
	}

	public boolean isInRoot(File root, File file) {

		for (File fil : root.listFiles()) {
			if (file.equals(fil)) {
				return true;
			}
		}
		return false;
	}

	public String getPrefix(File root, File file) {

		File backTrack = file;
		String pr = "";
		if (!isInRoot(root, file)) {
			pr = "/";
		}
		pr += file.getName();
		while (!isInRoot(root, backTrack)) {
			pr = "/" + backTrack.getParentFile().getName() + pr;
			backTrack = backTrack.getParentFile();
		}
		return pr;

	}

	public void processFile(File root, File file) {

		try {
			if (file.isDirectory()) {
				for (File sub : file.listFiles()) {
					processFile(root, sub);
				}
			} else {
				try {
					if (file.getName().substring(file.getName().length() - 4).equals(".xml")) {

						JHEQFeature generator = loadFeature(file);
						if (generator != null) {
							contentLib.put((JHEQFeature) generator, file);

						}
					}
				} catch (Exception end) {
					Console.debug("failed to load " + file.getPath());
				}
			}
		} catch (Exception unknown) {
			Console.debug("unknown file error " + file.getPath(), unknown);
		}

	}

	public void processFile(File root) {

		rootFiles.put(root, true);

		processFile(root, root);

	}

	public static JHEQFeature loadFeature(File file) {

		JHEQFeature generator = null;
		try {
			generator = XMLFileTools.loadContent(JHEQFeature.class, file);
			Console.debug("succesfully loaded " + file);
		} catch (Exception end) {

			Console.debug("failed to load " + file, end);
		}

		return generator;
	}

	public static void addNewFeature(String package_name, String destination) {

		addNewFeature(package_name, new File(destination));
	}

	public static void addNewFeature(String package_name, File destination) {

		if (destination == null) {

			destination = FileBrowser.save("Specify the file to store the feature");
		}
		try {
			JHEQFeature generator = (JHEQFeature) ClassLoader.getSystemClassLoader().loadClass(package_name)
					.newInstance();
			XMLFileTools.save(generator, destination);
			Console.debug("succesfully loaded " + generator);
		} catch (Exception end) {
			Console.debug("failed to load " + package_name);
		}
	}

	public HashMap<String, JHEQFeature> setupContentIndex() {

		taskList = new HashMap<String, JHEQFeature>();

		for (JHEQFeature generator : contentLib.keySet()) {

			taskList.put(generator.getCallHandle(), generator);

		}
		return taskList;
	}

	public void execute(String label, JHEQEnvironment environment, String input, JHEQToolbox app) {

		Console.debug("executing " + label + " with arguments " + input.toString());
		try {
			if (contentLib.containsKey(label)) {
				JHEQFeature generator = loadFeature(contentLib.get(label));
				if (generator != null) {
					generator.perform(app, input);
				}
			}
			// if (taskList.containsKey(label)) {
			// taskList.get(label).perform(app, input);
			// }
		} catch (

		Exception end) {
			Console.debug("failed to execute " + label + " with input " + input);
		}

	}

	/**
	 * @return the rootFiles
	 */
	public HashMap<File, Boolean> getRootFiles() {

		return rootFiles;
	}

	public static void main(String args[]) {

		File file = FileBrowser.save();
		JHEQLibrary jheqDB = new JHEQLibrary(file);
		System.out.println(XMLParser.serializeObject(jheqDB));
	}

	/**
	 * @return the config
	 */
	public JHEQConfiguration getConfig() {

		return config;
	}

	/**
	 * @param config
	 *            the config to set
	 */
	public void setConfig(JHEQConfiguration config) {

		this.config = config;
	}

}
