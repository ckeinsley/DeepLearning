/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * ------------------------------------------------
 * Connection.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 * 06-August-2018 : Version 2 - redesigned as class instead of interface (BS);
 *
 */

package edu.ucsc.cross.jheq.network;

import java.util.ArrayList;

import org.jgrapht.EdgeFactory;

import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.object.DataStructure;

/**
 * The basic connection is a graph edge that directly connects two objects of
 * class N.
 * 
 * Intended Operator: User
 * 
 * @param <S>
 *            The type of objects that are connected
 */
public class Connection<S, T> extends DataStructure implements EdgeFactory<Object, Connection<S, T>> {

	public static Integer BIDIRECTIONAL = 0;

	public static Integer INCOMING = 1;

	public static Integer OUTGOING = -1;

	/*
	 * Source vertex
	 */
	private S source;

	/*
	 * Target vertex
	 */
	private T target;

	/**
	 * List of connection properties
	 */
	private ArrayList<Object> properties;

	/**
	 * Constructor for the connection from specified source to destination
	 * 
	 * @param sourceVertex
	 *            start vertex
	 * @param targetVertex
	 *            end vertex
	 */
	public Connection(S sourceVertex, T targetVertex) {

		this.source = sourceVertex;
		this.target = targetVertex;
		properties = new ArrayList<Object>();

	}

	/**
	 * Get source vertex
	 * 
	 * @return source vertex
	 */
	public S getSource() {

		return source;
	}

	/**
	 * Get target vertex
	 * 
	 * @return target vertex
	 */
	public T getTarget() {

		return target;
	}

	/**
	 * @return the connection properties
	 */
	public ArrayList<Object> getProperties() {

		return properties;
	}

	/**
	 * @param properties
	 *            the properties to set
	 */
	public void setProperties(ArrayList<Object> properties) {

		this.properties = properties;
	}

	/**
	 * Add properties
	 * 
	 * @param properties
	 *            list of properties to add
	 */
	public void addProperties(Object... properties) {

		for (Object property : properties) {
			try {

				if (!this.properties.contains(property)) {
					this.properties.add(properties);
				}
			} catch (Exception badProperty) {
				Console.error("unable to add property " + property + " to connection " + this, badProperty);
			}
		}
	}

	/**
	 * Get property
	 * 
	 * @param <T>
	 *            property class
	 * 
	 * @param property_class
	 *            class of property to be retrieved
	 */
	public <P> P getProperty(Class<P> property_class) {

		for (Object property : properties) {
			if (property.getClass().equals(property_class)) {
				return property_class.cast(property);
			}
		}
		return null;
	}

	/**
	 * Creates a new edge whose endpoints are the specified source and target
	 * vertices.
	 *
	 * @param sourceVertex
	 *            the source vertex.
	 * @param targetVertex
	 *            the target vertex.
	 *
	 * @return a new edge whose endpoints are the specified source and target
	 *         vertices.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Connection<S, T> createEdge(Object sourceVertex, Object targetVertex) {

		Connection<S, T> connection = null;
		try {
			Connection<S, T> connectionAtt = new Connection<S, T>((S) sourceVertex, (T) targetVertex);
			connection = connectionAtt;
		} catch (Exception badType) {
			Console.error("unable to establish a connection between " + sourceVertex + " and " + targetVertex, badType);
		}
		return connection;

	}

}