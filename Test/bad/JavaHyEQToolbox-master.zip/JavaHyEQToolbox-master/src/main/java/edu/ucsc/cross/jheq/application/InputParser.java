
package edu.ucsc.cross.jheq.application;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class InputParser {

	public String fullInput;

	public static final String inputLine = ">>> ";

	public static String arraySeparator = ";";

	public static String argumentDefiner = "-";

	public static ArrayList<ParsedInput> getInputs(String parse_line) {

		String full = parse_line;
		String[] multi = getMultiCommand(full);

		return getInput(multi);
	}

	public static String[] getMultiCommand(String full_input) {

		String[] multiCommand =
			{ full_input };
		if (full_input.contains(arraySeparator)) {
			multiCommand = full_input.split(Pattern.quote(arraySeparator));
		}
		return multiCommand;

	}

	public static ArrayList<ParsedInput> getInput(String[] multi_command) {

		ArrayList<ParsedInput> inputs = new ArrayList<ParsedInput>();
		if (multi_command.length > 0) {
			for (String command : multi_command) {

				String index = command.split(" ")[0];
				String arguments = command.substring(index.length());
				ParsedInput ui = new ParsedInput(index, arguments);
				inputs.add(ui);
			}
		}
		return inputs;
	}

	/**
	 * @return the inputLine
	 */
	public static String getInputLine() {

		return inputLine;
	}

}
