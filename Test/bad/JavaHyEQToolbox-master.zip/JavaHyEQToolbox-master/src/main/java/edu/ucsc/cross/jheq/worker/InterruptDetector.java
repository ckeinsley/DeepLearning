/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * InterruptDetector.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.worker;

import org.apache.commons.math3.ode.events.EventHandler;

import edu.ucsc.cross.jheq.logging.ConsoleUtils;

/**
 * Continuously monitors the environment to interrupt the execution when the
 * time or jump threshold is reached, or a manual halt has been requested. This
 * allows the ODE to stop automatically without input from the engine.
 * 
 * Intended Operator: System
 */
public class InterruptDetector implements EventHandler {

	/**
	 * Unix time in milliseconds when the execution was terminated
	 */
	private Double endTime;

	/**
	 * Engine supervisor of this instance
	 */
	private EngineSupervisor manager; // manager of the environment

	/**
	 * Flag indicating if the system is paused
	 */
	private boolean paused;

	/**
	 * Constructor to link the environment
	 * 
	 * @param manager
	 *            Engine supervisor of this instance
	 */
	public InterruptDetector(EngineSupervisor manager) {

		this.manager = manager;
		paused = false;
		init(0.0, new double[] { 0.0 }, 0.0);
	}

	/**
	 * Response that occurs when event is detected
	 */
	@Override
	public EventHandler.Action eventOccurred(double t, double[] y, boolean increasing) {

		return EventHandler.Action.STOP; // Terminate integrator

	}

	/**
	 * The Threshold checking method that will trigger an interrupt
	 * 
	 * @param t
	 *            current simulation time
	 * @param y
	 *            vector of values received from the integrator
	 */
	@Override
	public double g(double t, double[] y) {

		ConsoleUtils.printInfoStatus(manager);
		if (isRunning()) {
			return 1;
		} else {
			return -1;
		}
	}

	/**
	 * Initializes the event handler
	 * 
	 * @param t0
	 *            initial simulation time
	 * 
	 * @param y0
	 *            initial vector of values
	 * 
	 * @param t
	 *            current simulation time
	 * 
	 */
	@Override
	public void init(double t0, double[] y0, double t) {

		endTime = manager.getEnvironmentSettings().maximumTime;
	}

	/**
	 * Check if the system is paused
	 * 
	 * @return true if paused, otherwise false
	 */
	public boolean isPaused() {

		return paused;
	}

	/**
	 * Performs actions necessary to reset the state after a jump has occurred.
	 *
	 * @return true if simulation is running, false otherwise
	 */
	public boolean isRunning() {

		return !paused && !thresholdReached();
	}

	/**
	 * Perform actions when termination occurs (nothing)
	 * 
	 * @param t
	 *            current simulation time
	 * @param y
	 *            vector of values received from the integrator
	 */
	@Override
	public void resetState(double t, double[] y) {

	}

	/**
	 * Pause or unpause the system
	 * 
	 * @param paused
	 *            flag indicating whether to pause or unpause
	 */
	public void setPaused(boolean paused) {

		this.paused = paused;
	}

	/**
	 * Check if a threshold has been reached
	 * 
	 * @return true if threshold reached, false otherwise
	 */
	public boolean thresholdReached() {

		Double timeOverThreshold = manager.getObjectManipulator().getSimulationTime() - endTime;
		Integer jumpsOverThreshold = manager.getObjectManipulator().getHybridSimTime().getJumps()
				- manager.getEnvironmentSettings().maximumJumps;
		if (timeOverThreshold >= 0 || jumpsOverThreshold >= 0) {
			return true;
		} else {
			return false;
		}
	}
}
