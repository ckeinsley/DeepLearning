
package edu.ucsc.cross.jheq.variable;

public class FixedVariable<X> implements Variable<X> {

	public X value;

	@Override
	public X getValue() {

		// TODO Auto-generated method stub
		return value;
	}

	public static <Z> FixedVariable<Z> create(Class<Z> var_class) {

		return new FixedVariable<Z>();
	}
}
