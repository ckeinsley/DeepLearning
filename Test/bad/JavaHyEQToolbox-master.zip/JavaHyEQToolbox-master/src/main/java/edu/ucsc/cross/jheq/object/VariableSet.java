
package edu.ucsc.cross.jheq.object;

import java.util.ArrayList;
import java.util.Arrays;

import com.be3short.obj.access.FieldFinder;

public class VariableSet {

	private ArrayList<Object> variables;

	public VariableSet() {

		variables = new ArrayList<Object>();

	}

	public VariableSet(Object[] vars) {

		variables = new ArrayList<Object>(Arrays.asList(vars));

	}

	public <T> T get(Class<T> var_class) {

		return get(var_class, false, null, IndexedObject.NONE);
	}

	private <T> T get(Class<T> obj_class, boolean exact_class, ArrayList<T> multi_get, Object[] index) {

		T var = null;
		for (Object param : variables) {
			if (matchClass(obj_class, param, exact_class)) {
				try {

					if (IndexedObject.containsKey(param, index)) {
						var = obj_class.cast(param);
						updateList(var, multi_get);
						if (multi_get == null) {
							return var;
						}
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}
		return var;
	}

	public <T> T get(Class<T> obj_class, Object[] index) {

		return get(obj_class, false, null, index);
	}

	public <T> ArrayList<T> getAll(Class<T> obj_class) {

		return getAll(obj_class, false, null);

	}

	private <T> ArrayList<T> getAll(Class<T> obj_class, boolean exact_class, Object[] index) {

		ArrayList<T> vars = new ArrayList<T>();
		get(obj_class, exact_class, vars, index);
		return vars;
	}

	public <T> ArrayList<T> getAll(Class<T> obj_class, Object[] index) {

		return getAll(obj_class, false, index);

	}

	public <T> ArrayList<T> getAllExact(Class<T> obj_class) {

		return getAll(obj_class, true, null);

	}

	public <T> ArrayList<T> getAllExact(Class<T> obj_class, Object[] index) {

		return getAll(obj_class, true, index);

	}

	public <T> T getExact(Class<T> obj_class) {

		return get(obj_class, true, null, IndexedObject.NONE);
	}

	public <T> T getExact(Class<T> obj_class, Object[] index) {

		return get(obj_class, true, null, index);
	}

	/**
	 * @return the variables
	 */
	public ArrayList<Object> getVariables() {

		return variables;
	}

	public boolean contains(Object object) {

		return getVariables().contains(object);
	}

	public static <P> boolean matchClass(Class<P> param_class, Object object, boolean exact) {

		if (exact) {
			return object.getClass().equals(param_class);
		} else {
			return FieldFinder.containsSuper(object, param_class);
		}
	}

	public static <P> boolean updateList(P object, ArrayList<P> list) {

		boolean continueSearch = false;
		if (list != null) {
			continueSearch = true;
			if (!list.contains(object)) {
				list.add(object);
			}
		}
		return continueSearch;
	}

	public static VariableSet create(Object... objects) {

		VariableSet vars = new VariableSet();
		for (Object obj : objects) {
			if (!vars.contains(obj))

			{
				vars.getVariables().add(obj);
			}

		}
		return vars;
	}
}
