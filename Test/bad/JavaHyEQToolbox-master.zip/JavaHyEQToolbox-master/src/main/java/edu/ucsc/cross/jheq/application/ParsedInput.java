
package edu.ucsc.cross.jheq.application;

public class ParsedInput {

	public String command;

	public String arguments;

	public ParsedInput(String command, String arguments) {

		this.command = command;
		this.arguments = arguments;
	}

	/**
	 * @return the command
	 */
	public String getCommand() {

		return command;
	}

	/**
	 * @return the arguments
	 */
	public String getArguments() {

		return arguments;
	}

	@Override
	public String toString() {

		if (arguments.length() <= 0.0) {
			return "[" + command + "] with no arguments";
		} else {
			return "[" + command + "] with arguments : " + arguments;
		}
	}
}
