/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * ConsoleSettings.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.logging;

/**
 * Console settings that define how the console and logging behave.
 * 
 * Intended Operator: User
 */
public class ConsoleSettings {

	/**
	 * Print warning messages
	 */
	public static String debugLabel = "debug";

	/**
	 * Print warning messages
	 */
	public static String defaultOutputDirectory = "log";

	/**
	 * Print dev messages
	 */
	public static String devLabel = "dev";

	/**
	 * Print warning messages
	 */
	public static String errorLabel = "error";

	/**
	 * Print warning messages
	 */
	public static String infoLabel = "info";

	/**
	 * Print warning messages
	 */
	public static String warnLabel = "warn";

	/**
	 * Print debug messages.
	 */
	public boolean printDebug;

	/**
	 * Print error messages.
	 */
	public boolean printError;

	/**
	 * Print information messages.
	 */
	public boolean printInfo;

	/**
	 * Print integrator exception warnings.
	 */
	public boolean printIntegratorExceptions;

	/**
	 * Print console log to file.
	 */
	public boolean printLogToFile;

	/**
	 * Total number of progress updates to print, ie 10 prints an update at 10%
	 * intervals. -1 disables progress update print outs.
	 */
	public Integer printProgressIncrement;

	/**
	 * Interval between status print outs.
	 */
	public Double printStatusInterval;

	/**
	 * Print warning messages.
	 */
	public boolean printWarning;

	/**
	 * Flag to terminate environment execution when user input is received from
	 * console
	 */
	public boolean terminateAtInput;

	public ConsoleSettings() {

		printStatusInterval = 5.0;
		printProgressIncrement = 10;
		printIntegratorExceptions = false;
		printInfo = true;
		printDebug = false;
		printWarning = true;
		printError = true;
		printLogToFile = true;
		terminateAtInput = true;
	}

}
