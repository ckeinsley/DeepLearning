
package edu.ucsc.cross.jheq.builder;

import java.io.File;
import java.util.HashMap;

import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.file.FileBrowser;
import edu.ucsc.cross.jheq.file.SwingFileBrowser;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.function.JHEQOperation;
import edu.ucsc.cross.jheq.function.JHEQTemplate;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.object.DataStructure;

public class ContentDefinition extends JHEQOperation implements JHEQTemplate {

	public HashMap<String, String> globalVariableClassMap;

	public HashMap<String, SystemDefinition> systemDefinitionMap;

	public String[] postProcessingTaskFilePaths;

	public String importFilePath;

	public ContentDefinition() {

		super();
		globalVariableClassMap = new HashMap<String, String>();
		globalVariableClassMap.put("variableKey", "edu.ucsc.cross.jheq.core.object.DataStructure");
		systemDefinitionMap = new HashMap<String, SystemDefinition>();
		systemDefinitionMap.put("systemKey", new SystemDefinition());
		postProcessingTaskFilePaths = new String[]
			{ "" };

	}

	@Override
	public void perform(JHEQToolbox app, String input) {

		if (importFilePath != null) {
			preSet(app.getEnvironment(), input);
		} else {
			ContentBuilder gen = new ContentBuilder();
			try {
				File componentPathz = FileBrowser.save("Create the generator task file");

				String resources = (FileBrowser.getRelativeFilePath(componentPathz.getAbsoluteFile()));
				resources = resources.substring(app.getDatabase().config.getRootFilePath().length());
				File resourcez = new File(
						app.getDatabase().config.getRootFilePath() + "resources/" + resources.split(".xml")[0]);
				setupGlobalGens(gen, resourcez);
				setupAdjacency(gen);
				setupSystems(gen, resourcez, app);
				gen.postProcessingTaskFilePaths = postProcessingTaskFilePaths;
				// gen.functionCallLabel = componentPathz.getName().split(".xml")[0];
				gen.setCallHandle(componentPathz.getName());

				XMLFileTools.save(gen, componentPathz);

			} catch (Exception badPath) {
				badPath.printStackTrace();
			}
		}

	}

	public <S extends DataStructure, L, Q> void preSet(JHEQEnvironment env, String input) {

		File componentPathz = FileBrowser.directory("Select a directory for the components");

		ContentBuilder gen = XMLFileTools.loadContent(ContentBuilder.class, new File(importFilePath));

		for (String globalVar : gen.systemBuilderMap.keySet()) {
			try {
				SystemBuilder<?> stateClass = gen.systemBuilderMap.get(globalVar);
				SystemBuilder<?> stateClassL = XMLFileTools.loadContent(SystemBuilder.class,
						new File(stateClass.importFilePath));
				File directory = new File(componentPathz, globalVar + ".xml");
				XMLFileTools.save(stateClassL, directory);
				gen.systemBuilderMap.get(globalVar).importFilePath = directory.getPath();
			} catch (Exception badPath) {
				Console.warn(badPath.getMessage());
			}
		}
		for (String system : gen.globalVariableBuilderMap.keySet()) {
			File file = new File(componentPathz, system + ".xml");
			ObjectBuilder<?> objGen = gen.globalVariableBuilderMap.get(system);
			ObjectBuilder<?> cop = XMLFileTools.loadContent(ObjectBuilder.class, new File(objGen.getImportFilePath()));
			XMLFileTools.save(cop, file);
			cop.setImportFilePath(file.getAbsolutePath());
			gen.globalVariableBuilderMap.get(system).importFilePath = file.getPath();

		}
		File appPath = SwingFileBrowser.save("Select a directory for the components");
		gen.setCallHandle(appPath.getName());

		XMLFileTools.save(gen, new File(appPath.getPath() + ".xml"));

	}

	public void setupAdjacency(ContentBuilder gen) {

		int[][] adjacency = new int[this.systemDefinitionMap.size()][this.systemDefinitionMap.size()];
		String[] vert = new String[this.systemDefinitionMap.size()];
		int i = 0;
		for (String globalVar : this.systemDefinitionMap.keySet()) {
			vert[i++] = globalVar;
		}
		gen.vertexSet = vert;
		gen.adjacencyMatrix = adjacency;
	}

	public void setupSystems(ContentBuilder gen, File componentPathz, JHEQToolbox database) {

		for (String globalVar : this.systemDefinitionMap.keySet()) {
			try {
				SystemDefinition stateClass = this.systemDefinitionMap.get(globalVar);
				SystemBuilder<?> sysGen = stateClass.createGenerator();

				File directory = new File(FileBrowser.getRelativeFilePath(componentPathz) + "/" + globalVar + ".xml");
				XMLFileTools.save(sysGen, directory);
				sysGen = SystemBuilder.instantiate();
				sysGen.importFilePath = FileBrowser.getRelativeFilePath(componentPathz) + "/" + globalVar + ".xml";
				gen.systemBuilderMap.put(globalVar, sysGen);
			} catch (Exception badPath) {
				badPath.printStackTrace();
			}
		}
	}

	public void setupGlobalGens(ContentBuilder gen, File componentPathz) {

		for (String globalVar : this.globalVariableClassMap.keySet()) {
			if (globalVar != null) {
				if (!globalVar.equals("")) {
					try {
						String stateClass = globalVariableClassMap.get(globalVar);
						Object state = ClassLoader.getSystemClassLoader().loadClass(stateClass).newInstance();
						ObjectBuilder<Object> obGen = new ObjectBuilder<Object>(state);

						File directory = new File(
								FileBrowser.getRelativeFilePath(componentPathz) + "/" + globalVar + ".xml");
						XMLFileTools.save(obGen, directory);
						obGen = new ObjectBuilder<Object>(
								FileBrowser.getRelativeFilePath(componentPathz) + "/" + globalVar + ".xml");

						gen.globalVariableBuilderMap.put(globalVar, obGen);
					} catch (Exception badPath) {
						badPath.printStackTrace();
					}
				}
			}
		}
	}

	public Object createInstance(String class_path) {

		try {
			return ClassLoader.getSystemClassLoader().loadClass(class_path).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static <T> T createInstance(Class<T> class_type, String class_path) {

		try {
			return class_type.cast(ClassLoader.getSystemClassLoader().loadClass(class_path).newInstance());
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void createTemplate(File directory) {

		XMLFileTools.save(new ContentDefinition(), new File(directory, "/tasks/contentDefinition.xml"));

	}

}
