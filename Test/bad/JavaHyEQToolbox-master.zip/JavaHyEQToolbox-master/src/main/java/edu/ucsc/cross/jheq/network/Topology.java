/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * ------------------------------------------------
 * Topology.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 08-August-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.network;

import java.util.HashMap;
import java.util.Set;

import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.graph.AsWeightedDirectedGraph;
import org.jgrapht.graph.DirectedPseudograph;
import org.jgrapht.graph.GraphDelegator;

/**
 * A graph backed by the the graph specified at the constructor, which delegates
 * all its methods to the backing graph. Operations on this graph "pass through"
 * to the to the backing graph. Any modification made to this graph or the
 * backing graph is reflected by the other.
 * 
 * Intended Operator: User
 *
 * @param <Object>
 *            Node type of the graph
 */
public class Topology extends GraphDelegator<Object, Connection<Object, Object>> {

	/**
	 * Serial id
	 */
	private static final long serialVersionUID = 8948004857528207396L;

	/**
	 * flag indicating if graph is directed or undirected
	 */
	private boolean directed;

	/**
	 * Constructs a new directed or undirected topology as pseudograph
	 * 
	 * @param directed
	 *            flag indicating if graph is directed or undirected
	 */
	public Topology(boolean directed) {

		super(new AsWeightedDirectedGraph<Object, Connection<Object, Object>>(
				new DirectedPseudograph<Object, Connection<Object, Object>>(new Connection<Object, Object>(null, null)),
				new HashMap<Connection<Object, Object>, Double>()));
		this.directed = directed;
	}

	/**
	 * Constructs a new directed or undirected topology as specified graph type
	 * 
	 * @param directed
	 *            flag indicating if graph is directed or undirected
	 * 
	 * @param graph
	 *            type of directed graph to use
	 */
	public Topology(boolean directed, Graph<Object, Connection<Object, Object>> graph) {

		super(graph);

		this.directed = directed;
	}

	/**
	 * Returns the degree of the specified vertex.
	 *
	 * @param vertex
	 *            vertex whose degree is to be calculated
	 * @return the degree of the specified vertex
	 * @see UndirectedGraph#degreeOf(Object)
	 */
	@Override
	public int degreeOf(Object vertex) {

		if (directed) {
			return inDegreeOf(vertex) + outDegreeOf(vertex);
		} else {
			return super.degreeOf(vertex);
		}
	}

	/**
	 * Returns a set of all edges outgoing from the specified vertex.
	 *
	 * @param vertex
	 *            the vertex for which the list of outgoing edges to be returned
	 * @return a set of all edges outgoing from the specified vertex
	 * @see DirectedGraph#outgoingEdgesOf(Object)
	 */
	@Override
	public Set<Connection<Object, Object>> outgoingEdgesOf(Object vertex) {

		if (directed) {
			return super.outgoingEdgesOf(vertex);
		} else {
			return super.edgesOf(vertex);
		}
	}

	/**
	 * Returns a set of all edges outgoing from the specified vertex.
	 *
	 * @param vertex
	 *            the vertex for which the list of outgoing edges to be returned
	 * @return a set of all edges outgoing from the specified vertex
	 * @see DirectedGraph#outgoingEdgesOf(Object)
	 */
	@Override
	public Set<Connection<Object, Object>> incomingEdgesOf(Object vertex) {

		if (directed) {
			return super.incomingEdgesOf(vertex);
		} else {
			return super.edgesOf(vertex);
		}
	}

	/**
	 * @return the directed
	 */
	public boolean isDirected() {

		return directed;
	}
}
