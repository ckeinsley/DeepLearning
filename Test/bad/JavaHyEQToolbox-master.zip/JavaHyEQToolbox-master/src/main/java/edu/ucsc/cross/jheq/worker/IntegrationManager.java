/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ IntegrationManager.java
 * ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.worker;

import org.apache.commons.math3.ode.FirstOrderIntegrator;

import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.specification.JumpStatus;

/**
 * Executes and monitors an instance of the Hybrid Environment. Errors are
 * caught and handled accordingly to keep environment running and protect result
 * data if a fatal error occurs.
 * 
 * Intended Operator: System
 */
public class IntegrationManager {

	/**
	 * Engine supervisor operating this integration manager
	 */
	private EngineSupervisor manager;

	/**
	 * Constructs the integration manager
	 * 
	 * @param manager
	 *            engine supervisor in charge
	 */
	public IntegrationManager(EngineSupervisor manager) {

		this.manager = manager;

	}

	/**
	 * Starts an execution of the current environment
	 */
	public void start() {

		// create the integrator
		FirstOrderIntegrator integrator = prepareIntegrator();
		// store the initial state values
		manager.getDataManager().storeNewData(manager.getObjectManipulator().getHybridSimTime().getTime());
		// get the start time
		double simulationTime = manager.getObjectManipulator().getHybridSimTime().getTime();
		// get the maximum simulation time
		double endTime = manager.getEnvironmentSettings().maximumTime;
		toggleObjectUpdate(true);
		// Run the integrator until thresholds reached or interrupted
		while (manager.getInterruptDetector().isRunning() || simulationTime > endTime) {

			simulationTime = runIntegrator(integrator, endTime);

		}
		toggleObjectUpdate(false);
		// store the final state values
		manager.getDataManager().performDataActions(simulationTime,
				manager.getObjectManipulator().getSimulatedObjectValueVector(), JumpStatus.NO_JUMP, true);
	}

	public void toggleObjectUpdate(boolean auto_update) {

		for (HybridSystem sys : manager.getEnvironment().getSystems().getSystems()) {
			sys.model().setAutoUpdateMaps(auto_update);
		}
	}

	/**
	 * Instantiates the simulation integrator based on the current settings
	 * 
	 * @return new integrator
	 */
	protected FirstOrderIntegrator prepareIntegrator() {

		// create integrator from settings
		FirstOrderIntegrator integrator = manager.getEnvironment().getSettings().integrator.createIntegrator();
		// clear any loaded event handlers
		integrator.clearEventHandlers();
		// add domain monitor to integrator
		integrator.addEventHandler(manager.getDomainMonitor(),
				manager.getEnvironmentSettings().eventHandlerMaximumCheckInterval,
				manager.getEnvironmentSettings().eventHandlerConvergenceThreshold,
				manager.getEnvironmentSettings().maxEventHandlerIterations);
		// add interrupt detector to integrator
		integrator.addEventHandler(manager.getInterruptDetector(), .1, .1, 10);
		return integrator;
	}

	/**
	 * Executes the integrator recursively, calling itself after an error occurs or
	 * returning the end time if the maximum recursion level has been reached.
	 * 
	 * @param integrator
	 *            - integrator to be used
	 * 
	 * @param recursion_level
	 *            - number of times that the method has been called by itself
	 * 
	 * @param end_time
	 *            time to stop integration
	 * 
	 * @return final time of integrator
	 * 
	 */
	public Double runIntegrator(FirstOrderIntegrator integrator, Double end_time) {

		// initialize stop time variable
		Double stopTime = end_time;
		try {
			// check if integrator is still supposed to be running
			if (manager.getInterruptDetector().isRunning()) {

				Console.debug("starting integrator : t0 = "
						+ manager.getObjectManipulator().getHybridSimTime().getTime() + " , tf = " + end_time);

				// get the odes
				EquationMap ode = manager.getODEInterface();
				// get current simulation time
				Double time = manager.getObjectManipulator().getHybridSimTime().getTime();
				// get the current state value vector
				double[] state = manager.getObjectManipulator().updateValueVector(null);
				// start integrator

				stopTime = integrator.integrate(ode, time, state, end_time, state);
			}
			return stopTime;

		} // integrator exception has occurred
		catch (Exception integratorException) {

			if (Console.getSettings().printIntegratorExceptions) {
				Console.warn("integrator exception", integratorException);
			}
			return manager.getObjectManipulator().getHybridSimTime().getTime();
		}

	}

}
