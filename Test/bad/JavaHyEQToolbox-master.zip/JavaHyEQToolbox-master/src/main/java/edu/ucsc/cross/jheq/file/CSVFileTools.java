/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ CSVFileCompiler.java
 * ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.file;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import com.be3short.io.general.FileSystemInteractor;

import edu.ucsc.cross.jheq.environment.EnvironmentContents;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.object.DataStructure;
import edu.ucsc.cross.jheq.trajectory.HybridTime;
import edu.ucsc.cross.jheq.trajectory.HybridTrajectory;
import edu.ucsc.cross.jheq.trajectory.HybridTrajectoryElement;
import edu.ucsc.cross.jheq.trajectory.HybridTrajectoryInterface;
import edu.ucsc.cross.jheq.trajectory.TrajectorySet;
import edu.ucsc.cross.jheq.worker.DataCollector;

/**
 * A File compiler that compiles the specified trajectories into CSV format.
 * Loading stored CSV data is not supported, please use the XML or HSE file
 * formats if you intend to reload data later.
 * 
 * Intended Operator: System
 */
public class CSVFileTools {

	/**
	 * Collection of print writers
	 */
	private static HashMap<CSVFileTools, PrintWriter> writers = new HashMap<CSVFileTools, PrintWriter>();

	/**
	 * Trajectory data set
	 */
	private TrajectorySet data;

	/**
	 * List of all hybrid trajectory elements to output
	 */
	private ArrayList<HybridTrajectoryElement<?>> seriesList;

	/**
	 * Constructor for the compiler
	 * 
	 * @param data
	 *            trajectory data set to output
	 * @param <T>
	 *            class of data structure corresponding to the hybrid trajectory
	 */
	public <T extends DataStructure> CSVFileTools(HybridTrajectory<T> data) {

		this.data = new TrajectorySet(new EnvironmentContents());
		this.data.getTimeDomain().addAll(data.getTimeDomain());
		DataCollector.getHybridTrajectoryMap(this.data).put(data.getDataPoint(null),
				new HybridTrajectoryInterface<T>(data));
	}

	/**
	 * Constructor for the compiler
	 * 
	 * @param data
	 *            trajectory data set to output
	 */
	public CSVFileTools(TrajectorySet data) {

		this.data = data;
		seriesList = new ArrayList<HybridTrajectoryElement<?>>();
	}

	/**
	 * Create the CSV output file
	 * 
	 * @param file
	 *            location of output
	 */
	public void createCSVOutput(File file) {

		prepareFileWriter(file);

		fileOut().println(createHeader());
		fileOut().flush();
		for (Integer index = 0; index < data.getTimeDomain().size(); index++) {
			String line = getLineIntro(index);
			HybridTime time = data.getTimeDomain().get(index);
			for (HybridTrajectoryElement<?> data : seriesList) {
				if (data.getStoredData(time) == null) {
					line += ",";
				} else {
					line += "," + data.getStoredData(time).toString();
				}
			}
			fileOut().println(line);
			fileOut().flush();
		}

		fileOut().close();
	}

	/**
	 * Parse the header of the CSV file to a single string
	 * 
	 * @return header string
	 */
	public String createHeader() {

		String header = "time,jumps";
		String state = "Environment,Environment";
		seriesList = getSortedSeriesList();

		for (HybridTrajectoryElement<?> series : seriesList) {
			// header += "," + series.getChild().getName() + " (" +
			// series.getParent().getProperties().getIndexedName()
			// + ")";
			//
			header += "," + series.getChild().getName();
			state += "," + series.getParent().properties().getIndexedName();
		}

		return state + "\n" + header;
	}

	/**
	 * Get a new print file writer
	 * 
	 * @return the writer
	 */
	private PrintWriter fileOut() {

		PrintWriter fileOut = null;
		if (writers.containsKey(this)) {
			try {
				fileOut = writers.get(this);
			} catch (Exception e) {

			}
		}
		return fileOut;
	}

	/**
	 * Get the beginning of the next line with the time index
	 * 
	 * @param index
	 *            current time index number
	 * @return beginning of string
	 */
	private String getLineIntro(Integer index) {

		HybridTime time = data.getTimeDomain().get(index);
		String line = time.getTime() + "," + time.getJumps();
		return line;
	}

	/**
	 * Get a sorted list of the trajectory elements
	 * 
	 * @return list of sorted trajectory elements
	 */
	public ArrayList<HybridTrajectoryElement<?>> getSortedSeriesList() {

		ArrayList<HybridTrajectoryElement<?>> sortedTrajectories = new ArrayList<HybridTrajectoryElement<?>>();
		HashMap<DataStructure, HybridTrajectoryInterface<?>> dataMap = DataCollector.getHybridTrajectoryMap(data);
		for (DataStructure objectSet : DataCollector.getObjectSetListSortedByName(data)) {
			HybridTrajectoryInterface<?> trajectory = dataMap.get(objectSet);
			sortedTrajectories.addAll(trajectory.getDataListSortedByName());
		}
		return sortedTrajectories;
	}

	/**
	 * Prepare file writer to output CSV content
	 * 
	 * @param file
	 *            output location
	 */
	private void prepareFileWriter(File file) {

		try {
			File checkedFile = DataFormat.CSV.getUtilities().appendExtension(file);
			FileSystemInteractor.createOutputFile(checkedFile, "");
			writers.put(this, new PrintWriter(new FileOutputStream(file)));
		} catch (Exception e) {
			Console.warn("create csv file cancelled");
		}
	}

}
