/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * HybridTime.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.trajectory;

import edu.ucsc.cross.jheq.worker.EngineSupervisor;

/**
 * A hybrid time value time that includes the number of jumps that have
 * occurred.
 *
 * Intended Operator: User
 */
public class HybridTime {

	/**
	 * The jump handle used to select jump as one of the axes of a trajectory
	 */
	public static final String JUMP = "Jumps";

	/**
	 * The time handle used to select time as one of the axes of a trajectory
	 */
	public static final String TIME = "Time";

	/**
	 * The current jump index of this instance of hybrid time
	 */
	private int jumps;

	/**
	 * The current time value of this instance of hybrid time
	 */
	private double time;

	/**
	 * Create a hybrid time with the specified time and jump components
	 * 
	 * @param time
	 *            current time
	 * @param jumps
	 *            current jump count
	 */
	public HybridTime(double time, int jumps) {

		this.time = time;
		this.jumps = jumps;
	}

	/**
	 * Get the jump index component of this hybrid time
	 * 
	 * @return jump index
	 */
	public int getJumps() {

		return jumps;
	}

	/**
	 * Get the time component of this hybrid time
	 * 
	 * @return time
	 */
	public double getTime() {

		return time;
	}

	/**
	 * Determines if this hybrid time instance is equivalent to another hybrid time
	 * 
	 * @param hybrid_time
	 *            time to be checked for equivalence
	 * @return true if the specified time is equivalent to the current time (ie same
	 *         time and jumps), and false otherwise
	 */
	public boolean isEquivalent(HybridTime hybrid_time) {

		boolean equivalent = false;
		if (hybrid_time.getTime() == time && hybrid_time.getJumps() == jumps) {
			equivalent = true;
		}
		return equivalent;
	}

	/**
	 * Get the current environment jump count
	 * 
	 * @return environment time
	 */
	public static int getEnvironmentJumps() {

		return EngineSupervisor.getEngine().getEnvironmentTime().getJumps();
	}

	/**
	 * Get the current environment time
	 * 
	 * @return environment time
	 */
	public static double getEnvironmentTime() {

		return EngineSupervisor.getEngine().getEnvironmentTime().getTime();
	}
}
