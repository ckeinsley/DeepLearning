
package edu.ucsc.cross.jheq.ui;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class TitledPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 706033996238560562L;

	private TitledBorder border;

	public TitledPanel(String title, Color titleCol) {

		super();

		border = new TitledBorder(title);
		border.setTitleColor(titleCol);
		border.setBorder(new LineBorder(Color.white));
		setBorder(border);

	}

	public void setTitle(String title) {

		border.setTitle(title);
	}
}