/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ DynamicsEvaluator.java
 * ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.worker;

import com.be3short.io.xml.XMLParser;
import com.be3short.obj.manipulation.DynamicObjectManipulator;

import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.model.HybridSystemModel;
import edu.ucsc.cross.jheq.object.DataStructure;
import edu.ucsc.cross.jheq.specification.DomainPriority;

/**
 * The evaluation component that is responsible for preparing, applying, and
 * processing the dynamics for all systems.
 * 
 * Intended Operator: System
 */
public class DynamicsEvaluator {

	private boolean jumpPriority;

	public boolean isJumpPriority() {

		return jumpPriority;
	}

	/**
	 * Engine supervisor of this instance of dynamics evaluator
	 */
	private EngineSupervisor engine;

	/**
	 * Constructor that link a hybrid systems environment engine
	 * 
	 * @param engine
	 *            hybrid systems environment engine that is operating this component
	 */
	public DynamicsEvaluator(EngineSupervisor engine) {

		this.engine = engine;
		resetPriority();
	}

	/**
	 * Apply all hybrid system dynamics
	 * 
	 * @param jump_occurring
	 *            flag indicating if a jump is occurring and discrete dynamics
	 *            should be applied or if a flow is occurring
	 */
	public void applyDynamics(boolean jump_occurring) {

		// iterate through all hybrid systems in the environment
		for (HybridSystem sys : engine.getEnvironmentSystems().getSystems()) {
			HybridSystemModel<?> hs = sys.model();
			// attempt to perform dynamics computation
			try {
				// get jump priority
				boolean priority = jumpPriority;
				// if a jump is occurring
				if (jump_occurring) {
					// if jumps do not have priority
					if (!priority) {
						// check that system if not in flow set
						if (!HybridSystemModel.c(hs)) {
							HybridSystemModel.g(hs);
						}
					}
					// if jumps have priority
					else {
						HybridSystemModel.g(hs);
					}
				} // if a flow is occurring
				else {
					// if jumps have priority
					if (priority) {
						// check that system is not in jump set
						if (!HybridSystemModel.d(hs)) {
							// give flows priority
							HybridSystemModel.f(hs);

						}
					} else {
						// apply flow map
						HybridSystemModel.f(hs);
					}
				}
			} catch (

			Exception dynamicsError) {
				// print error message if computation failed
				Console.error("Apply Dynamics Error on " + hs.getClass() + " with state: \n"
						+ XMLParser.serializeObject(hs.getState()), dynamicsError);
			}
		}

	}

	/**
	 * Clear the state change variable values
	 */
	public void clearChangeValues() {

		for (DynamicObjectManipulator field : engine.getObjectManipulator().getSimulatedObjectAccessVector()) {
			// System.out.println(XMLParser.serializeObject(field));

			try {
				if (((DataStructure) field.getParent()).properties().isSimulated() != null) {
					field.updateObject(field.getObject(), (field.getParent()));
					// System.out.println(XMLParser.serializeObject(field));
				} else {
					if (field.getField().getType().equals(Double.class)
							|| field.getField().getType().equals(double.class)) {
						field.updateObject(0.0, field.getChangeParent());
					}
				}
			} catch (Exception e) {
				if (field.getField().getType().equals(Double.class)
						|| field.getField().getType().equals(double.class)) {
					field.updateObject(0.0, field.getChangeParent());
				}
			}
		}
	}

	/**
	 * Evaluate the dynamics of all hybrid systems within the environment
	 * 
	 * @param jump_occurring
	 *            flag indicating if a jump is occurring
	 */
	public void evaluateDynamics(boolean jump_occurring) {

		// System.out.println(jump_occurring + " " + this.jumpPriority);
		prepareDynamicComponents(jump_occurring);

		applyDynamics(jump_occurring);

		processDynamicComponents(jump_occurring);

	}

	/**
	 * Get the jump priority
	 * 
	 * @return true if priority is for jumps, false if priority is for flows
	 */
	public boolean getJumpPriority() {

		DomainPriority jumpPriority = engine.getEnvironmentSettings().domainPriority;
		switch (jumpPriority) {
		case JUMP:
			return true;
		case FLOW:
			return false;
		case NONE:
			return true;
		case RANDOM:
			Double randomSelect = Math.random() - .5;
			if (randomSelect >= 0.0) {
				return true;
			} else {
				return false;
			}
		default:
			return true;
		}

	}

	/**
	 * Determine if any of the systems in the environment are in the jump or flow
	 * set
	 * 
	 * @param jump
	 *            flag indicating which set to evaluate, true for jump set, false
	 *            for flow set
	 * @return true if any system is in the specified set
	 */
	public boolean isSystemInSetz(boolean jump) {

		// initialize jump set flag
		boolean inSet = false;
		// iterate through all hybrid systems in the environment
		for (HybridSystem sys : engine.getEnvironmentSystems().getSystems()) {
			HybridSystemModel<?> hs = sys.model();
			// the function is checking jump set
			if (jump) {
				// check if current system is in the jump set
				boolean inJumpSet = HybridSystemModel.d(hs);
				// check for priority if system is also in flow set
				boolean priority = !(!jumpPriority && HybridSystemModel.c(hs));
				// determine if system is in jump set with priority adjustment
				inJumpSet = inJumpSet && priority;
				// add result to overall set flag
				inSet = inSet || inJumpSet;
			}
			// the function is checking flow set
			else {
				// check if current system is in the jump set
				boolean inFlowSet = HybridSystemModel.c(hs);
				// check for priority if system is also in jump set
				boolean priority = !(jumpPriority && HybridSystemModel.d(hs));
				// determine if system is in flow set with priority adjustment
				inFlowSet = inFlowSet && priority;
				// add result to overall set flag
				inSet = inSet || inFlowSet;
			}
		}
		return inSet;
	}

	/**
	 * Determine if any of the systems in the environment are in the jump or flow
	 * set
	 * 
	 * @param jump
	 *            flag indicating which set to evaluate, true for jump set, false
	 *            for flow set
	 * @return true if any system is in the specified set
	 */
	public boolean isSystemInSet(boolean jump) {

		// initialize jump set flag
		boolean inSet = false;
		// iterate through all hybrid systems in the environment
		for (HybridSystem sys : engine.getEnvironmentSystems().getSystems()) {
			HybridSystemModel<?> hs = sys.model();
			// the function is checking jump set
			if (jump) {
				// check if current system is in the jump set
				boolean inJumpSet = HybridSystemModel.d(hs);
				// check for priority if system is also in flow set
				// boolean priority = !(!jumpPriority && HybridSystemModel.c(hs));
				// determine if system is in jump set with priority adjustment
				// add result to overall set flag
				inSet = inSet || inJumpSet;
			}
			// the function is checking flow set
			else {
				// check if current system is in the jump set
				boolean inFlowSet = HybridSystemModel.c(hs);
				// check for priority if system is also in jump set
				// boolean priority = !(jumpPriority && HybridSystemModel.d(hs));
				// determine if system is in flow set with priority adjustment
				// add result to overall set flag
				inSet = inSet || inFlowSet;
			}
		}
		return inSet;
	}

	/**
	 * Prepare change state values for dynamics to be applied.
	 * 
	 * @param jump
	 *            flag indicating if jump is occurring
	 */
	public void prepareDynamicComponents(boolean jump) {

		if (jump) {
			storeChangeValues(true);
		} else {
			clearChangeValues();
		}
	}

	/**
	 * Process change state values after dynamics have been applied
	 * 
	 * @param jump
	 *            flag indicating if jump is occurring
	 */
	public void processDynamicComponents(boolean jump) {

		// if jump has occurred (ode has settled state and is paused)
		if (jump) {
			storeChangeValues(false); // store the change values to the state
			clearChangeValues(); // clear the change variables

		}
	}

	/**
	 * Store the change values before or after a jump has occurred
	 * 
	 * @param pre_jump
	 *            flag indicating if the values are being stored before a jump
	 */
	public void storeChangeValues(boolean pre_jump) {

		for (DynamicObjectManipulator field : engine.getObjectManipulator().getFieldParentMap().values()) {
			try {
				if (((DataStructure) field.getParent()).properties().isSimulated() != null) {
					field.updateObject(field.getObject(), (field.getParent()));
					// System.out.println(XMLParser.serializeObject(field));
				} else {
					throw new Exception();
				}
			} catch (Exception ee) {

				try {
					if (pre_jump) {
						field.updateObject(field.getObject(), field.getChangeParent());
					} else {
						field.updateObject(field.getChange());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	public void resetPriority() {

		this.jumpPriority = this.getJumpPriority();
	}

	public void resetPriority(boolean jump) {

		this.jumpPriority = jump;
	}
}
