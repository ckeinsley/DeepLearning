
package edu.ucsc.cross.jheq.application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import edu.ucsc.cross.jheq.application.CoreFeatures.CoreFeature;
import edu.ucsc.cross.jheq.builder.ContentBuilder;
import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.function.JHEQFeature;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.ui.HEQDisplay;
import edu.ucsc.cross.jheq.util.CollectionFormat;
import edu.ucsc.cross.jheq.variable.Shared;

public class JHEQToolbox {

	Shared<JHEQEnvironment> environment;

	JHEQLibrary database;

	Scanner scan = new Scanner(System.in);

	CoreFeatures core;

	CoreFeature coreStatus;

	HEQDisplay app;

	public JHEQToolbox() {

		this(new String[]
			{});
	}

	public JHEQToolbox(String args[]) {

		scan = new Scanner(System.in);
		environment = new Shared<JHEQEnvironment>(new JHEQEnvironment());
		database = new JHEQLibrary(null, true);
		if (app == null && database.config.isGuiEnabled()) {
			app = new HEQDisplay(this);
		}

	}

	public void initializ() {

	}

	public void prepare() {

		initialize();
		core = new CoreFeatures();
		coreStatus = null;
		Console.info("JavaHyEQ Toolbox loaded successfully");
	}

	public void run() {

		ContentBuilder.globalVariables.clear();
		if (getDatabase().config.isGuiEnabled()) {
			if (app != null) {
				try {
					app.getFrame().setResizable(false);

				} catch (Exception e) {
				}
			} else {
				app = new HEQDisplay(this);
			}
			prepare();
			app.start();
			app.getFrame().setResizable(true);

		} else {
			if (app != null) {
				try {
					app.getFrame().dispose();

				} catch (Exception e) {
				}
			}
			prepare();
			printMenu(false);
			runApp();
		}
		resetEnvironmentDefaultSettings();
	}

	public void resetEnvironmentDefaultSettings() {

		JHEQEnvironment e = new JHEQEnvironment();
		e.loadSettings(getDatabase().config.verifvEnvironmentSettings());
		Console.setSettings(database.config.verifvConsoleSettings());
		environment.setValue(e);
	}

	public void initialize() {

		Console.info("Initializing the JavaHyEQ Toolbox...");
		database.initialize(null);

		if (app != null) {
			app.refreshOperations();
		}
	}

	public static void main(String args[]) {

		JHEQToolbox hse = new JHEQToolbox(args);
		hse.run();
	}

	public void printMenu(boolean core) {

		Console.info("Menu \n" + getMenu(core) + "\n");
		// System.out.println("\nselect an operation by entering the corresponding
		// character or integer index: \n");

	}

	public void runApp() {

		if (coreStatus != (CoreFeature.QUIT)) {
			if (coreStatus == (CoreFeature.PRINT_MENU)) {
				printMenu(true);
			}
			System.out.print(InputParser.getInputLine());

			try {

				String selection = scan.nextLine();
				try {
					ArrayList<ParsedInput> userInputs = InputParser.getInputs(selection);
					for (ParsedInput input : userInputs) {
						executeCommand(input);
					}

				} catch (Exception badEntry) {
					Console.warn("invalid command sequence " + selection
							+ " no action taken, please try again or enter " + CoreFeature.QUIT.index + " to quit",
							badEntry);
				}

				// System.out.print("> ");
			} catch (Exception noLine) {
				noLine.printStackTrace();

			}
			runApp();
		} else {
			System.exit(0);
		}
	}

	public void executeCommands(String input_string) {

		if (input_string.length() < 1) {
			return;
		}
		ArrayList<ParsedInput> userInputs = InputParser.getInputs(input_string);
		for (ParsedInput input : userInputs) {

			if (input != null) {
				executeCommand(input);
			}
		}
	}

	public void executeCommand(ParsedInput input) {

		Console.info("executing task " + input.toString());

		try {
			if (CoreFeature.isCoreIndex(input.command)) {
				coreStatus = core.performInput(this.environment, input, this);
			} else {
				throw new IOException();
			}
		} catch (Exception notCore) {

			String selectionInd = input.command;
			JHEQFeature ind = database.getTaskList().get(selectionInd);
			try {
				CoreArgs args = new CoreArgs(input.arguments);
				// Console.debug(args.toString());
				Integer iterations = 1;
				if (args.multiArg.getValue() != null) {
					iterations = args.multiArg.getValue();
				}
				for (int i = 0; i < iterations; i++) {
					ind.perform(this, input.arguments);
				}

			} catch (Exception badEntry) {

				Console.info("invalid input " + input.toString() + " no action taken, please try again or enter "
						+ CoreFeature.QUIT.index + " to quit", badEntry);
			}
		}
	}

	public String getMenu(boolean core) {

		String menu = "";
		// fillIndex(hse);
		if (core) {
			menu += "Toolbox Tasks: \n" + CoreFeature.listCore();
		}
		menu += "\nApplication Tasks:";
		ArrayList<String> sortedNames = CollectionFormat.sortKeys(database.getTaskList());
		for (String ind : sortedNames) {
			menu += "\n---------------------------------------------------------------------------------------------  ";
			menu += "\n [ " + ind + " ] : " + " (" + database.getTaskList().get(ind).getClass().getSimpleName() + ")";
		}
		menu += "\n---------------------------------------------------------------------------------------------  ";

		return menu;
	}

	/**
	 * @return the database
	 */
	public JHEQLibrary getDatabase() {

		return database;
	}

	/**
	 * @return the environment
	 */
	public JHEQEnvironment getEnvironment() {

		return environment.getValue();
	}

	/**
	 * @param environment
	 *            the environment to set
	 */
	public void setEnvironment(JHEQEnvironment environment) {

		this.environment.setValue(environment);
	}

}
