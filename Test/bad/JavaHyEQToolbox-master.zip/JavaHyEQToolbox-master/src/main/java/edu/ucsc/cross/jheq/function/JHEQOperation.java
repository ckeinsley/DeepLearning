
package edu.ucsc.cross.jheq.function;

public abstract class JHEQOperation implements JHEQFeature {

	private String functionCallLabel;

	public JHEQOperation() {

		functionCallLabel = null;
	}

	/**
	 * The label that will be displayed in the menu and used to call the task from
	 * the command line
	 * 
	 * @return label to display
	 */

	@Override
	public String getCallHandle() {

		if (functionCallLabel == null) {
			return this.toString();
		} else {
			return functionCallLabel;
		}
	}

	public void setCallHandle(String label) {

		functionCallLabel = label;
	}

}
