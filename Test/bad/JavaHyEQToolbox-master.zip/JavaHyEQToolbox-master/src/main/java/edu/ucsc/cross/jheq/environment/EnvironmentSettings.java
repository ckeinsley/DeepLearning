/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ EnvironmentSettings.java
 * ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS); 01-August-2018 : Added default values for previously uninitialized
 * variables (BS);
 *
 */

package edu.ucsc.cross.jheq.environment;

import edu.ucsc.cross.jheq.integrator.FirstOrderIntegratorFactory;
import edu.ucsc.cross.jheq.integrator.VariableIntegratorFactory;
import edu.ucsc.cross.jheq.specification.DomainPriority;

/**
 * The settings that define how computations are handled and data is collected.
 * 
 * Intended Operator: User
 */
public class EnvironmentSettings {

	/**
	 * Time between data point storage.
	 */
	public double dataPointInterval;

	/**
	 * Specifies how domain will be determined when a system is in both flow and
	 * jump set.
	 */
	public DomainPriority domainPriority;

	/**
	 * The convergence threshold is the threshold in which a value is considered to
	 * be approximately the same as another value.
	 */
	public Double eventHandlerConvergenceThreshold;

	/**
	 * The maximum number of times the integrator will attempt to close in on a
	 * jump. Since events are only problem-dependent and are triggered by the
	 * independent time variable and the state vector, they can occur at virtually
	 * any time, unknown in advance. The integrators will take care to avoid sign
	 * changes inside the steps, they will reduce the step size when such an event
	 * is detected in order to put this event exactly at the end of the current
	 * step. This guarantees that step interpolation (which always has a one step
	 * scope) is relevant even in presence of discontinuities. This is independent
	 * from the stepsize control provided by integrators that monitor the local
	 * error (this event handling feature is available for all integrators,
	 * including fixed step ones).
	 */
	public Double eventHandlerMaximumCheckInterval;

	/**
	 * Integrator factory that will be the integrator to use.
	 */
	public FirstOrderIntegratorFactory integrator;

	/**
	 * Maximum number of iterations for the event handler.
	 */
	public int maxEventHandlerIterations;

	/**
	 * Maximum time allowed before execution terminates.
	 */
	public int maximumJumps;

	/**
	 * Maximum number of jumps allowed before execution terminates.
	 */
	public double maximumTime;

	/**
	 * Flag indicating if non primitive data is to be stored.
	 */
	public boolean storeNonPrimativeData;

	/**
	 * Value threshold where any value (absolute) with a lesser value will be
	 * considered to be zero if Zero approximator is being used.
	 */
	public double zeroThreshold;

	/**
	 * Default values constructor.
	 */
	public EnvironmentSettings() {

		dataPointInterval = .05;
		domainPriority = DomainPriority.JUMP;
		eventHandlerMaximumCheckInterval = 1E-3;
		eventHandlerConvergenceThreshold = 1e-5;
		zeroThreshold = 1e-3;
		integrator = new VariableIntegratorFactory();
		maxEventHandlerIterations = 100;
		maximumJumps = 200;
		maximumTime = 20.0;
		storeNonPrimativeData = false;
	}

}
