/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ DataStructure.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS); 30-August-2018 : Added constructor that allows trajectory store flag
 * to be set upon initialization.
 *
 */

package edu.ucsc.cross.jheq.object;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;

import com.be3short.obj.access.FieldFinder;

import edu.ucsc.cross.jheq.variable.ClonableVariable;
import edu.ucsc.cross.jheq.variable.RandomVariable;
import edu.ucsc.cross.jheq.variable.Variable;

/**
 * The base of any data structure developed to use within the environment. It
 * provides a set of properties that allow the structure to be named and
 * assigned a unique index to distinguish it from other instances of the same
 * object that may have the same name.
 * 
 * Intended Operator: User
 */
public class DataStructure {

	/**
	 * Properties of the data structure.
	 */
	DataStructureProperties properties;

	/**
	 * Constructs the data structure and instantiates the properties
	 */
	public DataStructure() {

		properties = new DataStructureProperties(this);

	}

	/**
	 * Constructs the data structure, instantiates the properties, and allows the
	 * trajectory storage flag to be set. This allows any data structure that
	 * defines a state to have the trajectory stored even if it is a substate of
	 * another data structure.
	 * 
	 * @param store_by_default
	 *            flag indicating that the trajectories of this data structure
	 *            should be stored by default
	 */
	public DataStructure(boolean store_by_default) {

		properties = new DataStructureProperties(this);
		properties.setStoreTrajectory(store_by_default);

	}

	/**
	 * Access the properties of the data structure.
	 * 
	 * @return properties object properties
	 */
	public DataStructureProperties properties() {

		return properties;
	}

	public static HashMap<String, Field> getFieldMap(Object obj) {

		HashMap<String, Field> fields = new HashMap<String, Field>();
		ArrayList<Field> fieldList = FieldFinder.getObjectFields(obj, true, false);
		for (Field field : fieldList) {
			if (!fields.containsValue(field)) {
				fields.put(field.getName(), field);
			}
		}
		return fields;
	}

	@SuppressWarnings(
		{ "rawtypes", "unchecked" })
	public static HashMap<String, Variable<?>> getFieldVarMap(Object obj) {

		HashMap<String, Field> fields = getFieldMap(obj);
		HashMap<String, Variable<?>> var = new HashMap<String, Variable<?>>();
		for (Field field : fields.values()) {
			String name = field.getName();
			if (field.getType().equals(double.class) || field.getType().equals(Double.class)) {
				var.put(name, new RandomVariable(0.0, 0.0));
			} else {
				try {
					var.put(name, new ClonableVariable(field.get(obj)));
				} catch (IllegalArgumentException | IllegalAccessException e) {
					e.printStackTrace();
				}
			}
		}
		return var;
	}

}
