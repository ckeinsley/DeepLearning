
package edu.ucsc.cross.jheq.builder;

import java.util.ArrayList;
import java.util.HashMap;

import com.be3short.data.cloning.ObjectCloner;
import com.be3short.io.xml.XMLParser;

import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.function.JHEQOperation;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.model.FlowMap;
import edu.ucsc.cross.jheq.model.FlowSet;
import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.model.JumpMap;
import edu.ucsc.cross.jheq.model.JumpSet;
import edu.ucsc.cross.jheq.util.CollectionFormat;

public class SystemDefinition extends JHEQOperation {

	private static HashMap<String, Object> globalParameterMap = new HashMap<String, Object>();

	public String flowMapClass;

	public String jumpMapClass;

	public String flowSetClass;

	public String jumpSetClass;

	public String stateClass;

	public String[] localVariables;

	public String[] globalVariables;

	public Object[] accessKeys;

	public SystemDefinition() {

		super();
		stateClass = "State";
		flowMapClass = "F";
		jumpMapClass = "G";
		flowSetClass = "C";
		jumpSetClass = "D";

		localVariables = new String[]
			{ "" };
		globalVariables = new String[]
			{ "" };
		accessKeys = new Object[]
			{ new Object() };
		super.setCallHandle(null);
	}

	@SuppressWarnings(
		{ "unchecked", "rawtypes" })
	public SystemBuilder<?> createGenerator() {

		try {
			Class stateClassType = ClassLoader.getSystemClassLoader().loadClass(stateClass);
			Object state = ClassLoader.getSystemClassLoader().loadClass(stateClass).newInstance();
			FlowMap flowMap = createInstance(FlowMap.class, flowMapClass);
			JumpMap jumpMap = createInstance(JumpMap.class, jumpMapClass);
			FlowSet flowSet = createInstance(FlowSet.class, flowSetClass);
			JumpSet jumpSet = createInstance(JumpSet.class, jumpSetClass);

			Object[] parameters = createVariables();
			Object[] access = (Object[]) ObjectCloner.xmlClone(accessKeys);
			HybridSystem hs = HybridSystem.create(stateClassType, state, flowMap, jumpMap, flowSet, jumpSet,
					parameters);
			hs.model().properties().setAccessKeys(access);
			SystemBuilder gener = new SystemBuilder(hs.model(),
					CollectionFormat.getStringListWithBlankEntriesFiltered(globalVariables));
			// gener.accessKeys = (accessKeys);

			return gener;
			// JEQ.save(gener);

		} catch (Exception badPath) {
			Console.error("invalid components provided to create a hybrid system \n" + XMLParser.serializeObject(this),
					badPath);

		}
		return null;

	}

	public Object[] createVariables() {

		ArrayList<Object> params = new ArrayList<Object>();
		for (String parameterClass : localVariables) {
			if (parameterClass.length() > 0) {
				try {
					Object param = createInstance(parameterClass);
					params.add(param);
				} catch (Exception badPath) {
					Console.error("unable to load param " + parameterClass);

				}
			}
		}
		return params.toArray(new Object[params.size()]);
	}

	public Object createInstance(String class_path) {

		Object obj = null;
		if (class_path != null) {
			if (!class_path.equals("null") && !class_path.equals("")) {
				try {
					obj = ClassLoader.getSystemClassLoader().loadClass(class_path).newInstance();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return obj;
	}

	public static <T> T createInstance(Class<T> class_type, String class_path) {

		T obj = null;
		if (class_path != null) {
			if (!class_path.equals("null") && !class_path.equals("")) {
				try {
					obj = class_type.cast(ClassLoader.getSystemClassLoader().loadClass(class_path).newInstance());
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return obj;
	}

	/**
	 * @return the globalParameterMap
	 */
	public static HashMap<String, Object> getGlobalParameterMap() {

		return globalParameterMap;
	}

	/**
	 * @param globalParameterMap
	 *            the globalParameterMap to set
	 */
	public static void setGlobalParameterMap(HashMap<String, Object> globalParameterMap) {

		SystemDefinition.globalParameterMap = globalParameterMap;
	}

	@Override
	public void perform(JHEQToolbox application, String input) {

		try {
			createGenerator();

			// JEQ.save(gener);

		} catch (Exception badPath) {
			Console.error("invalid components provided to create a hybrid system \n" + XMLParser.serializeObject(this),
					badPath);

		}
	}

}
