
package edu.ucsc.cross.jheq.application;

import java.io.File;
import java.util.HashMap;

import com.be3short.io.general.FileSystemInteractor;
import com.be3short.io.xml.XMLParser;

import edu.ucsc.cross.jheq.builder.ContentDefinition;
import edu.ucsc.cross.jheq.environment.EnvironmentSettings;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.logging.ConsoleSettings;

public class JHEQConfiguration {

	public static String defaultFilePathh = "";

	public static String defaultEnvironmentSetting = "settings/environmentSettings.xml";

	public static String defaultOperationPath = "tasks";

	public static String defaultConsoleSetting = "settings/consoleSettings.xml";

	public static final String defaultConfigurationFileName = "jheq.xml";

	public String rootFilePath;

	/**
	 * @return the rootFilePath
	 */
	public String getRootFilePath() {

		return rootFilePath;
	}

	/**
	 * @param rootFilePath
	 *            the rootFilePath to set
	 */
	public void setRootFilePath(String rootFilePath) {

		this.rootFilePath = rootFilePath;
	}

	private String defaultEnvironmentSettingPath;

	private String defaultConsoleSettingPath;

	private HashMap<String, Boolean> featurePathVisibility;

	private boolean guiEnabled;

	public JHEQConfiguration() {

		createNew();
		createNew();
		initialize();
	}

	private void initialize() {

		verifvEnvironmentSettings();
		verifvConsoleSettings();
	}

	private void createNew() {

		this.defaultEnvironmentSettingPath = defaultEnvironmentSetting;
		this.defaultConsoleSettingPath = defaultConsoleSetting;
		this.featurePathVisibility = new HashMap<String, Boolean>();
		guiEnabled = false;
		File taskFile = new File("tasks");
		taskFile.mkdirs();
		File resFile = new File("resources");
		resFile.mkdirs();
		File defFile = new File("definitions");
		File f = new File("definitions/defineContentTemplate.xml");
		f.setReadOnly();
		FileSystemInteractor.createOutputFile(f, XMLParser.serializeObject(new ContentDefinition()));
		defFile.mkdirs();
		rootFilePath = "";
		this.featurePathVisibility.put("tasks", true);
	}

	public EnvironmentSettings verifvEnvironmentSettings() {

		EnvironmentSettings envSettings = null;
		File f = new File(this.defaultEnvironmentSettingPath);
		try {
			if (!f.exists()) {
				throw new Exception();
			}
			envSettings = XMLFileTools.loadContent(EnvironmentSettings.class, f);

		} catch (Exception noConfig) {
			Console.warn("no environment settings found at " + this.defaultEnvironmentSettingPath
					+ " default settings created at the location", noConfig);
			envSettings = new EnvironmentSettings();

			XMLFileTools.save(envSettings, f);
		}
		return envSettings;
	}

	public ConsoleSettings verifvConsoleSettings() {

		File f = new File(this.defaultConsoleSettingPath);
		ConsoleSettings envSettings = null;
		try {
			if (!f.exists()) {
				throw new Exception();
			}
			envSettings = XMLFileTools.loadContent(ConsoleSettings.class, f);

		} catch (Exception noConfig) {
			Console.warn("no console settings found at " + this.defaultConsoleSettingPath
					+ " default settings created at the location", noConfig);
			envSettings = new ConsoleSettings();
			XMLFileTools.save(envSettings, f);
		}
		return envSettings;
	}

	public static JHEQConfiguration fetch() {

		File filePath = new File("");
		File file = new File(filePath.getAbsolutePath() + "/" + defaultConfigurationFileName);
		JHEQConfiguration config = null;
		try {
			if (file.exists()) {
				config = XMLFileTools.loadContent(JHEQConfiguration.class, file);

			} else {
				throw new Exception();
			}

		} catch (Exception noConfig) {
			Console.warn("no JavaHyEQ toolbox configuration file found at the current directory, creating default");
			config = new JHEQConfiguration();
			XMLFileTools.save(config, file);
		}
		return config;
	}

	public static JHEQConfiguration fetch(File file) {

		JHEQConfiguration config = null;
		try {
			config = XMLFileTools.loadContent(JHEQConfiguration.class, file);

		} catch (Exception noConfig) {
			Console.warn("no JavaHyEQ toolbox configuration file found at the current directory, creating default");
			config = new JHEQConfiguration();
			XMLFileTools.save(config, file);
		}
		return config;
	}

	/**
	 * @return the defaultEnvironmentSettingPath
	 */
	public String getDefaultEnvironmentSettingPath() {

		return defaultEnvironmentSettingPath;
	}

	/**
	 * @return the defaultConsoleSettingPath
	 */
	public String getDefaultConsoleSettingPath() {

		return defaultConsoleSettingPath;
	}

	/**
	 * @return the featurePathVisibility
	 */
	public HashMap<String, Boolean> getFeaturePathVisibility() {

		return featurePathVisibility;
	}

	public boolean isPathVisible(String path) {

		if (this.getFeaturePathVisibility().containsKey(path)) {
			return this.getFeaturePathVisibility().get(path);
		} else {
			return false;
		}
	}

	/**
	 * @return the guiEnabled
	 */
	public boolean isGuiEnabled() {

		return guiEnabled;
	}

	/**
	 * @param guiEnabled
	 *            the guiEnabled to set
	 */
	public void setGuiEnabled(boolean guiEnabled) {

		this.guiEnabled = guiEnabled;
		File filePath = new File("");
		File file = new File(filePath.getAbsolutePath() + "/" + defaultConfigurationFileName);
		XMLFileTools.save(this, file);
	}
}
