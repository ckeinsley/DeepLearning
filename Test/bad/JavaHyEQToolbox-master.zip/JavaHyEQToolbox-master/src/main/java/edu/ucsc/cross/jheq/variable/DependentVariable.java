/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * DependentVariable.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.variable;

import java.util.HashMap;

import edu.ucsc.cross.jheq.logging.Console;

/**
 * A value whose value is dependent on another value. A mapping links the
 * different values of the dependency to the corresponding values of this
 * variable.
 * 
 * Intended Operator: User
 *
 * @param <P>
 *            the class of the value that is provided by this variable
 */
public class DependentVariable<P> implements Variable<P> {

	/**
	 * The variable whose value dictates the value of this variable.
	 */
	private Variable<?> dependency;

	/*
	 * The variable value that will be loaded if dependency fails to produce one.
	 * Used to avoid fatal errors from attempts to access a null object.
	 */
	private P failProperties;

	/**
	 * The value mapping
	 */
	private HashMap<Object, P> valueMap;

	/**
	 * Constructor that stores the value that determines this value, and a "fail"
	 * instance of the value to be used when the dependency doesn't produce a value.
	 * Each time the dependency does not map to a value, an error is issued to the
	 * console and the fail instance will be loaded to avoid a fatal error.
	 * 
	 * @param value
	 *            the value that determines the output of this value
	 * @param fail_value
	 *            an output of this value that will be loaded if a problem occurs
	 *            that will produce incorrect values but avoid fatal errors. Each
	 *            time the fail value is used an error is written to the console.
	 */
	public DependentVariable(Variable<?> value, P fail_value) {

		this.dependency = value;
		failProperties = fail_value;
		valueMap = new HashMap<Object, P>();
	}

	/**
	 * Adds a value to the value dependency map
	 * 
	 * @param object
	 *            object that the value corresponds to
	 * @param value
	 *            the variable value
	 * @param <T>
	 *            specific class of data to be added
	 */
	public <T> void addValue(T object, P value) {

		valueMap.put(object, value);
	}

	/**
	 * Get the current value of type P
	 * 
	 * @return current value of type P
	 */
	@Override
	public P getValue() {

		P props = null;

		if (dependency.getValue() != null) {
			if (valueMap.keySet().contains(dependency.getValue())) {
				props = valueMap.get(dependency.getValue());
			}
		}
		if (props == null) {
			Console.error("missing dependent value: " + failProperties.getClass().getSimpleName() + "; dependency: "
					+ dependency.getValue());
			props = failProperties;
		}
		return props;
	}

}
