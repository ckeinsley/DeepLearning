/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ ObjectManipulator.java
 * ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.worker;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;

import com.be3short.data.cloning.ObjectCloner;
import com.be3short.obj.access.FieldFinder;
import com.be3short.obj.manipulation.DynamicObjectManipulator;
import com.be3short.obj.manipulation.FieldMapper;

import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.model.HybridSystemModel;
import edu.ucsc.cross.jheq.object.DataStructure;
import edu.ucsc.cross.jheq.trajectory.HybridTime;

/**
 * A global pointer management system that allows the values of objects to be
 * modified without overwriting the value.
 * 
 * Intended Operator: System
 */
public class ObjectManipulator {

	/**
	 * Field mapper that reads the fields of every data structure
	 */
	public static final FieldMapper fieldMapper = new FieldMapper(DataStructure.class, true, true);

	/**
	 * Mapping of the fields of each class
	 */
	public static HashMap<String, ArrayList<Field>> fields = new HashMap<String, ArrayList<Field>>();

	/**
	 * Vector of dynamic values for each object in the environment
	 */
	private double[] changeVector;

	/**
	 * Engine supervisor in charge
	 */
	EngineSupervisor manager;

	/**
	 * Mapping of object manipulators for every object within the environment
	 */
	private HashMap<Object, DynamicObjectManipulator> objectMap;

	/**
	 * Vector of object manipulators for every object that is being simulated
	 */
	private DynamicObjectManipulator[] simulatedObjectAccessVector;

	/**
	 * Vector of values of each object being simulated
	 */
	private double[] valueVector;

	/**
	 * Object manipulator constructor
	 * 
	 * @param manager
	 *            engine supervisor in charge
	 */
	public ObjectManipulator(EngineSupervisor manager) {

		this.manager = manager;
	}

	/**
	 * Get the vector of dynamic change values
	 * 
	 * @return dynamic value vector
	 */
	public double[] getChangeVector() {

		return changeVector;
	}

	/**
	 * Load class field mapping
	 * 
	 * @param elements
	 *            fields that have been loaded
	 * @param search_classes
	 *            classes to include while searching
	 * @param search_class
	 *            the base class being searched for
	 */
	public void getClassFieldMapping(HashMap<String, ArrayList<Field>> elements, Set<Class<?>> search_classes,
			Class<?> search_class) {

		for (Class<?> clas : search_classes) {
			for (Field fields : clas.getDeclaredFields()) {
				if (!fields.getName().contains("$SWITCH_TABLE$") && !fields.getType().equals(search_class))// &&
																											// !skipFields.contains(fields))
				{
					if (!elements.get(clas.getName()).contains(fields)) {
						elements.get(clas.getName()).add(fields);
					}
				}
			}
			if (search_classes.contains(clas.getSuperclass())) {
				Class<?> superClass = clas.getSuperclass();
				ArrayList<Field> extendedFields = new ArrayList<Field>(Arrays.asList(superClass.getDeclaredFields()));
				while (search_classes.contains(superClass)) {
					for (Field fi : extendedFields) {
						if (!fi.getName().contains("$SWITCH_TABLE$") && !fi.getType().equals(search_class))// &&
						{
							if (!elements.get(clas.getName()).contains(fi)) {
								elements.get(clas.getName()).add(fi);
							}
						}
					}
					clas = superClass;
					superClass = superClass.getSuperclass();
					extendedFields.addAll(Arrays.asList(superClass.getDeclaredFields()));

				}

			}

		}

	}

	/**
	 * Get the map of object manipulators for the parent of mapped fields
	 * 
	 * @return manipulator map
	 */
	public HashMap<Object, DynamicObjectManipulator> getFieldParentMap() {

		return objectMap;
	}

	/**
	 * Get environment hybrid time
	 * 
	 * @return environment hybrid time
	 */
	public HybridTime getHybridSimTime() {

		return manager.getEnvironmentTime();
	}

	/**
	 * Get the object manipulator vector for the simulated objects
	 * 
	 * @return manipulator vector
	 */
	public DynamicObjectManipulator[] getSimulatedObjectAccessVector() {

		return simulatedObjectAccessVector;
	}

	/**
	 * Get state value vector for the simulated objects
	 * 
	 * @return value vector
	 */
	public double[] getSimulatedObjectValueVector() {

		return valueVector;
	}

	/**
	 * Get the environment time
	 * 
	 * @return environment time
	 */
	public Double getSimulationTime() {

		return manager.getEnvironmentTime().getTime();
	}

	/**
	 * Increment jump index of the environment
	 * 
	 * @param jump_increment
	 *            amount to increment indexes
	 */
	public void incrementJumpIndex(Integer jump_increment) {

		setSimTime(new HybridTime(getHybridSimTime().getTime(), getHybridSimTime().getJumps() + jump_increment));
	}

	/**
	 * Initialize the field mapper to read the fields of every object
	 */
	private void initializeFieldMapper() {

		HashMap<Class<?>, String> classes = new HashMap<Class<?>, String>();
		HashMap<String, ArrayList<Field>> elems = new HashMap<String, ArrayList<Field>>();
		HashMap<String, ArrayList<Field>> ele = new HashMap<String, ArrayList<Field>>();
		for (HybridSystem syst : manager.getEnvironmentSystems().getSystems()) {
			HybridSystemModel<?> sys = syst.model();
			if (!classes.containsKey(sys.getState().getClass())) {
				classes.put(sys.getState().getClass(), sys.getState().getClass().getName());
				elems.put(sys.getState().getClass().getName(), new ArrayList<Field>());
			}
		}
		for (HybridSystem syst : manager.getEnvironmentSystems().getSystems()) {
			// HybridSystemModel<?> sys = syst.model();
			for (Object obj : syst.variables().getVariables()) {
				Console.debug("Initializing field mapper");
				DataStructure ds = (DataStructure) obj;
				if (!classes.containsKey(ds.getClass())) {
					classes.put(ds.getClass(), ds.getClass().getName());
					elems.put(ds.getClass().getName(), new ArrayList<Field>());
				}
			}
		}
		getClassFieldMapping(elems, classes.keySet(), DataStructure.class);
		while (countFields(ele) < countFields(elems)) {
			getClassFieldMapping(elems, classes.keySet(), DataStructure.class);
			ele = elems;
		}
		fields = elems;
	}

	/**
	 * Initialize object manipulator map for simulated objects
	 * 
	 * @param object_map
	 *            map to load
	 * @param state
	 *            state to read
	 * @param dynamic
	 *            dynamic state to read
	 */
	@SuppressWarnings("unchecked")
	private void initializeMap(HashMap<Object, DynamicObjectManipulator> object_map, Object state, Object dynamic) {

		for (Field field : fieldMapper.getClassFields(state.getClass()))// fields.get(state.getClass().getName()))
		{
			try {
				field.setAccessible(true);

				// if (fields.containsKey(field.getType()))
				if (FieldFinder.containsSuper(field.get(state), DataStructure.class)) {
					initializeMap(object_map, field.get(state), field.get(dynamic));
				} else {
					if (field.getType().equals(ArrayList.class))

					{
						ArrayList<Object> states = (ArrayList<Object>) field.get(state);
						ArrayList<Object> dynamics = (ArrayList<Object>) field.get(dynamic);
						if (!states.isEmpty()) {
							if (FieldFinder.containsSuper(states.get(0), DataStructure.class)) {
								for (int i = 0; i < states.size(); i++) {
									initializeMap(object_map, states.get(i), dynamics.get(i));
								}
							}
						}
					}

					else if (!object_map.containsKey(state.toString() + field.getName())) {

						try {
							DynamicObjectManipulator objAccess = new DynamicObjectManipulator(field, state, dynamic);
							object_map.put(state.toString() + field.getName(), objAccess);
						} catch (Exception badField) {
							badField.printStackTrace();
						}
					}
				}
			} catch (Exception e) {

			}
		}

		// initializeMap(object_map, state, dynamic);
	}

	/**
	 * Initialize object manipulator map for all objects
	 * 
	 * @param manager
	 *            engine supervisor in charge
	 * @return initialized map
	 */
	private HashMap<Object, DynamicObjectManipulator> initializeObjectAccessMap(EngineSupervisor manager) {

		initializeFieldMapper();

		HashMap<Object, DynamicObjectManipulator> newObjectAccessMap = new HashMap<Object, DynamicObjectManipulator>();
		for (HybridSystem syst : manager.getEnvironmentSystems().getSystems()) {
			HybridSystemModel<?> sys = syst.model();
			try {
				HybridSystemModel.initializeDynamicState(sys);

				initializeMap(newObjectAccessMap, sys.getState(), HybridSystemModel.getDynamicState(sys));
				for (Object obj : syst.variables().getVariables()) {

					initializeMap(newObjectAccessMap, obj, ObjectCloner.deepInstanceClone(obj));

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		// System.out.println(XMLParser.serializeObject(newObjectAccessMap));

		return newObjectAccessMap;
	}

	/**
	 * Prepare components of the object manipulator
	 * 
	 * @param manager
	 *            engine supervisor in charge
	 */
	public void prepareComponents(EngineSupervisor manager) {

		manager.setEnvironmentTime(new HybridTime(0.0, 0));
		initializeFieldMapper();
		objectMap = initializeObjectAccessMap(manager);
		simulatedObjectAccessVector = initializeObjectAccessVector(objectMap, manager, false);
		// objectAccessVector = initializeObjectAccessVector(objectMap, manager);

		valueVector = initializeValueVector(simulatedObjectAccessVector, false);
		changeVector = initializeValueVector(simulatedObjectAccessVector, true);
	}

	/**
	 * Read state values to the corresponding objects
	 * 
	 * @param y
	 *            state value vector
	 */
	public void readStateValues(double y[]) {

		for (int i = 0; i < y.length; i++) {
			try {
				DynamicObjectManipulator dm = getSimulatedObjectAccessVector()[i];
				// Field field = getSimulatedObjectAccessVector()[i].getField();
				if (((DataStructure) dm.getParent()).properties().isSimulated() != null) {

				} else {
					throw new Exception();
				}
			} catch (Exception ee) {
				getSimulatedObjectAccessVector()[i].updateObject(y[i]);
			}
		}
	}

	/**
	 * Set the state change vector
	 * 
	 * @param changeVector
	 *            change value vector
	 */
	public void setChangeVector(double[] changeVector) {

		this.changeVector = changeVector;
	}

	/**
	 * Set the field parent map
	 * 
	 * @param fieldParentMap
	 *            map to set
	 */
	public void setFieldParentMap(HashMap<Object, DynamicObjectManipulator> fieldParentMap) {

		this.objectMap = fieldParentMap;
	}

	/**
	 * Set the simulation hybrid time
	 * 
	 * @param simTime
	 *            time to set
	 */
	public void setSimTime(HybridTime simTime) {

		manager.setEnvironmentTime(simTime);
	}

	/**
	 * Set simulated object access vector
	 * 
	 * @param simulatedObjectAccessVector
	 *            vector to set
	 */
	public void setSimulatedObjectAccessVector(DynamicObjectManipulator[] simulatedObjectAccessVector) {

		this.simulatedObjectAccessVector = simulatedObjectAccessVector;
	}

	/**
	 * Set simulated object value vector
	 * 
	 * @param simulatedObjectValueVector
	 *            vector to set
	 */
	public void setSimulatedObjectValueVector(double[] simulatedObjectValueVector) {

		this.valueVector = simulatedObjectValueVector;
	}

	/**
	 * Update change vector
	 * 
	 * @param yDot
	 *            input vector
	 * @return output vector with loaded values
	 */
	public double[] updateChangeVector(double yDot[]) {

		for (int i = 0; i < changeVector.length; i++) {
			double newVal = 0.0;
			if (getSimulatedObjectAccessVector()[i].getChange() != null) {
				if (getSimulatedObjectAccessVector()[i].getChange().getClass().equals(double.class)
						|| getSimulatedObjectAccessVector()[i].getChange().getClass().equals(Double.class)) {
					try {
						newVal = (double) getSimulatedObjectAccessVector()[i].getChange();
					} catch (Exception badVal) {
						Console.error("bad state value " + getSimulatedObjectAccessVector()[i].getChange(), badVal);
					}
				}
			} else {
				Console.error("null state value " + getSimulatedObjectAccessVector().toString());

			}
			changeVector[i] = newVal;
			if (yDot != null) {
				yDot[i] = newVal;
			}
		}

		return changeVector;
	}

	/**
	 * Update simulation time
	 * 
	 * @param simTime
	 *            time to set
	 */
	public void updateSimulationTime(Double simTime) {

		setSimTime(new HybridTime(simTime, getHybridSimTime().getJumps()));
	}

	/**
	 * Update simulation time and jump index
	 * 
	 * @param simTime
	 *            new time
	 * @param jump_increment
	 *            amount to increment jump index
	 */
	public void updateSimulationTime(Double simTime, Integer jump_increment)

	{

		double time = this.getSimulationTime().doubleValue();
		int jumps = this.getHybridSimTime().getJumps();
		setSimTime(new HybridTime(time, jumps + jump_increment));
	}

	/**
	 * Update the value vector
	 * 
	 * @param y
	 *            input vector with new values
	 * @return updated value vector
	 */
	public double[] updateValueVector(double y[]) {

		for (int i = 0; i < valueVector.length; i++) {
			double newVal = 0.0;
			if (getSimulatedObjectAccessVector()[i].getObject() != null) {
				try {
					DynamicObjectManipulator dm = getSimulatedObjectAccessVector()[i];
					Field field = getSimulatedObjectAccessVector()[i].getField();
					if (((DataStructure) dm.getParent()).properties().isSimulated() != null) {
						newVal = field.getDouble(dm.getParent());
						// System.out.println(XMLParser.serializeObject(field));
					} else {
						throw new Exception();
					}
				} catch (Exception ee) {
					if (getSimulatedObjectAccessVector()[i].getObject().getClass().equals(double.class)
							|| getSimulatedObjectAccessVector()[i].getObject().getClass().equals(Double.class)) {
						try {
							newVal = (double) getSimulatedObjectAccessVector()[i].getObject();
						} catch (Exception badVal) {
							Console.error("bad state value " + getSimulatedObjectAccessVector()[i].getObject(), badVal);
						}
					}
				}
				valueVector[i] = newVal;
				if (y != null) {

					y[i] = newVal;

				}

				// DynamicObjectManipulator.isNumericalValue(getSimulatedObjectAccessVector()[i],
				// valueVector[i]);
			}
		}

		return valueVector;
	}

	/**
	 * Counts the number of fields in a mapping
	 * 
	 * @param test
	 *            map to count
	 * @return total number of fields.
	 */

	private static Integer countFields(HashMap<String, ArrayList<Field>> test) {

		Integer count = 0;
		for (ArrayList<Field> clas : test.values()) {
			count += clas.size();
		}
		return count;
	}

	/**
	 * Initialize object manipulator
	 * 
	 * @param object_map
	 *            map to get manipulators from
	 * @param manager
	 *            engine supervisor in charge
	 * @param ignore_null
	 *            ignore null objects
	 * @return manipulator vector
	 */
	private static DynamicObjectManipulator[] initializeObjectAccessVector(
			HashMap<Object, DynamicObjectManipulator> object_map, EngineSupervisor manager, boolean ignore_null) {

		ArrayList<DynamicObjectManipulator> stateObjectList = new ArrayList<DynamicObjectManipulator>();
		for (DynamicObjectManipulator obj : object_map.values()) {
			if (!(obj.getObject() == null) || ignore_null) {
				if (obj.getField().getType().equals(Double.class) || obj.getField().getType().equals(double.class)) {
					stateObjectList.add(obj);
				} else {
					try {
						@SuppressWarnings("unused")
						Double test = (Double) obj.getObject();
						stateObjectList.add(obj);
					} catch (Exception notDouble) {

					}
				}
			}
		}
		DynamicObjectManipulator[] newObjectAccessVector = stateObjectList
				.toArray(new DynamicObjectManipulator[stateObjectList.size()]);
		return newObjectAccessVector;
	}

	/**
	 * Initialize the value vector from object manipulators
	 * 
	 * @param access
	 *            manipulators to use
	 * @param zero_values
	 *            force values to zero
	 * @return value vector
	 */
	private static double[] initializeValueVector(DynamicObjectManipulator[] access, boolean zero_values) {

		double[] valueVector = new double[access.length];
		int i = 0;
		int valI = 0;
		while (i < access.length) {
			if (access[i].getField().getType().equals(double.class)
					|| access[i].getField().getType().equals(Double.class))
				try {
					if (zero_values) {
						valueVector[valI++] = 0.0;

					} else {
						valueVector[valI++] = (double) access[i].getObject();
					}
				} catch (Exception e) {
					// valueVector[i] = 0.0;
					e.printStackTrace();
				}
			i++;
		}
		return valueVector;
	}
}
