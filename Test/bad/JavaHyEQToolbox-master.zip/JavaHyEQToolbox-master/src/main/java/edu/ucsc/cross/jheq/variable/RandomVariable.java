/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * RandomVariable.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.variable;

/**
 * A random double variable with it's value always generated at random based on
 * the range provided
 * 
 * Intended Operator: User
 */
public class RandomVariable implements Variable<Double> {

	/**
	 * The minimum range value
	 */
	private double max;

	/**
	 * The maximum range value
	 */
	private double min;

	/**
	 * Construct the random variable with specified min and max value for the range
	 * 
	 * @param min
	 *            the minimum range value
	 * @param max
	 *            the maximum range value
	 */
	public RandomVariable(double min, double max) {

		this.setMin(min);
		this.setMax(max);
	}

	/**
	 * Computes a random value within the range specified.
	 * 
	 * @return random the randomly generated value
	 */
	public double generateRandom() {

		double random = min + Math.random() * (max - min);
		return random;
	}

	/**
	 * Get the maximum value of the generation range.
	 * 
	 * @return max the maximum range value
	 */
	public double getMax() {

		return max;
	}

	/**
	 * Get the minimum value of the generation range.
	 * 
	 * @return min the minimum range value
	 */
	public double getMin() {

		return min;
	}

	/**
	 * Get a randomized value in the specified range.
	 * 
	 * @return randomly generated double
	 */
	@Override
	public Double getValue() {

		return generateRandom();
	}

	/**
	 * Set the maximum value of the generation range.
	 * 
	 * @param max
	 *            max range value to be stored
	 */
	public void setMax(double max) {

		this.max = max;
	}

	/**
	 * Set the minimum value of the generation range.
	 * 
	 * @param min
	 *            minimum range value to be stored
	 */
	public void setMin(double min) {

		this.min = min;
	}

	/**
	 * Generate a random variable within a specified range without creating the
	 * variable.
	 * 
	 * @param min
	 *            the minimum range value
	 * @param max
	 *            the maximum range value
	 * @return random the randomly generated double
	 */
	public static double generate(double min, double max) {

		double random = min + Math.random() * (max - min);
		return random;
	}

}
