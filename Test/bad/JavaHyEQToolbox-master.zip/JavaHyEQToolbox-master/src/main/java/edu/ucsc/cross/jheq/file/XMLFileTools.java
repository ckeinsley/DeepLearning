
package edu.ucsc.cross.jheq.file;

import java.io.File;
import java.util.HashMap;

import com.be3short.io.compression.GZipper;
import com.be3short.io.general.FileSystemInteractor;
import com.be3short.obj.modification.XMLParser;

import edu.ucsc.cross.jheq.logging.Console;

public class XMLFileTools {

	private static HashMap<String, Object> loadedContentMap = new HashMap<String, Object>();

	public static void save(Object obj, File output, boolean compressed) {

		DataFormat format = DataFormat.XML;
		if (compressed) {
			format = DataFormat.HSE;
		}
		if (output != null) {
			File checkedOutput = format.getUtilities().appendExtension(output);
			String xmlString = XMLParser.serializeObject(obj);
			System.out.println(checkedOutput.getAbsolutePath());
			switch (format) {
			case XML: {
				FileSystemInteractor.createOutputFile(checkedOutput, xmlString);
				Console.info("Successfully saved global storage file " + checkedOutput);
				break;
			}
			case HSE: {
				GZipper.writeCompressedObjectToFile(checkedOutput, xmlString);
				Console.info("Successfully saved global storage file " + checkedOutput);
				break;
			}
			default:
				Console.warn(
						"Attempt to save global storage file in " + format.getFormatName() + " format not suported");
				break;
			}
		}
	}

	public static void save(Object obj, File file) {

		save(obj, file, false);
	}

	public static void save(Object obj, String file_path) {

		File file = new File(file_path);
		save(obj, file);
	}

	public static <T> T loadContent(Class<T> obj, File file) {

		T objClassed = null;
		try

		{
			if (file == null) {
				return null;
			}
			String serial = FileSystemInteractor.getFileContentsAsString(file);
			if (serial != null) {
				Object objIn = XMLParser.getObjectFromString(serial);
				objClassed = obj.cast(objIn);
			}
		} catch (

		Exception e)

		{
			Console.error("unable to load content " + obj + " from file " + file);
		}
		return objClassed;
	}

	public static <T> T loadContent(Class<T> obj, String file_path) {

		return loadContent(obj, file_path, false);
	}

	public static <T> T loadContent(Class<T> file_class, String path, boolean reload) {

		T item = null;
		if (reload || !loadedContentMap.containsKey(path)) {
			item = XMLFileTools.loadContent(file_class, new File(path));
			loadedContentMap.put(path, item);
		}
		return file_class.cast(loadedContentMap.get(path));
	}
}
