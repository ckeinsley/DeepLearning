
package edu.ucsc.cross.jheq.application;

import java.io.File;

import edu.ucsc.cross.jheq.builder.ChartBuilder;
import edu.ucsc.cross.jheq.builder.ContentDefinition;
import edu.ucsc.cross.jheq.builder.FigureBuilder;
import edu.ucsc.cross.jheq.chart.ChartUtils;
import edu.ucsc.cross.jheq.chart.RendererConfiguration;
import edu.ucsc.cross.jheq.environment.EnvironmentSettings;
import edu.ucsc.cross.jheq.figure.GraphicFormat;
import edu.ucsc.cross.jheq.file.FileBrowser;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.function.JHEQFeature;
import edu.ucsc.cross.jheq.function.JHEQTemplate;
import edu.ucsc.cross.jheq.logging.ConsoleSettings;

public class JHEQTemplates {

	public static void main(String args[]) {

		createTemplates();
	}

	public static void createTemplates() {

		File file = FileBrowser.directory("Select a directory to store the templates");
		createTemplates(file);
	}

	public static void createTemplates(File directory) {

		JHEQTemplate[] templates = new JHEQTemplate[]
			{ new FigureBuilder(), new ContentDefinition() };
		for (JHEQTemplate template : templates) {
			template.createTemplate(directory);
		}
		FigureBuilder fig = new FigureBuilder("Main Title", 500, 500, new JHEQFeature[][]
			{
					{ (new ChartBuilder()) } },
				true);
		fig.exportFileFormat = GraphicFormat.PDF;
		fig.exportFilePath = "";
		fig.rendererFilePath = "";
		XMLFileTools.save(fig, new File(directory, "/tasks/figureDefinitionExtended.xml"));
		JHEQTemplate r = new RendererConfiguration();
		XMLFileTools.save(r, new File(directory, "/resources/chartRendererConfig.xml"));
		XMLFileTools.save(ChartUtils.getDefaultChartConfiguration(),
				new File(directory, "/resources/chartLayoutConfig.xml"));
		XMLFileTools.save(ChartUtils.getDefaultChartConfiguration(),
				new File(directory, "/resources/figureLayoutConfig.xml"));
		XMLFileTools.save(new EnvironmentSettings(), new File(directory, "settings/environmentSettings.xml"));
		XMLFileTools.save(new ConsoleSettings(), new File(directory, "/settings/consoleSettings.xml"));

	}

}
