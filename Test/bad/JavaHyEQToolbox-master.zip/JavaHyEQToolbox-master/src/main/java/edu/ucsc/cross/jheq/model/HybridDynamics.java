/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * HybridDynamics.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.model;

/**
 * This interface defines the system state as the parameter X, and outlines the
 * methods that must be implemented to define a hybrid dynamical model of the
 * form documented in the user manual.
 * 
 * Intended Operator: User (through the HybridSystem class)
 * 
 * @param <X>
 *            state class of the hybrid system
 */
interface HybridDynamics<X> {

	/**
	 * The flow set C is the set of states that define the continuous domain, which
	 * is where the system exhibits discrete continuous dynamics. This function
	 * returns true if the state is in the flow set, or false if not
	 * 
	 * @param x
	 *            the current state of the system
	 * @return true if x is in flow set, false otherwise
	 */
	public boolean C(X x);

	/**
	 * The jump set D is the set of states that define the discrete domain, which is
	 * where the system exhibits discrete discrete dynamics. This function returns
	 * true if the state is in the jump set, or false if not
	 * 
	 * @param x
	 *            current state
	 * @return true if x is in jump set, false otherwise
	 */
	public boolean D(X x);

	/**
	 * The flow map F is a mapping that determines the continuous dynamics of the
	 * state. This function defines how to compute the derivatives of the state
	 * elements
	 * 
	 * @param x
	 *            the current state of the system
	 * 
	 * @param x_dot
	 *            a copy of the state where the computed derivatives are to be
	 *            stored.
	 */
	public void F(X x, X x_dot);

	/**
	 * The jump map G is a mapping that determines the discrete changes that occur
	 * to the state variable. This function defines how the state values change
	 * discretely
	 * 
	 * @param x
	 *            the current state of the system
	 * 
	 * @param x_plus
	 *            a copy of the state where the updated jump state is to be stored
	 */
	public void G(X x, X x_plus);

}
