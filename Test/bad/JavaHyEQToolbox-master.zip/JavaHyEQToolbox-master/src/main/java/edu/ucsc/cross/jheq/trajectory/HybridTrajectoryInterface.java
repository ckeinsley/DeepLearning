/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * HybridTrajectoryInterface.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.trajectory;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import edu.ucsc.cross.jheq.object.DataStructure;

/**
 * An interface between the engine and the trajectory data that contains all of
 * the methods not intended for user functionality.
 * 
 * Intended Operator: System
 *
 * @param <X>
 *            the data structure whose trajectory is processed by this interface
 */
public class HybridTrajectoryInterface<X extends DataStructure> {

	/**
	 * The trajectory arc that is accessed by the interface
	 */
	HybridTrajectory<X> arc;

	/**
	 * Constructor for the trajectory interface
	 * 
	 * @param arc
	 *            trajectory to be interfaced
	 */
	public HybridTrajectoryInterface(HybridTrajectory<X> arc) {

		this.arc = arc;
	}

	/**
	 * Add a series to the corresponding hybrid trajectory
	 * 
	 * @param field
	 *            field whose value the trajectory element is capturing
	 * @param series
	 *            new trajectory element
	 */
	public void addSeries(Field field, HybridTrajectoryElement<?> series) {

		arc.data.put(field, series);
	}

	/**
	 * Determine if the corresponding hybrid trajectory contains a trajectory
	 * element for the specified field
	 * 
	 * @param field
	 *            field to check for a trajectory element
	 * @return true if hybrid trajectory contains a trajectory element for the
	 *         field, false otherwise
	 */
	public boolean containsSeries(Field field) {

		return arc.data.containsKey(field);
	}

	/**
	 * Get the corresponding hybrid trajectory
	 * 
	 * @return the hybrid trajectory
	 */
	public HybridTrajectory<X> getArc() {

		return arc;
	}

	/**
	 * Get the corresponding hybrid trajectory data as a map
	 * 
	 * @return map of fields and corresponding trajectory elements
	 */
	public HashMap<Field, HybridTrajectoryElement<?>> getData() {

		return arc.data;
	}

	/**
	 * Get the list of individual field trajectories sorted by field name
	 * 
	 * @return array list of all elements within the trajectory
	 */
	public ArrayList<HybridTrajectoryElement<?>> getDataListSortedByName() {

		ArrayList<HybridTrajectoryElement<?>> sortedData = new ArrayList<HybridTrajectoryElement<?>>();
		HashMap<Field, HybridTrajectoryElement<?>> fieldMap = arc.data;
		HashMap<String, HybridTrajectoryElement<?>> sortedTrajectories = new HashMap<String, HybridTrajectoryElement<?>>();
		for (Field field : fieldMap.keySet()) {
			sortedTrajectories.put(field.getName(), fieldMap.get(field));
		}
		ArrayList<String> sortedNames = new ArrayList<String>(sortedTrajectories.keySet());
		Collections.sort(sortedNames);
		for (String fieldName : sortedNames) {
			sortedData.add(sortedTrajectories.get(fieldName));
		}
		return sortedData;
	}

	/**
	 * Set the time indices for the stored data
	 * 
	 * @param storeTimes
	 *            list of hybrid time indices
	 */
	public void setStoreTimes(ArrayList<HybridTime> storeTimes) {

		arc.timeDomain = storeTimes;
	}

	/**
	 * Create a new hybrid trajectory for the specified data structure
	 * 
	 * @param system
	 *            data structure instance
	 * @param store_times
	 *            hybrid time index list to be used
	 * @return new hybrid trajectory
	 * @param <Y>
	 *            specific class of data to be loaded
	 */
	public static <Y extends DataStructure> HybridTrajectory<Y> createArc(Y system, ArrayList<HybridTime> store_times) {

		return new HybridTrajectory<Y>(system, store_times);
	}

	/**
	 * Create a new hybrid trajectory interface for the specified hybrid trajectory
	 * 
	 * @param trajectory
	 *            hybrid trajectory instance
	 * @return new hybrid trajectory interface
	 * @param <Y>
	 *            specific class of data to be loaded
	 */
	public static <Y extends DataStructure> HybridTrajectoryInterface<Y> createArc(HybridTrajectory<Y> trajectory) {

		return new HybridTrajectoryInterface<Y>(trajectory);
	}
}