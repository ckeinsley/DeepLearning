/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ RendererConfiguration.java
 * ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.chart;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Paint;
import java.awt.Stroke;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.jfree.chart.ChartColor;

import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.function.JHEQTemplate;

/**
 * A rendering configuration that determine how the data in a chart will be
 * displayed. These properties can be used to assign specific colors and
 * patterns to object sets in order to distinguish them.
 * 
 * Intended Operator: User
 */
public class RendererConfiguration implements JHEQTemplate {

	/**
	 * Map of colors assigned to specific items
	 */
	private HashMap<String, Paint> assignedSeriesColors;

	/**
	 * Map of strokes assigned to specific items
	 */
	private HashMap<String, Stroke> assignedSeriesStrokes;

	/**
	 * default flow stroke to be used whenever stroke is not specified
	 */
	private Stroke standardFlowStroke;

	/**
	 * default flow stroke to be used when stroke is not specified
	 */
	private Stroke standardJumpStroke;

	/**
	 * collection of series colors used to render lines
	 */
	private ArrayList<Paint> standardSeriesColors;

	private boolean includeVarNameInLabel;

	/**
	 * Construct a new renderer property configuration
	 */
	public RendererConfiguration() {

		initialize();
	}

	/**
	 * Assign a color to all elements that match the specified label
	 * 
	 * @param label
	 *            the variable name of the element to be painted
	 * @param color
	 *            the color said variable will be painted
	 *
	 */
	public void assignSeriesColor(String label, Paint color) {

		assignedSeriesColors.put(label, color);
	}

	/**
	 * Assign a stroke to all elements that match the specified label
	 * 
	 * @param label
	 *            the variable name of the element to be assigned a new stroke
	 * @param color
	 *            the color that will be assigned to objects matching the specified
	 *            label
	 */
	public void assignSeriesStroke(String label, Stroke color) {

		assignedSeriesStrokes.put(label, color);
	}

	/**
	 * Gets the series color for a specified series index
	 * 
	 * @param index
	 *            the index to be selected
	 * @return the color that series will be painted
	 */
	public Paint getSeriesColor(Integer index) {

		Integer adj = Math.floorMod(index, standardSeriesColors.size() - 1);
		Paint color = standardSeriesColors.get(adj);
		return color;
	}

	/**
	 * Gets the series color for a specified element label
	 * 
	 * @param series_name
	 *            the name of the element that will be selected
	 * @return the color that series will be painted
	 */
	public Paint getSeriesColor(String series_name) {

		Paint color = null;
		if (series_name != null) {
			for (String assignedColor : assignedSeriesColors.keySet()) {
				if (series_name.contains(assignedColor)) {
					color = assignedSeriesColors.get(assignedColor);
				}
			}
		}
		return color;
	}

	/**
	 * Gets the series stroke for a specified element label
	 * 
	 * @param series_name
	 *            the name of the element that will be selected
	 * @return the stroke that series will be painted
	 */
	public Stroke getSeriesStroke(String series_name) {

		Stroke color = standardFlowStroke;
		if (series_name != null) {
			for (String assignedColor : assignedSeriesColors.keySet()) {
				if (series_name.contains(assignedColor)) {
					color = assignedSeriesStrokes.get(assignedColor);
				}
			}
		}
		return color;
	}

	/**
	 * Get the standard stroke used to draw flows between data points
	 * 
	 * @return the standard stroke
	 */
	public Stroke getStandardFlowStroke() {

		return standardFlowStroke;
	}

	/**
	 * Get the standard stroke used to draw jumps between data points
	 * 
	 * @return the standard jump
	 */
	public Stroke getStandardJumpStroke() {

		return standardJumpStroke;
	}

	/**
	 * Initialize the components of a new renderer property configuration
	 */
	private void initialize() {

		standardSeriesColors = getDefaultStandardSeriesColors();

		float dash1[] =
			{ 2.0f };

		assignedSeriesColors = new HashMap<String, Paint>();
		assignedSeriesStrokes = new HashMap<String, Stroke>();
		assignedSeriesColors.put("exampleStateName", new Color(230, 230, 230));
		assignedSeriesStrokes.put("exampleStateName",
				new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1.0f, dash1, 2.0f));
		setIncludeVarNameInLabel(false);
		standardJumpStroke = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1.0f, dash1, 2.0f);
		standardFlowStroke = new BasicStroke(1.5f);

	}

	/**
	 * Sets the standard flow stroke used to draw all flows sections
	 * 
	 * @param flowStroke
	 *            the stroke to use for all flows without explicit flow definitions
	 */
	public void setStandardFlowStroke(Stroke flowStroke) {

		this.standardFlowStroke = flowStroke;
	}

	/**
	 * Sets the standard jump stroke used to draw all jump sections
	 * 
	 * @param jumpStroke
	 *            the stroke to use for all jumps
	 */
	public void setStandardJumpStroke(Stroke jumpStroke) {

		this.standardJumpStroke = jumpStroke;
	}

	/**
	 * Sets the standard series of colors that are used to plot each series in a
	 * plot
	 * 
	 * @param colors
	 *            a list of colors that will be used to paint each series instead of
	 *            the defaults
	 */
	public void setStandardSeriesColors(ArrayList<Paint> colors) {

		standardSeriesColors = colors;
	}

	/**
	 * Get the library default set of series colors that are used
	 * 
	 * @return the library default set of colors
	 */
	public static ArrayList<Paint> getDefaultStandardSeriesColors() {

		return new ArrayList<Paint>(Arrays.asList(ChartColor.createDefaultPaintArray()));
	}

	/**
	 * @return the includeVarNameInLabel
	 */
	public boolean isIncludeVarNameInLabel() {

		return includeVarNameInLabel;
	}

	/**
	 * @param includeVarNameInLabel
	 *            the includeVarNameInLabel to set
	 */
	public void setIncludeVarNameInLabel(boolean includeVarNameInLabel) {

		this.includeVarNameInLabel = includeVarNameInLabel;
	}

	@Override
	public void createTemplate(File file) {

		RendererConfiguration config = new RendererConfiguration();
		XMLFileTools.save(config, new File(file, "/chart/chartRendererConfig.xml"));

	}

}
