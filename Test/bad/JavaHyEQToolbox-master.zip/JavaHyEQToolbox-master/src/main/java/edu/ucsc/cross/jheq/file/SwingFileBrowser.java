
package edu.ucsc.cross.jheq.file;

import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.GridLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import javax.swing.JFileChooser;
import javax.swing.JPanel;

import com.be3short.io.general.FileSystemInteractor;

import edu.ucsc.cross.jheq.figure.GraphicFormat;
import edu.ucsc.cross.jheq.figure.GraphicFormatFilter;
import edu.ucsc.cross.jheq.figure.GraphicFormatSelector;
import edu.ucsc.cross.jheq.logging.Console;

public class SwingFileBrowser {

	public static class Test {

		private static int result;

		static File file = null;

		public static void main(String[] args) throws Exception {

			EventQueue.invokeAndWait(new Runnable() {

				@Override
				public void run() {

					String folder = System.getProperty("user.dir");
					JFileChooser fc = new JFileChooser(folder);
					HashMap<String, GraphicFormat> formats = GraphicFormat.getFormatMap();

					GraphicFormatSelector<GraphicFormat> gs = new GraphicFormatSelector<GraphicFormat>(formats);
					fc.addChoosableFileFilter(new GraphicFormatFilter<GraphicFormat>(GraphicFormat.PDF));
					JPanel panel = new JPanel(new GridLayout(2, 1));
					JPanel label = new JPanel();
					panel.add(gs.getChoicePanel(), 0);
					panel.add(label, 1);
					panel.setVisible(true);
					result = fc.showSaveDialog(label);

					file = fc.getSelectedFile();
				}
			});
			System.out.println(result + " file " + file.toString());
		}
	}

	/**
	 * Open a file browser window
	 * 
	 * @param save
	 *            flag to open save dialog
	 * @return file the file selected by the window, or null if nothing was selected
	 */
	static File openFileWindow(boolean save) {

		int mode = FileDialog.LOAD;
		File file = null;
		if (save) {
			mode = FileDialog.SAVE;
		}
		try {
			final FileDialog fc = new java.awt.FileDialog((java.awt.Frame) null, "Save File", mode);
			fc.setVisible(true);
			file = new File(fc.getDirectory(), fc.getFile());
			FileSystemInteractor.checkDirectory(file.getParent(), true);
		} catch (Exception noFile) {
			String operation = "load selection";
			if (save) {
				operation = "save definition";
			}
			Console.info(operation + " cancelled");
		}
		return file;

	}

	public static File file(String title, boolean save) {

		return openDialog(title, true, save);
	}

	public static File directory(String title, boolean save) {

		return openDialog(title, false, save);
	}

	public static File openDialog(String title, boolean file_select, boolean save) {

		JFileChooser chooser;
		chooser = new JFileChooser();
		chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
		chooser.setDialogTitle(title);
		if (!file_select) {
			chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		} else {
			chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		}
		chooser.setControlButtonsAreShown(true);
		if (save) {
			chooser.setDialogType(JFileChooser.SAVE_DIALOG);
		} else {
			chooser.setDialogType(JFileChooser.OPEN_DIALOG);
		}
		return openFileDialog(chooser);
	}

	public static JPanel

			generatePanel() {

		JPanel panel = new JPanel();
		panel.setSize(500, 750);
		return panel;
	}

	public static File save(String title) {

		JFileChooser chooser;
		chooser = new JFileChooser();
		chooser.setCurrentDirectory(new java.io.File("."));
		chooser.setDialogTitle(title);
		chooser.setDialogType(JFileChooser.SAVE_DIALOG);
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.setControlButtonsAreShown(true);
		// disable the "All files" option.
		//
		chooser.setAcceptAllFileFilterUsed(false);
		return openFileDialog(chooser);

	}

	public static void handleDialog(JFileChooser fc, ArrayList<File> files) {

		try {
			EventQueue.invokeAndWait(new Runnable() {

				@Override
				public void run() {

					if (fc.getDialogType() == JFileChooser.SAVE_DIALOG) {
						fc.showSaveDialog(null);
						if (fc.getFileSelectionMode() == JFileChooser.DIRECTORIES_ONLY) {
							files.add(fc.getSelectedFile());
						} else {
							files.add(fc.getSelectedFile());
							files.addAll(Arrays.asList(fc.getSelectedFiles()));
						}
					} else {
						fc.showOpenDialog(null);
					}
					// if (result == JFileChooser.APPROVE_OPTION) {
					files.addAll(Arrays.asList(fc.getSelectedFile()));
					// }
				}
			});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static ArrayList<File> openFilesDialog() {

		String folder = System.getProperty("user.dir");
		JFileChooser fc = new JFileChooser(folder);
		return openFilesDialog(fc);
	}

	public static ArrayList<File> openFileDialog() {

		String folder = System.getProperty("user.dir");
		JFileChooser fc = new JFileChooser(folder);
		return openFilesDialog(fc);
	}

	public static String getFileReport(ArrayList<File> files) {

		String report = "files selected by dialog = " + files.size();
		for (File file : files) {
			if (file != null) {
				report += "\n> " + file.getAbsolutePath();
			}
		}
		return report;
	}

	public static ArrayList<File> openFilesDialog(JFileChooser fc) {

		final ArrayList<File> files = new ArrayList<File>();
		SwingFileBrowser.handleDialog(fc, files);
		Console.debug(SwingFileBrowser.getFileReport(files));
		return files;

	}

	public static File openFileDialog(JFileChooser fc) {

		final ArrayList<File> files = SwingFileBrowser.openFilesDialog(fc);
		File file = null;
		try {
			file = files.get(0);
		} catch (Exception problem) {
			problem.printStackTrace();
		}
		return file;

	}

}
