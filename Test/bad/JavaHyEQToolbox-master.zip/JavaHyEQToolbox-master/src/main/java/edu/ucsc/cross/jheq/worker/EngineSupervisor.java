/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ EngineSupervisor.java
 * ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.worker;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import edu.ucsc.cross.jheq.environment.EnvironmentContents;
import edu.ucsc.cross.jheq.environment.EnvironmentSettings;
import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.logging.ConsoleUtils;
import edu.ucsc.cross.jheq.trajectory.HybridTime;
import edu.ucsc.cross.jheq.trajectory.TrajectorySet;

/**
 * The main interface between all of the processing and monitoring components
 * that perform tasks and run the environment.
 * 
 * Intended Operator: System
 */
public class EngineSupervisor {

	/**
	 * Static engine instance
	 */
	private static EngineSupervisor engine;

	/**
	 * Mapping of environments to the corresponding engine supervisor
	 */
	public static HashMap<JHEQEnvironment, EngineSupervisor> operatorMap = new HashMap<JHEQEnvironment, EngineSupervisor>();

	/**
	 * List of all engine instances
	 */
	private static ArrayList<EngineSupervisor> operators = new ArrayList<EngineSupervisor>();

	/**
	 * Data collector handles data storage and removes invalid data
	 */
	DataCollector dataCollector;

	/**
	 * Domain monitor - monitors system states to trigger jump interrupts
	 */
	DomainMonitor domainMonitor;

	/**
	 * Dynamics evaluator - evaluates the dynamics of the hybrid systems
	 */
	DynamicsEvaluator dynamicsEvaluator;

	/**
	 * Hybrid systems environment linked to this engine
	 */
	JHEQEnvironment env;

	/**
	 * Integration manager - operates the integrator and handles related errors
	 */
	IntegrationManager integrationManager;

	/**
	 * Interrupt detector monitors inputs to trigger event interrupts
	 */
	InterruptDetector interruptDetector;

	/**
	 * Object manipulator - modifies objects with pointer protection
	 */
	ObjectManipulator objectManipulator;

	/**
	 * Simulation processor - processes and formats the values being simulated
	 */
	EquationMap simulationProcessor;

	/**
	 * Construct engine supervisor
	 * 
	 * @param envi
	 *            environment
	 */
	public EngineSupervisor(JHEQEnvironment envi) {

		env = envi;
		ConsoleUtils.linkEngine(this);
		setOperator(envi);
		initializeComponents();
	}

	/**
	 * Get a list containing all components
	 * 
	 * @return list of all components
	 */
	private ArrayList<Object> components() {

		return new ArrayList<Object>(Arrays.asList(dataCollector, env, objectManipulator, integrationManager,
				domainMonitor, simulationProcessor, dynamicsEvaluator));
	}

	/**
	 * Compute the total runtime of a simulation
	 * 
	 * @param start_time
	 *            initial time
	 * @param end_time
	 *            final time
	 * @return runtime
	 */
	private Double computeRunTime(Long start_time, Long end_time) {

		Double startTimeSec = start_time / 1E9;
		Double endTimeSec = end_time / 1E9;
		Double runTime = endTimeSec - startTimeSec;
		return runTime;

	}

	/**
	 * Get the data collector component
	 * 
	 * @return data collector
	 */
	public DataCollector getDataManager() {

		return dataCollector;
	}

	/**
	 * Get domain monitor
	 * 
	 * @return domain monitor
	 */
	public DomainMonitor getDomainMonitor() {

		return domainMonitor;
	}

	/**
	 * Get dynamics evaluator
	 * 
	 * @return dynamics evaluator
	 */
	public DynamicsEvaluator getDynamicsEvaluator() {

		return dynamicsEvaluator;
	}

	/**
	 * Get the hybrid systems environment
	 * 
	 * @return hybrid systems environment
	 */
	public JHEQEnvironment getEnvironment() {

		return env;
	}

	/**
	 * Get environment settings
	 * 
	 * @return environment settings
	 */
	public EnvironmentSettings getEnvironmentSettings() {

		return env.getSettings();
	}

	/**
	 * Get the system set of the environment
	 * 
	 * @return all systems within the environment
	 */
	public EnvironmentContents getEnvironmentSystems() {

		return env.getSystems();
	}

	/**
	 * Get environment time
	 * 
	 * @return environment time
	 */
	public HybridTime getEnvironmentTime() {

		return dataCollector.getEnvironmentTime();
	}

	/**
	 * Get the result trajectories of the environment
	 * 
	 * @return all trajectories of the environment states
	 */
	public TrajectorySet getEnvironmentTrajectories() {

		return env.getTrajectories();
	}

	/**
	 * Get integration manager
	 * 
	 * @return integration manager
	 */
	public IntegrationManager getIntegrationManager() {

		return integrationManager;
	}

	/**
	 * Get the interrupt detector component
	 * 
	 * @return interrupt detector
	 */
	public InterruptDetector getInterruptDetector() {

		return interruptDetector;
	}

	/**
	 * Get the object manipulator component
	 * 
	 * @return object manipulator
	 */
	public ObjectManipulator getObjectManipulator() {

		return objectManipulator;
	}

	/**
	 * Get ode interface
	 * 
	 * @return ode interface
	 */
	public EquationMap getODEInterface() {

		return simulationProcessor;
	}

	/**
	 * Initialize engine components
	 */
	public void initializeComponents() {

		simulationProcessor = new EquationMap(this);
		domainMonitor = new DomainMonitor(this);
		integrationManager = new IntegrationManager(this);
		dataCollector = new DataCollector(this);
		dynamicsEvaluator = new DynamicsEvaluator(this);
		objectManipulator = new ObjectManipulator(this);
		interruptDetector = new InterruptDetector(this);
		engine = this;
	}

	/**
	 * Prepare components for simulation
	 */
	public void prepare() {

		initializeComponents();

		setEnvironmentTime(new HybridTime(0.0, 0));
		env.clearTrajectories();
		objectManipulator.prepareComponents(this);
		dataCollector.storeInitialData();
		dataCollector.loadTrajectoryMap();
		// ZeroConfiguration.setEnvironment(getEnvironment());
	}

	/**
	 * Reset components
	 */
	public void reset() {

		try {
			if (dataCollector.getInitialData() != null) {
				dataCollector.restoreInitialData(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Run simulation
	 * 
	 * @return result trajectory set
	 */
	public TrajectorySet run() {

		engine = this;
		Long startTime = System.nanoTime();
		reset();
		prepare();
		start();
		stop();
		Console.info(
				"Environment stopped, total runtime = " + computeRunTime(startTime, System.nanoTime()) + " seconds");
		return env.getTrajectories();

	}

	/**
	 * Set environment time
	 * 
	 * @param time
	 *            new time
	 */
	public void setEnvironmentTime(HybridTime time) {

		dataCollector.setEnvironmentTime(time);
	}

	/**
	 * Set an operator to an environment
	 * 
	 * @param environment
	 *            to link
	 */
	public void setOperator(JHEQEnvironment environment) {

		operatorMap.put(environment, this);
	}

	/**
	 * Start components for simulation
	 */
	private void start() {

		// ConsoleUtils.createLogFile();
		Console.info("Environment started");
		interruptDetector.setPaused(false);
		ConsoleUtils.startSystemMonitorPrintThread();
		integrationManager.start();
	}

	/**
	 * Stop simulation if running
	 */
	public void stop() {

		try {
			env.stop();
			ConsoleUtils.killSystemMonitorThread();
			dataCollector.restoreInitialData(false);
		} catch (Exception e) {

		}
	}

	/**
	 * Get the environment that contains the specified object
	 * 
	 * @param component
	 *            object to locate
	 * @return the host environment
	 */
	public static JHEQEnvironment getContainingEnvironment(Object component) {

		for (JHEQEnvironment env : operatorMap.keySet()) {
			ArrayList<Object> objs = new ArrayList<Object>(
					Arrays.asList(env.getSystems(), env.getTrajectories(), env.getSettings()));
			if (objs.contains(component)) {
				return env;
			}
		}
		return null;
	}

	/**
	 * Get the environment that contains the specified object
	 * 
	 * @param component
	 *            object to locate
	 * @return the host environment
	 */
	public static JHEQEnvironment getEnv(Object component) {

		for (JHEQEnvironment env : operatorMap.keySet()) {
			ArrayList<Object> objs = new ArrayList<Object>(
					Arrays.asList(env.getSystems(), env.getTrajectories(), env.getSettings()));
			if (objs.contains(component)) {
				return env;
			}
			if (env.getSystems().contains(component)) {
				return env;
			}
		}
		return null;
	}

	/**
	 * Get the static engine instance
	 * 
	 * @return engine supervisor
	 */
	public static EngineSupervisor getEngine() {

		return engine;
	}

	/**
	 * Get the engine supervisor paired with the specified environment
	 * 
	 * @param environment
	 *            to pair
	 * @return engine supervisor
	 */
	public static EngineSupervisor getOperator(JHEQEnvironment environment) {

		if (!operatorMap.containsKey(environment)) {
			operatorMap.put(environment, new EngineSupervisor(environment));
		}
		return EngineSupervisor.operatorMap.get(environment);
	}

	/**
	 * Get the engine supervisor that contains a specified object
	 * 
	 * @param object
	 *            to locate
	 * @return host engine supervisor
	 */
	public static EngineSupervisor getOperator(Object object) {

		EngineSupervisor op = null;
		if (operators.size() > 0) {
			op = operators.get(0);
		}
		for (EngineSupervisor operator : operators) {
			if (operator.components().contains(object)) {
				op = operator;
			}
		}
		return op;
	}

	/**
	 * Get the environment that contains the specified hybrid system
	 * 
	 * @param sys
	 *            system to locate
	 * @return the host environment
	 */

}
