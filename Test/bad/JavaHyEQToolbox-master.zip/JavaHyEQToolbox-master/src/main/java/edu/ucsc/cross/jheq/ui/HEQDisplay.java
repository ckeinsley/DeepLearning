
package edu.ucsc.cross.jheq.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

import edu.ucsc.cross.jheq.application.CoreFeatures;
import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.logging.ConsoleUtils;

public class HEQDisplay {

	JHEQToolbox hse;

	JPanel contentPanel;

	JPanel taskButtonPanel;

	ToolboxTaskBar toolboxButtonPanel;

	JTabbedPane tabPanel;

	HashMap<Button, TextField> buttonMap;

	PrintStream pw;

	TextAreaOutputStream console;

	/**
	 * @return the console
	 */
	public TextAreaOutputStream getConsole() {

		return console;
	}

	JFrame frame;

	/**
	 * @return the frame
	 */
	public JFrame getFrame() {

		return frame;
	}

	public HEQDisplay(JHEQToolbox hse) {

		this.hse = hse;
		if (console == null) {
			console = new TextAreaOutputStream();
			pw = new PrintStream(console);
			System.setOut(pw);
			ConsoleUtils.setNewOutputStream(console);
			// console = new TextAreaOutputStream();
			// pw = new PrintStream(console);
			// System.setOut(pw);
			// ConsoleUtils.setNewOutputStream(console);
		}
	}

	public HEQDisplay() {

		// this.hse = new HEQToolbox();
	}

	public void start() {

		boolean pack = false;
		this.contentPanel = new JPanel(new BorderLayout());
		if (frame == null) {
			frame = new JFrame();
			pack = true;
		}
		populate();
		frame.setContentPane(contentPanel);
		if (pack) {
			frame.pack();
		}
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public JPanel generatePanel(String title, ArrayList<String> features, ArgumentSelector args) {

		JPanel pane = new JPanel(new BorderLayout());
		TitledPanel contentPanelx = new TitledPanel(title, Color.BLACK);
		contentPanelx.setLayout(new BorderLayout());
		JPanel p = new JPanel();
		p.setLayout(new GridLayout(features.size(), 1));
		Collections.sort(features);
		for (String feature : features) {

			MenuChooser buttonAc = new MenuChooser(feature, args.getArgs(), args.enable, hse);
			JButton button = new JButton();// feature);
			button.setLayout(new BorderLayout());
			button.add(BorderLayout.CENTER, new JLabel(feature));
			button.addActionListener(buttonAc);
			// button.setMaximumSize(new Dimension(220, 25));
			// button.setPreferredSize(new Dimension(220, 25));

			// JPanel bp = new JPanel(new BorderLayout());
			// bp.add(BorderLayout.CENTER, button);
			// bp.add(BorderLayout.PAGE_END, args);
			p.add(button);

		}
		contentPanelx.add(BorderLayout.CENTER, new JScrollPane(p));
		pane.add(BorderLayout.CENTER, contentPanelx);

		pane.add(BorderLayout.PAGE_END, args.getPanel());
		return pane;

	}

	public void refreshOperations() {

		ArgumentSelector args = new ArgumentSelector("Task Arguments");
		ArrayList<String> features = new ArrayList<String>(hse.getDatabase().getTaskList().keySet());
		try {
			contentPanel.remove(toolboxButtonPanel.getPanel());

			taskButtonPanel = generatePanel("Project Tasks", features, args);
			contentPanel.add(BorderLayout.PAGE_START, toolboxButtonPanel.getPanel());
		} catch (Exception e) {

		}

	}

	private void populate() {

		buttonMap = new HashMap<Button, TextField>();
		ArgumentSelector args = new ArgumentSelector("Task Arguments");
		ArrayList<String> features = new ArrayList<String>(hse.getDatabase().setupContentIndex().keySet());

		taskButtonPanel = generatePanel("Project Tasks", features, args);
		features = new ArrayList<String>(CoreFeatures.CoreFeature.getCoreLabels(true));
		toolboxButtonPanel = new ToolboxTaskBar(hse, args);

		// toolboxButtonPanel.getComponent(0).setPreferredSize(new Dimension(200, (int)
		// 500));
		JPanel consolePanel = new JPanel(new BorderLayout());

		JPanel cpanel = new TitledPanel("System Console", Color.BLACK);
		cpanel.setLayout(new BorderLayout());
		cpanel.add(BorderLayout.CENTER, new JScrollPane(console.getTextControl()));
		consolePanel.add(BorderLayout.CENTER, cpanel);// console.getTextControl()));
		ConsoleInputBar in = new ConsoleInputBar(hse);
		consolePanel.add(BorderLayout.PAGE_END, in.getPanel());
		// toolboxButtonPanel.setMaximumSize(new Dimension(120, (int)
		// toolboxButtonPanel.getPreferredSize().getHeight()));
		// taskButtonPanel.setMaximumSize(new Dimension(220, (int)
		// taskButtonPanel.getPreferredSize().getHeight()));
		// tabPanel.setMaximumSize(new Dimension(120, (int)
		// toolboxButtonPanel.getPreferredSize().getHeight()));
		// toolboxButtonPanel
		// .setPreferredSize(new Dimension(120, (int)
		// toolboxButtonPanel.getPreferredSize().getHeight()));
		// taskButtonPanel.setPreferredSize(new Dimension(220, (int)
		// taskButtonPanel.getPreferredSize().getHeight()));

		// tabPanel.add("Project Tasks", new JScrollPane(taskButtonPanel));
		// contentPanel.add(BorderLayout.NORTH, new JLabel("JavaHyEQ Toolbox", new
		// Font("Times")));
		JPanel lPanel = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		GridBagConstraints l = new GridBagConstraints();
		l.weightx = .25;
		c.weightx = .75;
		l.weighty = 1.0;
		c.weighty = 1.0;
		c.fill = GridBagConstraints.BOTH;
		l.fill = GridBagConstraints.BOTH;
		c.gridx = 1;
		lPanel.add(taskButtonPanel, l);
		lPanel.add(consolePanel, c);
		contentPanel.add(BorderLayout.CENTER, lPanel);
		// contentPanel.add(BorderLayout.CENTER, consolePanel);
		// contentPanel.add(BorderLayout.LINE_START, taskButtonPanel);
		contentPanel.add(BorderLayout.PAGE_START, toolboxButtonPanel.getPanel());
	}

	public static void main(String args[]) {

		HEQDisplay app = new HEQDisplay();
		app.start();
	}

	public static class ArgumentSelector {

		private JPanel panel;

		/**
		 * @return the panel
		 */
		public JPanel getPanel() {

			return panel;
		}

		final Button clear;

		final TextField args;

		/**
		 * @return the args
		 */
		public TextField getArgs() {

			return args;
		}

		final JCheckBox enable;

		public ArgumentSelector(String title) {

			args = new TextField();
			enable = new JCheckBox();
			clear = new Button("X");
			panel = new TitledPanel(title, Color.BLACK);
			panel.setLayout(new GridBagLayout());
			GridBagConstraints c = new GridBagConstraints();

			c.gridy = 0;
			c.weightx = 0;
			c.fill = GridBagConstraints.NONE;
			GridBagConstraints a = new GridBagConstraints();

			a.gridy = 0;
			a.weightx = 1;
			a.fill = GridBagConstraints.HORIZONTAL;
			GridBagConstraints e = new GridBagConstraints();

			e.gridy = 0;
			e.weightx = 0;
			e.fill = GridBagConstraints.NONE;

			// panel.setMaximumSize(new Dimension(120, 25));
			// panel.setPreferredSize(new Dimension(400, 25));
			clear.setPreferredSize(new Dimension(45, 25));
			clear.setMaximumSize(new Dimension(45, 25));
			enable.setPreferredSize(new Dimension(25, 25));
			enable.setMaximumSize(new Dimension(25, 25));
			args.setMaximumSize(new Dimension(400, 20));
			// args.setPreferredSize(new Dimension(400, 25));
			enable.addActionListener(new ArgumentSelectorEnable(args, enable));
			clear.addActionListener(new ArgumentSelectorClear(args, clear));
			panel.add(clear, c);
			panel.add(args, a);
			panel.add(enable, e);
			// GridBagLayout gb = (GridBagLayout) panel.getLayout();
			// gb.setConstraints(clear, c);
			// gb.setConstraints(enable, e);
			// gb.setConstraints(args, a);
			// panel.add(BorderLayout.LINE_START, clear);
			// panel.add(BorderLayout.LINE_END, enable);
			// panel.add(BorderLayout.CENTER, args);
		}

	}

	public static class ArgumentSelectorEnable implements ActionListener {

		final TextField args;

		final JCheckBox enable;

		public ArgumentSelectorEnable(TextField args, JCheckBox enable) {

			this.args = args;
			this.enable = enable;
		}

		@Override
		public void actionPerformed(ActionEvent e) {

			args.setEnabled(enable.isSelected());
		}

	}

	public static class ArgumentSelectorClear implements ActionListener {

		final TextField args;

		final Button enable;

		public ArgumentSelectorClear(TextField args, Button enable) {

			this.args = args;
			this.enable = enable;
		}

		@Override
		public void actionPerformed(ActionEvent e) {

			args.setText(" ");
			args.getParent().repaint();

		}

	}

	public static class MenuChooser implements ActionListener {

		JHEQToolbox hse;

		JCheckBox enable;

		final TextField args;

		final String title;

		public MenuChooser(String title, TextField args, JCheckBox enable, JHEQToolbox hse) {

			this.title = title;
			this.args = args;
			this.hse = hse;
			this.enable = enable;
		}

		protected Runnable createTask() {

			return new Runnable() {

				@Override
				public void run() {

					performTask();
				}
			};

		}

		@Override
		public void actionPerformed(ActionEvent e) {

			// if (title.equals(CoreFeatures.CoreFeature.RUN_EMV))
			{
				// if (!title.equals(CoreFeatures.CoreFeature.TEMPLATE_BUILD.index)
				// && !title.equals(CoreFeatures.CoreFeature.EXECUTE_FEATURE.index)
				// && CoreFeatures.CoreFeature.isCoreIndex(title)) {
				Thread thread = new Thread(createTask());
				thread.start();
			} // else
			{
				// performTask
			}
			// } else {
			// performTask();
			// }
		}

		public void performTask() {

			try {
				String argText = "";
				if (args.isEnabled()) {
					if (args.getText().length() > 0) {
						args.setEnabled(false);
						enable.setSelected(false);
						argText = " " + args.getText();
					}
				}
				hse.executeCommands(title + argText);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
