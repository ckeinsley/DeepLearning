
package edu.ucsc.cross.jheq.figure;

import java.io.File;

import javax.swing.filechooser.FileFilter;

import com.be3short.io.format.FileFormatProperties;

public class GraphicFormatFilter<T extends FileFormatProperties<T>> extends FileFilter {

	T formatProps;

	public GraphicFormatFilter(T format) {

		formatProps = format;
	}

	@Override
	public boolean accept(File f) {

		return formatProps.getUtilities().isFileFormat(f);
	}

	@Override
	public String getDescription() {

		// TODO Auto-generated method stub
		return formatProps.getUtilities().getFileFormat().getFormatName();
	}

}
