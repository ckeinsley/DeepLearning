
package edu.ucsc.cross.jheq.function;

import java.io.File;

public interface JHEQTemplate {

	public void createTemplate(File location);

}
