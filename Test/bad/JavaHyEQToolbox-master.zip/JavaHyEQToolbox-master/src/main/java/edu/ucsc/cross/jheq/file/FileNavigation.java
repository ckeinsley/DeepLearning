
package edu.ucsc.cross.jheq.file;

import java.io.File;

public interface FileNavigation {

	public File file(String title, boolean directory_select);

	public File directory(String title, boolean save);
}
