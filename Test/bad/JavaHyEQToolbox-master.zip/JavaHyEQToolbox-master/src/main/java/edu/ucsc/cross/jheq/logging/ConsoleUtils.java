/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * ConsoleUtils.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 * 01-August-2018 : Updated progress computation to include jumps (BS);
 *
 */

package edu.ucsc.cross.jheq.logging;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.be3short.io.info.SystemInfo;

import edu.ucsc.cross.jheq.specification.MessageType;
import edu.ucsc.cross.jheq.trajectory.HybridTime;
import edu.ucsc.cross.jheq.worker.EngineSupervisor;

/**
 * The output generator for a running environment that provides status updates
 * and monitors the progress in a separate thread to consistently verify correct
 * operation.
 * 
 * Intended Operator: System
 */
public class ConsoleUtils {

	static PrintStream pw;

	/**
	 * Engine that is linked to the system output
	 */
	static EngineSupervisor linkedEngine;

	/**
	 * Print writer that is writing a console log file (if enabled)
	 */
	static PrintWriter logFileOut;

	/**
	 * Time to print next progress update statement
	 */
	static Double nextProgressUpdatePrintTime;

	/**
	 * Time (real) to print the next system update
	 */
	static Double nextSystemMonitorPrintTime;

	/**
	 * Output stream that can change where console prints to
	 */
	static OutputStream out;

	/**
	 * Interval between progress update print statements
	 */
	static Double progressUpdatePrintInterval;

	/**
	 * Date format for all console messages
	 */
	static SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS");

	/**
	 * System information gatherer
	 */
	static SystemInfo sysInfo = new SystemInfo();

	/**
	 * Thread that prints system status periodically, is sepearate from main thread
	 * so it will still print if main is stuck
	 */
	static Thread systemMonitorThread;

	/**
	 * Current environment time
	 */
	HybridTime environmentTime;

	/**
	 * Close the console log file
	 */
	public static void closeLogFile() {

		try {
			ConsoleUtils.logFileOut.close();
		} catch (Exception e) {

		}
	}

	/**
	 * Compile the prefix of a console message
	 * 
	 * @param label
	 *            message category label
	 * @return prefix string
	 */
	static String compileMessagePrefix(String label) {

		Runtime.getRuntime().totalMemory();
		String prefix = "[" + sdf.format(new Date()) + "][" + label + "]";
		return prefix;
	}

	/**
	 * Compile the suffix of a console message
	 * 
	 * @return suffix string
	 */
	static String compileMessageSuffix() {

		Runtime.getRuntime().totalMemory();
		String memoryUsage = String.valueOf((int) Math.round(sysInfo.usedMem() / (Math.pow(1024.0, 2))) + "/"
				+ String.valueOf((int) Math.round(sysInfo.totalMem() / (Math.pow(1024.0, 2)))));
		String prefix = "  [" + memoryUsage + " mB]";
		return prefix;
	}

	/**
	 * Create the console log file
	 */
	public static void createLogFile() {

		File executionDirectory = new File(ConsoleSettings.defaultOutputDirectory);
		executionDirectory.mkdirs();
		if (Console.getSettings().printLogToFile) {
			if (logFileOut == null) {
				try {
					ConsoleUtils.logFileOut = new PrintWriter(
							new FileOutputStream(new File(ConsoleSettings.defaultOutputDirectory + "/"
									+ (new SimpleDateFormat("M_d_yy_HH_mm_ss_SSS")).format(new Date()) + ".txt")));
				} catch (FileNotFoundException e) {

				}

			}
		}
	}

	/**
	 * Get the linked engine
	 * 
	 * @return linked engine
	 */
	static EngineSupervisor getEngine() {

		if (linkedEngine == null) {
			linkedEngine = EngineSupervisor.getOperator(null);
		}
		return linkedEngine;
	}

	/**
	 * Determine if print statements are enabled for a message type
	 * 
	 * @param type
	 *            message type to check if print is enabled
	 * @return true if print is enabled, false otherwise
	 */
	static boolean isPrintOutEnabled(MessageType type) {

		switch (type) {
		case INFO: {
			return Console.getSettings().printInfo;

		}
		case DEBUG: {
			return Console.getSettings().printDebug;

		}
		case WARN: {
			return Console.getSettings().printWarning;

		}
		case ERROR: {
			return Console.getSettings().printError;

		}
		default: {
			return true;
		}
		}

	}

	/**
	 * Terminate the system monitor print thread
	 */
	@SuppressWarnings("deprecation")
	public static void killSystemMonitorThread() {

		ConsoleUtils.systemMonitorThread.stop();
	}

	/**
	 * Link a hybrid systems engine to the system output
	 * 
	 * @param engine
	 *            engine to link
	 */
	public static void linkEngine(EngineSupervisor engine) {

		linkedEngine = engine;
	}

	/**
	 * Compile and print a console message
	 * 
	 * @param label
	 *            message category label
	 * @param message
	 *            string to be printed
	 * @param type
	 *            message type of the print statement
	 */
	static void print(String label, String message, MessageType type) {

		if (ConsoleUtils.isPrintOutEnabled(type)) {
			String statement = compileMessagePrefix(label) + " " + message + compileMessageSuffix();
			try {
				if (out != null) {
					out.write(statement.getBytes());
				} else {
					if (type.equals(MessageType.ERROR)) {
						System.err.println(statement);
					} else {
						System.out.println(statement);
					}
				}
				if (logFileOut != null) {
					logFileOut.println(statement);
					logFileOut.flush();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Compile and print a console message
	 * 
	 * @param label
	 *            message category label
	 * @param message
	 *            string to be printed
	 * @param throwable
	 *            throwable error included with the message
	 * @param type
	 *            message type of the print statement
	 */
	static void print(String label, String message, Throwable throwable, MessageType type) {

		String statement = compileMessagePrefix(label) + " " + message + compileMessageSuffix();
		try {
			if (out != null) {
				out.write(statement.getBytes());
			} else {

				System.out.println(statement);

			}
			if (logFileOut != null) {
				logFileOut.println(statement);
				logFileOut.flush();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		throwable.printStackTrace();
		if (logFileOut != null) {
			throwable.printStackTrace(logFileOut);
			logFileOut.flush();
		}
	}

	/**
	 * Print out the final progress update for a given engine
	 * 
	 * @param engine
	 *            the engine whose progress will be printed
	 */
	public static void printCompleteStatus(EngineSupervisor engine) {

		if (Console.getSettings().printProgressIncrement > 0) {
			Console.info("update : " + String.format("%2.2f", 100.0) + "%  complete : sim time = "
					+ ConsoleUtils.getEngine().getObjectManipulator().getSimulationTime() + " : jumps = "
					+ ConsoleUtils.getEngine().getObjectManipulator().getHybridSimTime().getJumps());
		}

	}

	/**
	 * Print the next progress update if ready
	 * 
	 * @param engine
	 *            engine whose progress will be printed
	 */
	public static void printInfoStatus(EngineSupervisor engine) {

		ConsoleUtils.printInfoStatus(engine, false);
	}

	/**
	 * Print the next progress update if ready
	 * 
	 * @param engine
	 *            engine whose progress will be printed
	 * @param override_time
	 *            flag indicating that the progress update should be printed
	 *            regardless if next update time has been reached
	 */
	public static void printInfoStatus(EngineSupervisor engine, boolean override_time) {

		if ((ConsoleUtils.getEngine().getObjectManipulator()
				.getSimulationTime() >= ConsoleUtils.nextProgressUpdatePrintTime)
				|| (ConsoleUtils.getEngine().getObjectManipulator()
						.getSimulationTime() >= ConsoleUtils.nextProgressUpdatePrintTime)
				|| override_time) {

			Double percentComplete = computePercentComplete();
			Console.info("status: " + String.format("%.2f", percentComplete) + "%  complete : sim time = "
					+ String.format("%.2f", ConsoleUtils.getEngine().getObjectManipulator().getSimulationTime())
					+ " : jumps = " + ConsoleUtils.getEngine().getObjectManipulator().getHybridSimTime().getJumps());
			if (ConsoleUtils.getEngine().getObjectManipulator()
					.getSimulationTime() >= ConsoleUtils.nextProgressUpdatePrintTime) {
				ConsoleUtils.nextProgressUpdatePrintTime = ConsoleUtils.getEngine().getObjectManipulator()
						.getSimulationTime() + ConsoleUtils.progressUpdatePrintInterval;
			}
		}
	}

	/**
	 * Print the system status update
	 */
	private static void printSystemStatus() {

		if (ConsoleUtils.nextSystemMonitorPrintTime < System.currentTimeMillis()) {
			if (ConsoleUtils.getEngine().getInterruptDetector().isRunning()) {
				Double percentComplete = computePercentComplete();
				Console.info("monitor : " + String.format("%.2f", percentComplete) + "% complete : sim time = "
						+ String.format("%.2f", ConsoleUtils.getEngine().getObjectManipulator().getSimulationTime())
						+ " : jumps = "
						+ ConsoleUtils.getEngine().getObjectManipulator().getHybridSimTime().getJumps());
				ConsoleUtils.nextSystemMonitorPrintTime = System.currentTimeMillis()
						+ Console.getSettings().printStatusInterval * 1000.0;
			}
		}
	}

	/**
	 * Compute the progress of the current environment trial as a percentage
	 * 
	 * @return the percentage completed
	 */
	public static Double computePercentComplete() {

		Double timePercentComplete = 100 * ConsoleUtils.getEngine().getObjectManipulator().getSimulationTime()
				/ ConsoleUtils.getEngine().getEnvironmentSettings().maximumTime;
		Double jumpPercentComplete = (double) (100
				* ConsoleUtils.getEngine().getObjectManipulator().getHybridSimTime().getJumps()
				/ ConsoleUtils.getEngine().getEnvironmentSettings().maximumJumps);
		Double percentComplete = Math.max(timePercentComplete, jumpPercentComplete);
		return percentComplete;

	}

	/**
	 * Set the output stream to a different location
	 * 
	 * @param output
	 *            the output stream that the console will print to
	 */
	public static void setNewOutputStream(OutputStream output) {

		ConsoleUtils.out = output;
		// System.setOut(pw);
		// System.setErr(pw);
	}

	/**
	 * Start the thread that prints periodic system statuses
	 */
	public static void startSystemMonitorPrintThread() {

		nextSystemMonitorPrintTime = System.currentTimeMillis() + Console.getSettings().printStatusInterval * 1000.0;
		progressUpdatePrintInterval = getEngine().getEnvironmentSettings().maximumTime
				/ Console.getSettings().printProgressIncrement;
		nextProgressUpdatePrintTime = 0.0;
		ConsoleUtils.systemMonitorThread = new Thread(new Runnable() {

			public void run() {

				systemMonitorPrintTask();
			}
		});
		ConsoleUtils.systemMonitorThread.start();
	}

	/**
	 * Task performed by the system monitor thread to periodically print the system
	 * status
	 */
	private static void systemMonitorPrintTask() {

		while (ConsoleUtils.getEngine().getInterruptDetector().isRunning()) {
			if (Console.getSettings().printStatusInterval != null) {
				if (Console.getSettings().terminateAtInput) {
					try {
						if (System.in.available() > 0) {
							linkedEngine.getInterruptDetector().setPaused(true);
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
					printSystemStatus();
				}
			}
		}
	}
}
