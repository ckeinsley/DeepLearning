/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * HybridTrajectory.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.trajectory;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;

import com.be3short.obj.modification.ObjectCloner;

import edu.ucsc.cross.jheq.file.CSVFileTools;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.object.DataStructure;

/**
 * Contains the stored points on the hybrid trajectory of a particular data
 * structure.
 *
 * Intended Operator: User
 */
public class HybridTrajectory<X extends DataStructure> {

	/**
	 * Map of the trajectories of each element indexed by its corresponding field
	 * object. This is used internally to plot the trajectories of each individual
	 * element in the set (provided that the element is a numerical value), and to
	 * reconstruct the object set of each data point. Recommended to only be used
	 * internally.
	 */
	HashMap<Field, HybridTrajectoryElement<?>> data;

	/**
	 * The object set of the trajectory
	 */
	X objectSet;

	/**
	 * Time domain of the trajectory
	 */
	ArrayList<HybridTime> timeDomain;

	/**
	 * Create new hybrid trajectory for object and a domain location
	 * 
	 * @param system
	 *            hybrid object that trajectory will be generated for
	 * @param store_times
	 *            domain of the trajectory, linked to the global set
	 */
	public HybridTrajectory(X system, ArrayList<HybridTime> store_times) {

		this.objectSet = system;
		timeDomain = (store_times);
		data = new HashMap<Field, HybridTrajectoryElement<?>>();
	}

	/**
	 * Create a new instance of a hybrid object at a specific time for use in a
	 * trajectory
	 * 
	 * @param hybrid_time
	 *            time corresponding to stored data that will be loaded
	 * @return hybrid object at specified time on trajectories
	 */
	@SuppressWarnings("unchecked")
	private X createInstance(HybridTime hybrid_time) {

		X newInstance = null;
		try {
			newInstance = (X) ObjectCloner.xmlClone(objectSet);
			newInstance.properties().setName(objectSet.properties().getName());
			for (Field field : data.keySet()) {
				try {
					field.set(newInstance, data.get(field).getStoredData(hybrid_time));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		} catch (Exception ee) {
			// TODO Auto-generated catch block
			ee.printStackTrace();
		}
		return newInstance;
	}

	/**
	 * Export the trajectory to a CSV file format
	 * 
	 * @param path
	 *            file path where attempt CSV file creation will occur
	 * 
	 * @return true if the file was created successfully, false otherwise
	 */
	public boolean exportToCSVFile(File path) {

		boolean success = true;
		try {
			CSVFileTools csv = new CSVFileTools(this);
			csv.createCSVOutput(path);
		} catch (Exception badFile) {
			success = false;
			Console.error("unable to export " + this + " to csv file " + path);
		}
		return success;
	}

	/**
	 * Finds an equivalent hybrid time as the input in the domain
	 * 
	 * @param hybrid_time
	 *            time to match in domain
	 * @return equivalent hybrid time if found, null otherwise
	 */
	private HybridTime findMatchingTime(HybridTime hybrid_time) {

		if (timeDomain.contains(hybrid_time)) {
			return hybrid_time;
		} else {
			for (HybridTime time : timeDomain) {
				if (time.isEquivalent(hybrid_time)) {
					return time;
				}
			}
		}
		return null;
	}

	/**
	 * Get the data point at specified time on the domain.
	 * 
	 * @param hybrid_time
	 *            time instant on the trajectory to get object at
	 * 
	 * @return hybrid object if the specified time instant is on the trajectory
	 *         domain
	 */
	public X getDataPoint(HybridTime hybrid_time) {

		if (hybrid_time == null) {
			return objectSet;
		} else {
			HybridTime lookupTime = findMatchingTime(hybrid_time);
			return createInstance(lookupTime);
		}
	}

	/**
	 * Get the map of all the data points in the trajectory, indexed by the hybrid
	 * time domain
	 * 
	 * @return map of all states in trajectory indexed by time domain
	 */
	public HashMap<HybridTime, X> getDataPointMap() {

		HashMap<HybridTime, X> solution = new HashMap<HybridTime, X>();

		for (HybridTime ht : timeDomain) {
			X newInstance = createInstance(ht);
			if (newInstance != null) {
				solution.put(ht, newInstance);
			}
		}

		return solution;
	}

	/**
	 * Get the last time in the domain of the trajectory
	 * 
	 * @return last hybrid time in trajectory domain
	 * 
	 */
	public HybridTime getFinalTime() {

		HybridTime finalTime = null;
		if (timeDomain.size() > 0) {
			Integer finalIndex = timeDomain.size() - 1;
			finalTime = timeDomain.get(finalIndex);
		}
		return finalTime;
	}

	/**
	 * Get the first time in the domain of the trajectory
	 *
	 * @return first hybrid time in trajectory domain
	 */
	public HybridTime getInitialTime() {

		HybridTime finalTime = null;
		if (timeDomain.size() > 0) {
			Integer finalIndex = timeDomain.size() - 1;
			finalTime = timeDomain.get(finalIndex);
		}
		return finalTime;
	}

	/**
	 * Get the complete time domain of the trajectory
	 *
	 * @return list of all times in the hybrid domain
	 */
	public ArrayList<HybridTime> getTimeDomain() {

		return timeDomain;
	}
}
/*
 * Design note : broke down the data to the trajectories of each element for
 * optimization purposes. Fields corresponding to an object that requires it to
 * be cloned (ie a non elementary object) can be identified (since cloning takes
 * a significant amount of time), as opposed to just cloning the whole object
 * every time. Right now the cloning identification is not implemented, but this
 * structure provides more flexibility for future optimizations
 */