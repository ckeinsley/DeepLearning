/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ DormandPrince853IntegratorFactory.java
 * ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.integrator;

import org.apache.commons.math3.ode.FirstOrderIntegrator;
import org.apache.commons.math3.ode.nonstiff.DormandPrince853Integrator;

/**
 * Dormand prince 853 integrator factory that creates the integrator based on the specified parameters.
 * 
 * Intended Operator: User
 */
public class DormandPrince853Factory implements FirstOrderIntegratorFactory
{

	/**
	 * Maximum step size for variable step integrator.
	 */
	public double odeMaximumStepSize = 1E-2;

	/**
	 * Ode step size if using a fixed step integrator, or minimum ode step size of a variable step integrator.
	 */
	public double odeMinimumStepSize = 1E-9;

	/**
	 * Relative tolerance of the ode solver: This tolerance is a measure of the error relative to the size of each
	 * solution component. Roughly, it controls the number of correct digits in all solution components, except those
	 * smaller than thresholds AbsTol(i).The default, 1e-3, corresponds to 0.1% accuracy.
	 */
	double odeRelativeTolerance = 1.0e-6;

	/**
	 * Absolute tolerance of the ode solver: AbsTol(i) is a threshold below which the value of the ith solution
	 * component is unimportant. The absolute error tolerances determine the accuracy when the solution approaches zero.
	 */
	public double odeSolverAbsoluteTolerance = 1.0e-6;

	/**
	 * Constructor with default parameters
	 */
	public DormandPrince853Factory()
	{

	}

	/**
	 * Constructor with specified parameters
	 * 
	 * @param ode_max_step_size
	 *            ode minimum step size
	 * @param ode_min_step_size
	 *            ode maximum step size
	 * @param ode_rel_tol
	 *            ode relative tolerance
	 * @param ode_abs_tol
	 *            ode absolute tolerance
	 */
	public DormandPrince853Factory(double ode_min_step_size, double ode_max_step_size, double ode_rel_tol,
	double ode_abs_tol)
	{

		odeMinimumStepSize = ode_min_step_size;
		odeMaximumStepSize = ode_max_step_size;

		odeRelativeTolerance = ode_rel_tol;
		odeSolverAbsoluteTolerance = ode_abs_tol;
	}

	/**
	 * Create a Dormand prince 853 integrator
	 * 
	 * @return first order integrator
	 */
	@Override
	public FirstOrderIntegrator createIntegrator()
	{

		DormandPrince853Integrator integrator = new DormandPrince853Integrator(odeMinimumStepSize, odeMaximumStepSize,
		odeSolverAbsoluteTolerance, odeRelativeTolerance);

		return integrator;
	}

	/**
	 * Determine the minimum step size of the integrator
	 * 
	 * @return minimum step size value
	 */
	@Override
	public double getMaxStepSize()
	{

		return odeMaximumStepSize;
	}
}
