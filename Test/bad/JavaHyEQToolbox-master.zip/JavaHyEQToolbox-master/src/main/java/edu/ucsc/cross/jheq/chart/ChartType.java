/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * ChartType.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.chart;

/**
 * A specification that indicates what type of plot is to be rendered. This
 * specification includes the rendering characteristics of each type.
 * 
 * Intended Operator: User
 */
public enum ChartType {
	/**
	 * Line chart where data points generate a trajectory.
	 */
	LINE(true, false),
	/**
	 * Scatter chart where data points are plotted as shapes.
	 */
	SCATTER(false, true),
	/**
	 * Line chart where data points generate a trajectory and are also plotted as
	 * shapes.
	 */
	SCATTER_WITH_LINE(true, true);

	/**
	 * Flag indicating if lines should be rendered for the given type.
	 */
	final boolean renderLines;

	/**
	 * Flag indicating if lines should be rendered for the given type.
	 */
	final boolean renderShapes;

	/**
	 * Constructs the chart type and assigns the rendering characteristics.
	 * 
	 * @param lines
	 *            flag indicating line visibility
	 * @param shapes
	 *            flag indicating shape visibility
	 */
	private ChartType(boolean lines, boolean shapes) {
		renderLines = lines;
		renderShapes = shapes;
	}
}
