package edu.ucsc.cross.jheq.integrator;

public enum IntegratorType
{
	DORMAND_PRINCE_853,
	EULER;
}
