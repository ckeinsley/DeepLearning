
package edu.ucsc.cross.jheq.function;

import edu.ucsc.cross.jheq.application.JHEQToolbox;

public interface JHEQFeature {

	public String getCallHandle();

	/**
	 * Perform the feature
	 * 
	 * @param env
	 *            environment in use
	 * @param input
	 *            user input argument string
	 * @param app
	 *            main application functionality
	 */
	public void perform(JHEQToolbox application, String input);
}
