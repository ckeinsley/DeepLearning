/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ CollectionFile.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS); 01-August-2018 : Added logic to catch null save/load files and print
 * alternate error message without throwing exception to differentiate from actual issues (BS);
 *
 */

package edu.ucsc.cross.jheq.file;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import com.be3short.io.compression.GZipper;
import com.be3short.io.general.FileSystemInteractor;
import com.be3short.obj.access.FieldFinder;
import com.be3short.obj.modification.XMLParser;

import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.model.HybridSystem;

/**
 * A file data structure that stores a collection objects to be saved/retrieved.
 * Any combination of the basic system content class objects can be
 * stored/retrieved in this file, as well as additional user defined components.
 * The basic system content classes are HybridSystems (all systems loaded into
 * the environment), HSEnvironment (entire environment, consists of all
 * components), EnvironmentSettings (settings for the environment,
 * ExecutionParameters (configuration of how an environment execution will be
 * performed), and HybridTrajectories (solution trajectories of object sets).
 * Note: All classes stored in a file must be on a projects class path in order
 * to retrieve the file successfully.
 * 
 * Intended Operator: User
 */
@SuppressWarnings(
	{ "unchecked" })
public class ArchiveFile {

	/**
	 * File Content Mapping : Stores all file contents
	 */
	private HashMap<Class<?>, ArrayList<Object>> fileContents;

	/**
	 * Create a new object collection and adds any objects specified as inputs
	 * 
	 * @param object
	 *            an object (or objects) to be added to the collection
	 */
	public ArchiveFile(Object... object) {

		initializeObjectMap();
		addObject(object);
	}

	/**
	 * Add objects to the file
	 *
	 * @param <T>
	 *            specific class of data to be loaded
	 * @param content
	 *            array of contents to be stored to new file
	 * @return
	 */
	public <T> void addObject(T... content) {

		for (T content_item : content) {

			if (content_item != null) {
				storeObject(content_item);
			}
		}
	}

	/**
	 * Get an object from the file. Returns the first object in the list if there
	 * are multiple objects of the specified class in the collection, or returns
	 * null if there are no objects of the specified class in the collections
	 * 
	 * @param object_class
	 *            class of the object to be retrieved
	 * 
	 * @return the first object in the list if there are multiple objects of the
	 *         specified class in the collection, or returns null if there are no
	 *         objects of the specified class in the collections
	 * 
	 * @param <T>
	 *            specific class of data to be loaded
	 */
	public <T> T getObject(Class<T> object_class) {

		T content = null;
		if (fileContents.containsKey(object_class)) {
			if (fileContents.get(object_class).size() > 0) {
				content = (T) fileContents.get(object_class).get(0);
			}
		}
		return content;
	}

	/**
	 * Returns a list of stored objects of the specified class.
	 * 
	 * @param object_class
	 *            class of the list of contents to be retrieved
	 * 
	 * @return content list containing objects of specified content type
	 * 
	 * @param <T>
	 *            specific class of data to be loaded
	 */
	public <T> ArrayList<T> getObjects(Class<T> object_class) {

		ArrayList<T> contents = new ArrayList<T>();
		if (fileContents.containsKey(object_class)) {
			try {
				contents.addAll((ArrayList<T>) fileContents.get(object_class));
			} catch (Exception badContents) {
				Console.error("no contents of type " + object_class + " found", badContents);
			}
		}
		return contents;
	}

	/**
	 * Initializes the content mapping with lists for all of the system objects
	 */
	private void initializeObjectMap() {

		fileContents = new HashMap<Class<?>, ArrayList<Object>>();

	}

	/**
	 * Stores all contents of the collection to a specified destination
	 * 
	 * @param output
	 *            location where file will be created
	 */
	public void saveToFile(File output) {

		saveToFile(output, true);
	}

	/**
	 * Stores all contents of the collection to a specified destination
	 * 
	 * @param output
	 *            location where file will be created
	 * 
	 * @param compressed
	 *            flag indicating if file should be compressed (HSE file) or
	 *            uncompressed (XML file)
	 */
	public void saveToFile(File output, boolean compressed) {

		if (output == null) {
			Console.error("file location is null, unable to save");
		}
		try {
			DataFormat format = DataFormat.XML;
			if (compressed) {
				format = DataFormat.HSE;
			}
			if (output != null) {
				File checkedOutput = format.getUtilities().appendExtension(output);
				String xmlString = XMLParser.serializeObject(this);
				System.out.println(checkedOutput.getAbsolutePath());
				switch (format) {
				case XML: {
					FileSystemInteractor.createOutputFile(checkedOutput, xmlString);
					Console.info("Successfully saved global storage file " + checkedOutput);
					break;
				}
				case HSE: {
					GZipper.writeCompressedObjectToFile(checkedOutput, xmlString);
					Console.info("Successfully saved global storage file " + checkedOutput);
					break;
				}
				default:
					Console.warn("Attempt to save global storage file in " + format.getFormatName()
							+ " format not suported");
					break;
				}
			} else {
				throw new NullPointerException();
			}

		} catch (Exception badFile) {
			Console.error("Unable to save file: " + output, badFile);
		}

	}

	/**
	 * Stores all contents of the collection to a specified destination
	 * 
	 * note: depreciated (8/1/2018) for saveToFile because csv formatting is now
	 * done separately leaving only two format options, which can be specified using
	 * boolean argument for compressed/uncompressed
	 * 
	 * @param output
	 *            location where file will be created
	 * @param format
	 *            file format to use
	 * 
	 */
	@Deprecated
	public void saveToFormat(File output, DataFormat format) {

		try {

			if (output != null) {
				File checkedOutput = format.getUtilities().appendExtension(output);
				String xmlString = XMLParser.serializeObject(this);
				System.out.println(checkedOutput.getAbsolutePath());
				switch (format) {
				case XML: {
					FileSystemInteractor.createOutputFile(checkedOutput, xmlString);
					Console.info("Successfully saved global storage file " + checkedOutput);
					break;
				}
				case HSE: {
					GZipper.writeCompressedObjectToFile(checkedOutput, xmlString);
					Console.info("Successfully saved global storage file " + checkedOutput);
					break;
				}
				default:
					Console.warn("Attempt to save global storage file in " + format.getFormatName()
							+ " format not suported");
					break;
				}
			} else {
				throw new NullPointerException();
			}

		} catch (Exception badFile) {
			Console.error("Unable to save file: " + output, badFile);
		}

	}

	/**
	 * Processes the storage of internal contents
	 * 
	 * @param object
	 *            to be stored
	 * @param <T>
	 *            specific class of data to be loaded
	 */
	private <T> void storeObject(T object) {

		Class<?> contentType = object.getClass();

		if (!fileContents.containsKey(contentType)) {
			fileContents.put(contentType, new ArrayList<Object>());
		}
		if (!fileContents.get(contentType).contains(object)) {
			fileContents.get(contentType).add(object);
		}
		if (contentType.equals(JHEQEnvironment.class)) {
			JHEQEnvironment env = (JHEQEnvironment) object;
			storeObject(env.getTrajectories());
			storeObject(env.getSystems());
			storeObject(env.getSettings());
			storeObject(env.getSystems());
		} else if (FieldFinder.containsSuper(object, HybridSystem.class)) {
			fileContents.get(HybridSystem.class).add(object);
		}

	}

	/**
	 * Attempt to add possible extensions to file path if specified file does not
	 * exist or does not match one of the available formats exist
	 * 
	 * @param file
	 *            file to evaluate
	 * @return adjusted file
	 */
	public static File attemptAppendedExtension(File file) {

		DataFormat fileFormat = DataFormat.HSE.getUtilities().checkFormat(file);
		if (fileFormat == null) {

			for (DataFormat format : DataFormat.values()) {
				File attempt = new File(file.getAbsolutePath() + format.getFileExtension());
				if (attempt.exists()) {
					return attempt;
				}
			}
		} else {
			return file;
		}

		return null;
	}

	/**
	 * Attempts to load the set from a file
	 * 
	 * 
	 * 
	 * @param input
	 *            file path to attempt to load from
	 * 
	 * @return HybridTrajectories set of trajectories loaded from file, or null if
	 *         trajectories couldn't be loaded from the file
	 */
	public static ArchiveFile loadFromFile(File input) {

		ArchiveFile env = null;
		if (input == null) {
			Console.error("null input file provided, unable to load content");
		} else {
			try {
				File file = attemptAppendedExtension(input);
				DataFormat format = DataFormat.HSE.getUtilities().checkFormat(file);

				switch (format) {
				case XML: {
					env = (ArchiveFile) XMLParser.getObject(file);
					break;
				}
				case HSE: {
					env = ArchiveFile.loadFromZippedFile(file);
					break;
				}
				default: {
					Console.warn("Failed to save global storage file " + file + " in unsupported format "
							+ format.getFormatName());
					break;
				}
				}
			} catch (Exception badFile) {
				Console.error("Unable to open file " + input + " due to an exception", badFile);
			}
		}
		return env;
	}

	/**
	 * Loads a stored object collection from a file
	 * 
	 * @param input_file
	 *            location of stored object collection
	 * 
	 * @return HSEFile parsed from the input file
	 */
	private static ArchiveFile loadFromZippedFile(File input_file) {

		ArchiveFile inputFile = null;
		File input = attemptAppendedExtension(input_file);
		try {
			if (!input.exists()) {

				Console.error("Non-existent file specified: " + input);
				return null;

			} else {

				if (input.getName().contains(DataFormat.HSE.getFileExtension())) {
					String inputString = GZipper.readCompressedObjectFromFile(input, String.class);
					inputFile = (ArchiveFile) XMLParser.getObjectFromString(inputString);
				} else if (input.getName().contains(DataFormat.XML.getFileExtension())) {
					inputFile = (ArchiveFile) XMLParser.getObject(input);
				}

			}
		} catch (Exception badFile) {
			Console.error("Unable to fetch file: " + input, badFile);
		}
		return inputFile;
	}

	/**
	 * * Attempts to load an object collection from a specified file location, and
	 * get an object of the specified class from that file
	 * 
	 * @param input
	 *            location of stored object collection file
	 * @param content_type
	 *            specific class of data to be loaded
	 * @return object retrieved from file, or null if unable to load file or object
	 *         of specified class type was not present
	 * @param <T>
	 *            specific class of data to be loaded
	 * 
	 */
	public static <T> T loadObjectFromFile(File input, Class<T> content_type) {

		ArchiveFile inputFile = ArchiveFile.loadFromZippedFile(input);
		T inputContent = null;
		try {
			if (inputFile != null) {

				inputContent = inputFile.getObject(content_type);

			}
		} catch (Exception badFile) {
			Console.error("Unable to fetch content " + content_type.toString() + " from file: " + input, badFile);
		}
		return inputContent;
	}

	/**
	 * Attempts to load an object collection from a specified file location, and get
	 * an object of the specified class from that file
	 * 
	 * @param input
	 *            location of stored object collection file
	 * @param content_type
	 *            class of object to be retrieved from file
	 * @return object retrieved from file, or null if unable to load file or object
	 *         of specified class type was not present
	 * @param <T>
	 *            specific class of data to be loaded
	 */
	public static <T> ArrayList<T> loadObjectsFromFile(File input, Class<T> content_type) {

		ArchiveFile inputFile = ArchiveFile.loadFromZippedFile(input);
		ArrayList<T> inputContent = new ArrayList<T>();
		try {
			ArrayList<T> content = inputFile.getObjects(content_type);
			inputContent.addAll(content);

		} catch (

		Exception badFile) {
			Console.error("Unable to fetch content " + content_type.toString() + " from file: " + input, badFile);
		}
		return inputContent;
	}

	/**
	 * Creates an object collection with the specified contents and writes the
	 * collection to the specified destination
	 * 
	 * @param output
	 *            location where file will be created
	 * 
	 * @param compressed
	 *            flag indicating if file should be compressed (HSE file) or
	 *            uncompressed (XML file)
	 * 
	 * @param contents
	 *            array of objects to be stored in the file
	 * 
	 * @return file with stored contents
	 *
	 */
	public static ArchiveFile saveToNewFile(File output, boolean compressed, Object... contents) {

		ArchiveFile outputz = new ArchiveFile(contents);
		if (compressed) {
			outputz.saveToFile(output, true);
		} else {
			outputz.saveToFile(output, false);
		}
		return outputz;

	}

	/**
	 * * Creates an object collection with the specified contents and writes the
	 * collection to the specified destination
	 * 
	 * @param output
	 *            location where file will be created
	 * 
	 * @param contents
	 *            array of contents to be stored to new file
	 * @return file containing contents
	 */
	public static ArchiveFile saveToNewFile(File output, Object... contents) {

		ArchiveFile storage = saveToNewFile(output, DataFormat.HSE, contents);
		return storage;
	}

}
