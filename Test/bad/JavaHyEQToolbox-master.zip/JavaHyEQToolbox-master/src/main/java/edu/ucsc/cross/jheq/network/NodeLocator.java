
package edu.ucsc.cross.jheq.network;

import java.util.ArrayList;
import java.util.Set;

import com.be3short.obj.access.FieldFinder;

import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.object.IndexedObject;

public class NodeLocator {

	Network network;

	Object source;

	NodeLocator(Network network, Object source) {

		this.network = network;
		this.source = source;
	}

	public <X> ArrayList<X> getAll(Class<X> target_class, Object[] search_keys) {

		return getAll(target_class, Connection.BIDIRECTIONAL, search_keys);

	}

	public <X> ArrayList<X> getAll(Class<X> target_class, Integer direction, Object[] search_keys) {

		ArrayList<X> connections = new ArrayList<X>();
		for (Object conn : getAllObjects(direction, search_keys)) {
			if (FieldFinder.containsSuper(conn, target_class)) {
				try {
					X item = target_class.cast(conn);

					connections.add(item);
				} catch (Exception badCast) {
					Console.error("unable to cast object " + conn + " to " + target_class, badCast);
				}
			}
		}
		return connections;

	}

	public <X> ArrayList<X> getAll(Class<X> target_class) {

		return getAll(target_class, Connection.BIDIRECTIONAL, IndexedObject.NONE);

	}

	public <X> ArrayList<X> getAll(Class<X> target_class, Integer direction) {

		return getAll(target_class, direction, IndexedObject.NONE);

	}

	/**
	 * Get all of the objects connected to a specified object
	 * 
	 * @param source
	 *            source vertex
	 * @return array list containing all objects that the source is connected to
	 */
	public ArrayList<Object> getAllObjects(Integer direction, Object[] search_keys) {

		ArrayList<Object> connections = new ArrayList<Object>();
		Set<Connection<Object, Object>> connectionList = network.getTopology().edgesOf(source);

		ArrayList<Connection<Object, Object>> connectionListMod = new ArrayList<Connection<Object, Object>>();
		for (Connection<Object, Object> con : connectionList) {
			if (!connectionListMod.contains(con)) {// && AccessKey.containsKey(con, search_keys)) {

				connectionListMod.add(con);
			}

		}
		// System.out.println(source + " " + connectionListMod);
		// connectionList = connectionListMod;
		for (Connection<Object, Object> connection : connectionListMod) {
			Object add = null;
			if (connection.getTarget().equals(source) && direction + 1 > 0) {
				add = (connection.getSource());
			}
			if (connection.getSource().equals(source) && direction - 1 < 0) {
				add = (connection.getTarget());
			}

			if (add != null && IndexedObject.containsKey(add, search_keys)) {
				if (!connections.contains(add)) {
					connections.add(add);
				}
			}
		}
		// System.out.println(source + " " + connections);

		return connections;
	}

	/**
	 * Get all of the objects connected to a specified object
	 * 
	 * @param source
	 *            source vertex
	 * @return array list containing all objects that the source is connected to
	 */
	public ArrayList<HybridSystem> getAllSystems(Integer direction, Object[] search_keys) {

		return getAll(HybridSystem.class, direction, search_keys);
	}

	/**
	 * Get all of the objects connected to a specified object
	 * 
	 * @param source
	 *            source vertex
	 * @return array list containing all objects that the source is connected to
	 */
	public ArrayList<HybridSystem> getAllSystems(Object[] search_keys) {

		return getAll(HybridSystem.class, Connection.BIDIRECTIONAL, search_keys);
	}

	/**
	 * Get all of the objects connected to a specified object
	 * 
	 * @param source
	 *            source vertex
	 * @return array list containing all objects that the source is connected to
	 */
	public ArrayList<HybridSystem> getAllSystems(Integer direction) {

		return getAll(HybridSystem.class, direction, IndexedObject.NONE);
	}

	/**
	 * Get all of the objects connected to a specified object
	 * 
	 * @param source
	 *            source vertex
	 * @return array list containing all objects that the source is connected to
	 */
	public ArrayList<HybridSystem> getAllSystems() {

		return getAll(HybridSystem.class, Connection.BIDIRECTIONAL, IndexedObject.NONE);
	}

	/**
	 * Get all of the objects connected to a specified object
	 * 
	 * @param source
	 *            source vertex
	 * @return array list containing all objects that the source is connected to
	 */
	public ArrayList<Object> getAllObjects() {

		return getAllObjects(Connection.BIDIRECTIONAL, IndexedObject.NONE);
	}

	/**
	 * Get all of the objects connected to a specified object
	 * 
	 * @param source
	 *            source vertex
	 * @return array list containing all objects that the source is connected to
	 */
	public ArrayList<Object> getAllObjects(Integer direction) {

		return getAllObjects(direction, IndexedObject.NONE);
	}

	public static NodeLocator create(Network network, Object source) {

		return new NodeLocator(network, source);
	}
}
