
/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ HybridSys.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 23-August-2018 : Version 1 (BS);
 * 
 */

package edu.ucsc.cross.jheq.model;

import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.network.Network;
import edu.ucsc.cross.jheq.network.NodeLocator;
import edu.ucsc.cross.jheq.object.DataStructure;
import edu.ucsc.cross.jheq.object.VariableSet;

/**
 * Generalized hybrid system with dynamics given by externally defined mappings
 * and sets.
 * 
 * @author Brendan Short
 *
 * @param <X>
 *            class type of hybrid system state
 */
public interface HybridSystem

{

	public JHEQEnvironment environment();

	public HybridSystemModel<?> model();

	public <X extends DataStructure> HybridSystemModel<X> model(Class<X> state_class);

	public Object state();

	public <X extends DataStructure> X state(Class<X> state);

	/**
	 * Get the current state of the hybrid system
	 * 
	 * @return the current state of the hybrid system
	 */

	public VariableSet variables();

	public Network network();

	public NodeLocator connections();

	public static <S extends DataStructure> HybridSystem create(Class<S> state_class, Object state, FlowMap<S> flow_map,
			JumpMap<S> jump_map, FlowSet<S> flow_set, JumpSet<S> jump_set, Object[] variables) {

		return new HybridSystemModel<S>(state_class.cast(state), flow_map, jump_map, flow_set, jump_set, variables);

	}

	public static <S extends DataStructure> HybridSystem create(S state, FlowMap<S> flow_map, JumpMap<S> jump_map,
			FlowSet<S> flow_set, JumpSet<S> jump_set, Object[] variables) {

		return new HybridSystemModel<S>(state, flow_map, jump_map, flow_set, jump_set, variables);

	}
}
