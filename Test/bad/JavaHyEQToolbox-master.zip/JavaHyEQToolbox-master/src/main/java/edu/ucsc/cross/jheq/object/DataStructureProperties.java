/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ DataStructureProperties.java
 * ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.object;

import edu.ucsc.cross.jheq.util.CollectionFormat;

/**
 * The properties of of an object set, which provides information about the set
 * and how it should be handled. This allows each object set to be named and
 * assigned a unique index to distinguish it from other instances of the same
 * object that may have the same name. It also specifies if the trajectory
 * should be stored.
 * 
 * Intended Operator: User
 */
public class DataStructureProperties {

	/**
	 * Index of the object set
	 */
	Integer index;

	/**
	 * name of the object set
	 */
	String name;

	/**
	 * flag indicating if trajectory is stored or not
	 */
	boolean storeTrajectory;

	/**
	 * flag indicating if trajectory is stored or not
	 */
	Boolean simulated;

	Object[] accessKeys;

	/**
	 * Create a new instance of properties for the specified object set
	 * 
	 * @param object_set
	 *            object set that these properties describe
	 */
	DataStructureProperties(DataStructure object_set) {

		setName(object_set.getClass().getSimpleName());
		index = 0;
		storeTrajectory = false;
		simulated = null;
	}

	/**
	 * Get the index of the object set
	 * 
	 * @return index of the object set
	 * 
	 */
	public Integer getIndex() {

		return this.index;
	}

	/**
	 * Get the name of the object set including with the index appended
	 * 
	 * @return indName appended name
	 */
	public String getIndexedName() {

		String indName = name;
		if (index > 0) {
			indName = indName + " " + index;
		}
		return indName;
	}

	/**
	 * Get the name of the object
	 * 
	 * @return name of the object set
	 */
	public String getName() {

		return this.name;
	}

	/**
	 * Determine if the trajectory of the object set is stored while the environment
	 * is running
	 * 
	 * @return true if the trajectory is being stored, false otherwise
	 */
	public boolean isTrajectoryStored() {

		return this.storeTrajectory;
	}

	/**
	 * Set the name of the object set
	 * 
	 * @param name
	 *            to be assigned
	 */
	public void setName(String name) {

		this.name = name;
	}

	/**
	 * Set a flag to store the trajectory of the object set
	 * 
	 * @param store_trajectory
	 *            flag to store the trajectory of the object set or not
	 */
	public void setStoreTrajectory(boolean store_trajectory) {

		this.storeTrajectory = store_trajectory;
		;
	}

	/**
	 * Set the index of a data structure property set
	 * 
	 * @param properties
	 *            properties to edit
	 * @param index
	 *            value to use
	 */
	public static void setIndex(DataStructureProperties properties, Integer index) {

		properties.index = index;
	}

	/**
	 * @return the simulated
	 */
	public Boolean isSimulated() {

		return simulated;
	}

	/**
	 * @param simulated
	 *            the simulated to set
	 */
	public void setSimulated(Boolean simulated) {

		this.simulated = simulated;
	}

	public void addAccessKeys(Object... objs) {

		if (this.accessKeys == null) {
			this.accessKeys = CollectionFormat.array(objs);
		} else {
			Object[] newKeys = new Object[accessKeys.length + objs.length];
			int i = 0;
			for (Object obj : accessKeys) {
				newKeys[i++] = obj;
			}
			for (Object obj : objs) {
				newKeys[i++] = obj;
			}
		}
	}

	public void setAccessKeys(Object[] objs) {

		this.accessKeys = objs;
		if (this.accessKeys == null) {
			this.accessKeys = IndexedObject.NONE;
		}
	}

	public Object[] getAccessKeys() {

		if (this.accessKeys == null) {
			return new Object[]
				{};
		} else {
			return accessKeys;
		}
	}
}