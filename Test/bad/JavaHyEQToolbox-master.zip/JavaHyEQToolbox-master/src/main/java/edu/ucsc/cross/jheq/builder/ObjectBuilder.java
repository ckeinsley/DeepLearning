
package edu.ucsc.cross.jheq.builder;

import java.io.File;
import java.lang.reflect.Field;
import java.util.HashMap;

import com.be3short.obj.access.FieldFinder;

import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.function.JHEQOperation;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.object.DataStructure;
import edu.ucsc.cross.jheq.variable.Variable;

@SuppressWarnings(
	{ "unchecked", "rawtypes" })
public class ObjectBuilder<X> extends JHEQOperation {

	private X baseStructure;

	private Class<X> baseStructureClass;

	private HashMap<String, Field> fieldMap;

	private HashMap<String, Variable<?>> variableMap;

	public String importFilePath;

	public String objectName;

	ObjectBuilder(X baseStructure) {

		this.baseStructure = baseStructure;
		this.baseStructureClass = (Class<X>) baseStructure.getClass();
		this.fieldMap = null;// DataStructure.getFieldMap(this.baseStructure);
		this.variableMap = DataStructure.getFieldVarMap(baseStructure);
		this.importFilePath = "null";
		objectName = baseStructure.getClass().getSimpleName();
		this.baseStructure = null;
	}

	ObjectBuilder(String file_path) {

		this.baseStructure = null;
		this.fieldMap = null;
		this.variableMap = null;
		importFilePath = file_path;
	}

	public void loadSettingsFromFile() {

		if (this.importFilePath != "null")

		{
			loadSettingsFromFile(new File(this.importFilePath));
		}

	}

	public void loadSettingsFromFile(File file) {

		ObjectBuilder<X> load = XMLFileTools.loadContent(ObjectBuilder.class, file);
		this.baseStructure = load.baseStructure;
		this.fieldMap = DataStructure.getFieldMap(baseStructure);
		this.variableMap = load.variableMap;

	}

	public static <Z extends DataStructure> void createConfigFile(File file, Z base_structure) {

		ObjectBuilder<Z> gen = new ObjectBuilder<Z>(base_structure);
		gen.fieldMap = null;
		XMLFileTools.save(new ObjectBuilder<Z>(base_structure), file);

	}

	public X generate() {

		X newStructure = null;
		if (!importFilePath.equals("null")) {

			ObjectBuilder generator = XMLFileTools.loadContent(ObjectBuilder.class, new File(this.importFilePath));
			variableMap = generator.variableMap;
			baseStructureClass = generator.baseStructureClass;
			try {
				baseStructure = (X) generator.baseStructureClass.newInstance();
			} catch (InstantiationException | IllegalAccessException e) {
				e.printStackTrace();
			}

			fieldMap = DataStructure.getFieldMap(baseStructure);

		} else {
			try {
				baseStructure = baseStructureClass.newInstance();

			} catch (InstantiationException | IllegalAccessException e) {
				e.printStackTrace();
			}
		}

		try {

			newStructure = baseStructureClass.newInstance();
			fieldMap = DataStructure.getFieldMap(newStructure);
		} catch (InstantiationException | IllegalAccessException e1) {
			e1.printStackTrace();
		}

		catch (Exception e1) {
			e1.printStackTrace();
		}
		for (String fieldName : fieldMap.keySet()) {
			try {
				fieldMap.get(fieldName).set(newStructure, variableMap.get(fieldName).getValue());
			} catch (Exception e) {
				Console.error("unable to generate new variable field " + fieldName + " for "
						+ baseStructure.getClass().getSimpleName() + " with value " + variableMap.get(fieldName), e);
				e.printStackTrace();
			}

		}
		try {

			if (objectName != null) {
				if (FieldFinder.containsSuper(newStructure, DataStructure.class)) {
					DataStructure ds = (DataStructure) newStructure;

					ds.properties().setName(objectName);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newStructure;
	}

	public static <R extends DataStructure> ObjectBuilder<R> createFromFilePath(String string) {

		return new ObjectBuilder<R>(string);
	}

	public static <R extends DataStructure> ObjectBuilder<R> createFromFilePath(R structure) {

		return new ObjectBuilder<R>(structure);
	}

	/**
	 * @return the importFilePath
	 */
	public String getImportFilePath() {

		return importFilePath;
	}

	/**
	 * @param importFilePath
	 *            the importFilePath to set
	 */
	public void setImportFilePath(String importFilePath) {

		this.importFilePath = importFilePath;
	}

	@Override
	public void perform(JHEQToolbox application, String input) {

		generate();
	}

}
