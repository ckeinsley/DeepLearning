
package edu.ucsc.cross.jheq.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.ui.HEQDisplay.ArgumentSelectorClear;

public class ConsoleInputBar {

	JPanel panel;

	/**
	 * @return the panel
	 */
	public JPanel getPanel() {

		return panel;
	}

	JHEQToolbox hse;

	public ConsoleInputBar(JHEQToolbox hse) {

		this.hse = hse;
		panel = generatePanel("Console Input");

		// panel.setPreferredSize(new Dimension((int)
		// panel.getPreferredSize().getWidth(), 80));
	}

	Button clear;

	TextField args;

	/**
	 * @return the args
	 */
	public TextField getArgs() {

		return args;
	}

	Button enable;

	public JPanel generatePanel(String title) {

		args = new TextField();
		enable = new Button("Enter");
		clear = new Button("X");
		JPanel panel = new TitledPanel(title, Color.BLACK);
		panel.setLayout(new BorderLayout());
		// panel.setMaximumSize(new Dimension(120, 25));
		// panel.setPreferredSize(new Dimension(400, 25));
		clear.setPreferredSize(new Dimension(45, 25));
		enable.setPreferredSize(new Dimension(25, 25));
		// args.setMaximumSize(new Dimension(400, 25));
		enable.addActionListener(new ConsoleInputAction(args, enable, hse));
		clear.addActionListener(new ArgumentSelectorClear(args, clear));
		args.addKeyListener(new ConsoleInputEnter(args, hse));
		panel.add(BorderLayout.LINE_START, clear);
		panel.add(BorderLayout.LINE_END, enable);
		panel.add(BorderLayout.CENTER, args);
		return panel;
	}

	public static class ConsoleInputAction implements ActionListener {

		ConsoleInputEnter inputAccess;

		final TextField args;

		final Button enable;

		JHEQToolbox hse;

		public ConsoleInputAction(TextField args, Button enable, JHEQToolbox hse) {

			this.args = args;
			this.enable = enable;
			this.hse = hse;
			inputAccess = new ConsoleInputEnter(args, hse);
		}

		@Override
		public void actionPerformed(ActionEvent e) {

			// Thread thread = new Thread(inputAccess.createTask());
			// thread.start();
			String entry = args.getText();
			hse.executeCommands(entry);

			inputAccess.performTask();

		}

	}

	public static class ConsoleInputEnter implements KeyListener {

		final TextField args;

		JHEQToolbox hse;

		public ConsoleInputEnter(TextField args, JHEQToolbox hse) {

			this.args = args;

			this.hse = hse;
		}

		@Override
		public void keyTyped(KeyEvent e) {

			// TODO Auto-generated method stub

		}

		protected Runnable createTask() {

			return new Runnable() {

				@Override
				public void run() {

					performTask();
				}
			};

		}

		@Override
		public void keyPressed(KeyEvent e) {

			// TODO Auto-generated method stub

		}

		public void performTask() {

			try {
				String argText = "";
				if (args.isEnabled()) {
					if (args.getText().length() > 0) {

						argText = " " + args.getText();
					}
				}
				hse.executeCommands(args.getText());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		@Override
		public void keyReleased(KeyEvent e) {

			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				Thread thread = new Thread(createTask());
				thread.start();
			}

		}

	}
}
