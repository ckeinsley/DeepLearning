
package edu.ucsc.cross.jheq.object;

import java.util.ArrayList;
import java.util.Arrays;

import com.be3short.obj.access.FieldFinder;

import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.util.CollectionFormat;

public interface IndexedObject {

	public static final Object[] NONE = new Object[]
		{};

	public static final ArrayList<String> BLANK_INDEX = new ArrayList<String>(Arrays.asList("blank_entry", "", "null"));

	public Object[] getAccessKeys();

	public static boolean containsKey(Object object, Object[] search_keys) {

		if (search_keys.length == 0) {
			return true;
		}
		boolean contains = false;
		Object[] index = getAccessKeys(object);
		ArrayList<Object> searchKeys = CollectionFormat.list(search_keys);
		for (Object key : index) {
			if (key != null) {
				// System.out.println("key " + key);

				for (Object search : searchKeys) {
					// System.out.println("search " + search);
					if (search.getClass().equals(key.getClass())) {

						contains = contains || key.getClass().cast(search).equals(key);
					}
				}
			}
		}
		// System.out.println("index " + XMLParser.serializeObject(index));
		// System.out.println("search array" + searchKeys);
		// System.out.println("found " + contains);
		return contains;
	}

	public static Object[] getAccessKeys(Object object) {

		Object[] index = new Object[]
			{};
		// System.out.println(XMLParser.serializeObject(object.getClass().getInterfaces()));
		if (object.getClass().getInterfaces().length > 0) {
			for (Class<?> interf : object.getClass().getInterfaces()) {
				if (interf.equals(HybridSystem.class)) {
					try {
						HybridSystem indexedObj = (HybridSystem) object;
						index = indexedObj.model().properties().getAccessKeys();
						// System.out.println(XMLParser.serializeObject(indexedObj.model().properties()));
					} catch (Exception e) {
						e.printStackTrace();
					}

				} else if (interf.equals(IndexedObject.class)) {
					try {
						IndexedObject indexedObj = (IndexedObject) object;
						index = indexedObj.getAccessKeys();
					} catch (Exception e) {
						e.printStackTrace();
					}

				}

			}
		} else if (FieldFinder.containsSuper(object, DataStructure.class))

		{
			DataStructure obj = (DataStructure) (object);
			index = obj.properties().getAccessKeys();
		}
		return index;
	}
}
