
package edu.ucsc.cross.jheq.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SpringLayout;

import edu.ucsc.cross.jheq.application.CoreFeatures;
import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.ui.HEQDisplay.ArgumentSelector;
import edu.ucsc.cross.jheq.ui.HEQDisplay.MenuChooser;
import edu.ucsc.cross.jheq.util.CollectionFormat;

public class ToolboxTaskBar {

	JPanel panel;

	/**
	 * @return the panel
	 */
	public JPanel getPanel() {

		return panel;
	}

	JHEQToolbox hse;

	ArgumentSelector args;

	TextField t;

	TextField j;

	public ToolboxTaskBar(JHEQToolbox hse, ArgumentSelector args) {

		this.hse = hse;
		this.args = args;
		ArrayList<String> envTasks = new ArrayList<String>();
		envTasks.addAll(CollectionFormat.getArrayList(CoreFeatures.CoreFeature.ENV_CLEAR.index,
				CoreFeatures.CoreFeature.ENV_FROM_FILE.index, CoreFeatures.CoreFeature.LOAD_ENV_SETTINGS.index,
				CoreFeatures.CoreFeature.ENV_SAVE.index, CoreFeatures.CoreFeature.EXPORT_TO_CSV.index));
		JPanel envPanel = generatePanel("Environment Menu", envTasks);
		ArrayList<String> taskMenu = new ArrayList<String>();
		taskMenu.addAll(CollectionFormat.getArrayList(CoreFeatures.CoreFeature.EXECUTE_FEATURE.index,
				CoreFeatures.CoreFeature.RELOAD_FEATURES.index));// , CoreFeatures.CoreFeature.ADD_FEATURE.index));
		JPanel taskMenuPanel = generatePanel("Task Menu", taskMenu);
		// taskMenuPanel.setPreferredSize(new Dimension(75, 25));
		JPanel simPanel = generateSimPanel("Simulation Menu");
		panel = generateBar("Toolbox Tasks", simPanel, envPanel, taskMenuPanel);

		// panel.setPreferredSize(new Dimension((int)
		// panel.getPreferredSize().getWidth(), 80));
	}

	public JPanel generatePanel(String title, ArrayList<String> features) {

		JPanel contentPanelx = new JPanel(new GridLayout(1, features.size() + 1));
		TitledPanel pane = new TitledPanel(title, Color.BLACK);
		pane.setLayout(new BorderLayout());
		// contentPanelx.setLayout(new GridLayout(1, features.size() + 1));

		for (String feature : features) {

			MenuChooser buttonAc = new MenuChooser(feature, args.getArgs(), args.enable, hse);
			Button button = new Button(feature);
			button.addActionListener(buttonAc);
			// button.setMaximumSize(new Dimension(105, 25));
			// button.setPreferredSize(new Dimension(105, 25));

			// JPanel bp = new JPanel(new BorderLayout());
			// bp.add(BorderLayout.CENTER, button);
			// bp.add(BorderLayout.PAGE_END, args);
			contentPanelx.add(button);

		}

		pane.add(BorderLayout.CENTER, contentPanelx);
		pane.repaint();
		return pane;
	}

	public JPanel generateSimPanel(String title) {

		ArrayList<String> features = new ArrayList<String>();
		features.addAll(CollectionFormat.getArrayList(CoreFeatures.CoreFeature.RUN_EMV.index,
				CoreFeatures.CoreFeature.INTERRUPT_SIM.index));
		JPanel contentPanelx = new JPanel(new GridLayout(1, features.size() + 2));
		TitledPanel pane = new TitledPanel(title, Color.BLACK);
		pane.setLayout(new BorderLayout());

		for (String feature : features) {

			MenuChooser buttonAc = new MenuChooser(feature, args.getArgs(), args.enable, hse);
			Button button = new Button(feature);
			button.addActionListener(buttonAc);
			// button.setMaximumSize(new Dimension(55, 25));
			// button.setPreferredSize(new Dimension(105, 25));

			// JPanel bp = new JPanel(new BorderLayout());
			// bp.add(BorderLayout.CENTER, button);
			// bp.add(BorderLayout.PAGE_END, args);
			contentPanelx.add(button);

		}
		JPanel tpane = new JPanel(new BorderLayout());
		tpane.add(BorderLayout.LINE_START, new JLabel(" t "));
		t = new TextField(String.valueOf(hse.getEnvironment().getSettings().maximumTime));
		tpane.add(BorderLayout.CENTER, t);
		JPanel jpane = new JPanel(new BorderLayout());
		jpane.add(BorderLayout.LINE_START, new JLabel(" j "));
		j = new TextField(String.valueOf(hse.getEnvironment().getSettings().maximumJumps));
		jpane.add(BorderLayout.CENTER, j);
		prepareThresholdMenu();
		contentPanelx.add(tpane);
		contentPanelx.add(jpane);
		pane.add(BorderLayout.CENTER, contentPanelx);
		pane.repaint();
		return pane;
	}

	public void prepareThresholdMenu() {

		t.addKeyListener(new ThresholdInputEnter(this));
		j.addKeyListener(new ThresholdInputEnter(this));

	}

	public static class ThresholdInputEnter implements KeyListener {

		ToolboxTaskBar tb;

		public ThresholdInputEnter(ToolboxTaskBar tb) {

			this.tb = tb;
		}

		@Override
		public void keyTyped(KeyEvent e) {

			// TODO Auto-generated method stub

		}

		@Override
		public void keyPressed(KeyEvent e) {

			// TODO Auto-generated method stub

		}

		@Override
		public void keyReleased(KeyEvent e) {

			Console.debug("threshold change detected j=" + tb.j.getText() + " t=" + tb.t.getText());
			try {
				Integer jMax = Integer.parseInt(tb.j.getText());
				Double tMax = Double.parseDouble(tb.t.getText());
				tb.hse.getEnvironment().getSettings().maximumJumps = jMax;
				tb.hse.getEnvironment().getSettings().maximumTime = tMax;

			} catch (Exception badThreshold) {
			}

		}

		protected Runnable createTask() {

			return new Runnable() {

				@Override
				public void run() {

				}
			};

		}
	}

	public JPanel generateBar(String title, JPanel... sub_menus) {

		JPanel pane = new JPanel(new BorderLayout());
		JPanel contentPanelx = new JPanel(new SpringLayout());// (1, sub_menus.length + 1));
		// JCollapsiblePanel contentPanelx = new JCollapsiblePanel(title, Color.BLACK);
		GridBagLayout l = new GridBagLayout();
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.anchor = GridBagConstraints.LINE_START;//
		contentPanelx.setLayout(l);
		c.gridx = 0;
		// pane.getInsets().set(args.getPanel().getInsets().top,
		// args.getPanel().getInsets().left,
		// args.getPanel().getInsets().bottom, args.getPanel().getInsets().right);
		for (JPanel feature : sub_menus) {
			GridBagConstraints cp = new GridBagConstraints();
			cp.fill = GridBagConstraints.BOTH;
			cp.anchor = GridBagConstraints.LINE_START;//
			cp.weightx = .333;
			cp.gridx = c.gridx;
			contentPanelx.add(feature, cp);
			c.gridx = c.gridx + 1;
		}
		// contentPanelx.add(args.getPanel());
		// args.getPanel().setPreferredSize(new Dimension(255, (int)
		// sub_menus[0].getPreferredSize().getHeight()));
		// contentPanelx.add(args.getPanel());
		// pane.add(BorderLayout.LINE_START, contentPanelx);
		/// pane.add(BorderLayout.WEST, contentPanelx);
		pane.add(BorderLayout.CENTER, contentPanelx);
		pane.repaint();
		return pane;
	}
}
