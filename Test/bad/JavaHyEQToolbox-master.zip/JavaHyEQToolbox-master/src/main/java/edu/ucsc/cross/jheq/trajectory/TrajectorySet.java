/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ TrajectorySet.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.trajectory;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import com.be3short.obj.access.FieldFinder;

import edu.ucsc.cross.jheq.environment.EnvironmentContents;
import edu.ucsc.cross.jheq.file.CSVFileTools;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.object.DataStructure;
import edu.ucsc.cross.jheq.worker.DataCollector;

/**
 * A set of hybrid trajectories corresponding to hybrid objects and systems.
 * 
 * Intended Operator: User
 */
public class TrajectorySet {

	/**
	 * Mapping of all object trajectories contained in this set indexed by object
	 */
	private HashMap<DataStructure, HybridTrajectory<?>> hybridTrajectoryMap;

	/**
	 * Set of hybrid systems with objects related to the trajectories stored in this
	 * set
	 */
	private EnvironmentContents systems;

	/**
	 * Time domain of the trajectory
	 */
	private ArrayList<HybridTime> timeDomain;

	/**
	 * Construct a new hybrid trajectory set for the specified hybrid system set.
	 */
	public TrajectorySet() {

		this.systems = new EnvironmentContents();
		timeDomain = new ArrayList<HybridTime>();
		hybridTrajectoryMap = (new HashMap<DataStructure, HybridTrajectory<?>>());
	}

	/**
	 * Construct a new hybrid trajectory set for the specified hybrid system set.
	 * 
	 * @param systems
	 *            set to be loaded into this new instance
	 */
	public TrajectorySet(EnvironmentContents systems) {

		this.systems = (systems);
		timeDomain = new ArrayList<HybridTime>();
		hybridTrajectoryMap = (new HashMap<DataStructure, HybridTrajectory<?>>());
	}

	/**
	 * Add hybrid times to the global hybrid time domain
	 * 
	 * @param dom
	 *            the list of times to be added
	 */
	private void addToTimeDomain(ArrayList<HybridTime> dom) {

		for (HybridTime t : dom) {
			if (!this.timeDomain.contains(t)) {
				boolean add = true;

				if (add) {
					timeDomain.add(t);
				}
			}
		}
	}

	/**
	 * Add trajectories to the set. Note: can cause problems with the hybrid chart
	 * renderer if time domain does not match
	 * 
	 * @param trajectories
	 *            hybrid trajectories to be added
	 */
	public void addTrajectory(HybridTrajectory<?>... trajectories) {

		for (HybridTrajectory<?> trajectory : trajectories) {
			hybridTrajectoryMap.put(trajectory.getDataPoint(null), trajectory);
			addToTimeDomain(trajectory.getTimeDomain());
		}
	}

	/**
	 * Export the trajectory to a CSV file format
	 * 
	 * @param path
	 *            file path where attempt CSV file creation will occur
	 * 
	 * @return true if the file was created successfully, false otherwise
	 */
	public boolean exportToCSVFile(File path) {

		boolean success = true;
		try {
			CSVFileTools csv = new CSVFileTools(this);
			csv.createCSVOutput(path);
		} catch (Exception badFile) {
			success = false;
			Console.error("unable to export " + this + " to csv file " + path);
		}
		return success;
	}

	/**
	 * Get the last time in the domain of the trajectory
	 * 
	 * @return last hybrid time in trajectory domain
	 * 
	 */
	public HybridTime getFinalTime() {

		HybridTime finalTime = null;
		if (timeDomain.size() > 0) {
			Integer finalIndex = timeDomain.size() - 1;
			finalTime = timeDomain.get(finalIndex);
		}
		return finalTime;
	}

	/**
	 * Get the map of hybrid trajectories for every object set
	 * 
	 * @return map containing all hybrid trajectories contained in this set, indexed
	 *         by object
	 */
	public HashMap<DataStructure, HybridTrajectory<?>> getHybridTrajectoryMap() {

		return hybridTrajectoryMap;
	}

	/**
	 * Get the map of all hybrid trajectories in the set of a specified class type,
	 * indexed by object
	 * 
	 * @param <T>
	 *            This describes my type parameter
	 * @param object_type
	 *            object class that will be used to filter out all other classes and
	 *            create a new subset with trajectories specifically for the
	 *            specified class
	 * @return subSet map of the object trajectories for the specified type indexed
	 *         by type object
	 */
	@SuppressWarnings("unchecked")
	public <T extends DataStructure> HashMap<T, HybridTrajectory<T>> getHybridTrajectoryMapByObject(
			Class<T> object_type) {

		HashMap<T, HybridTrajectory<T>> subSet = new HashMap<T, HybridTrajectory<T>>();
		for (DataStructure objectSet : hybridTrajectoryMap.keySet()) {
			if (FieldFinder.containsSuper(objectSet, object_type)) {
				subSet.put((T) objectSet, (HybridTrajectory<T>) hybridTrajectoryMap.get(objectSet));

			}
		}
		return subSet;
	}

	/**
	 * Get a trajectory set that is a subset of all hybrid trajectories for the
	 * specified class type
	 * 
	 * @param <T>
	 *            This describes my type parameter
	 * 
	 * @param object_type
	 *            object class that will be used to filter out all other classes and
	 *            create a new subset with trajectories specifically for the
	 *            specified class
	 * @return TrajectorySet trajectory set containing only the trajectories
	 *         corresponding to the specified object type
	 */
	public <T extends DataStructure> TrajectorySet getHybridTrajectorySetByObject(Class<T> object_type) {

		EnvironmentContents systemz = new EnvironmentContents();
		TrajectorySet subSet = new TrajectorySet(systemz);
		for (DataStructure objectSet : hybridTrajectoryMap.keySet()) {
			if (FieldFinder.containsSuper(objectSet, object_type)) {
				subSet.addTrajectory(hybridTrajectoryMap.get(objectSet));
				EnvironmentContents subSys = getSystemsAssociatedToObject(objectSet);
				systemz.add(subSys);
			}
		}
		return subSet;
	}

	/**
	 * Get the first time in the domain of the trajectory
	 *
	 * @return first hybrid time in trajectory domain
	 */
	public HybridTime getInitialTime() {

		HybridTime initialTime = null;
		if (timeDomain.size() > 0) {

			initialTime = timeDomain.get(0);
		}
		return initialTime;
	}

	/**
	 * Get the unique names of all object sets with trajectories
	 * 
	 * @return list of all unique object names with trajectories in this sets
	 */
	public ArrayList<String> getObjectSetNames() {

		ArrayList<String> nameOrder = new ArrayList<String>();
		{
			for (DataStructure dataSeries : DataCollector.getObjectSetListSortedByName(this)) {
				if (!nameOrder.contains(dataSeries.properties().getIndexedName())) {
					nameOrder.add(dataSeries.properties().getIndexedName());
				}
			}
			Collections.sort(nameOrder);
		}
		return nameOrder;
	}

	/**
	 * Get the set of hybrid systems that are related to the object set trajectories
	 * 
	 * @return set of hybrid systems with objects related to the trajectories stored
	 *         in this set
	 */
	public EnvironmentContents getSystems() {

		return systems;
	}

	/**
	 * Gets a system set containing all systems associated with the specified hybrid
	 * object
	 * 
	 * @param object_set
	 *            hybrid object to be checked for association with multiple systems
	 * @return object_set set of systems associated with object_set
	 */
	private EnvironmentContents getSystemsAssociatedToObject(DataStructure object_set) {

		EnvironmentContents systemz = new EnvironmentContents();
		for (HybridSystem sys : systems.getSystems()) {
			sys.model().containsObject(object_set);
		}
		return systemz;
	}

	/**
	 * Get the complete time domain of the trajectory
	 *
	 * @return list of all times in the hybrid domain
	 */
	public ArrayList<HybridTime> getTimeDomain() {

		return timeDomain;
	}

	/**
	 * Get a set of hybrid trajectories for all of the object sets specified
	 * 
	 * @param object_set
	 *            one or more object_set attempting to fetch trajectories
	 * 
	 * 
	 * @return trajectory set containing trajectories of all objects whose
	 *         trajectories were saved
	 */
	public TrajectorySet getTrajectories(DataStructure... object_set) {

		TrajectorySet trajectories = new TrajectorySet(systems);
		for (DataStructure trajectoryObject : object_set) {
			if (hybridTrajectoryMap.containsKey(trajectoryObject)) {
				trajectories.addTrajectory(hybridTrajectoryMap.get(trajectoryObject));
			}
		}
		return null;
	}

	/**
	 * Get a set of hybrid trajectories for all of the object sets related to the
	 * specified hybrid systems to the given inputs.
	 * 
	 * @param system
	 *            one or more hybrid systems attempting to fetch trajectories for
	 *            related objects
	 * 
	 * @return trajectory set containing trajectories of all objects related to the
	 *         systems, for objects whose trajectories were saved obviously
	 */
	public TrajectorySet getTrajectories(HybridSystem... system) {

		EnvironmentContents systemz = new EnvironmentContents();
		TrajectorySet trajectories = new TrajectorySet(systemz);
		trajectories.timeDomain = timeDomain;
		for (HybridSystem sys : system) {
			if (hybridTrajectoryMap.containsKey(sys.state()))

			{
				// systemz.add(sys);
				trajectories.addTrajectory(hybridTrajectoryMap.get(sys.state()));
			}
		}
		return trajectories;
	}

	/**
	 * Get the trajectory of the object set corresponding to the state of the
	 * specified hybrid system
	 * 
	 * @param <X>
	 *            The hybrid object defining the state
	 * 
	 * @param system
	 *            with state that will attempt to fetch trajectory
	 * 
	 * @return ObjectTrajectory of the hybrid object state of the hybrid system, if
	 *         the trajectory exists in the set
	 */
	@SuppressWarnings("unchecked")
	public <X extends DataStructure> HybridTrajectory<X> getTrajectory(HybridSystem system) {

		if (hybridTrajectoryMap.containsKey(system.state())) {
			return (HybridTrajectory<X>) hybridTrajectoryMap.get(system.state());
		}
		return null;
	}

	/**
	 * Get the trajectory of the specified object set
	 * 
	 * @param <X>
	 *            The hybrid object defining the state
	 * @param state
	 *            hybrid object that will attempt to fetch trajectory
	 * 
	 * @return ObjectTrajectory of the hybrid object state if the trajectory exists
	 *         in the set
	 */
	@SuppressWarnings("unchecked")
	public <X extends DataStructure> HybridTrajectory<X> getTrajectory(X state) {

		if (hybridTrajectoryMap.containsKey(state)) {
			return (HybridTrajectory<X>) hybridTrajectoryMap.get(state);
		}
		return null;
	}
}
