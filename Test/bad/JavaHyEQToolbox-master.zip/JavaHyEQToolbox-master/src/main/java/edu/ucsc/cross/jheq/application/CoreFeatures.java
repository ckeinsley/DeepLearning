
package edu.ucsc.cross.jheq.application;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

import edu.ucsc.cross.jheq.environment.EnvironmentSettings;
import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.file.DataFormat;
import edu.ucsc.cross.jheq.file.FileBrowser;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.function.JHEQFeature;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.variable.Shared;

public class CoreFeatures {

	public static enum CoreFeature {
		ENV_FROM_FILE("load", true, "load an environment from a file"), ENV_CLEAR("clear", true,
				"clear the contents and data currently stored in the environment"), ENV_SAVE("save", true,
						"save the environment to a file"),
		// CONFIGURE_NETWORK(
		// "n",
		// "network"),
		GUI_TOGGLE("gui", false, "enable or disable the gui upon load"), QUIT("quit", false,
				"quit the application"), ADD_FEATURE("add", false,
						"add feature by packaged name (requires -p name argument)"), INTERRUPT_SIM("stop", true,
								"interrupt the environment if it is running and retain the data"), RELOAD_FEATURES(
										"rescan", true,
										"reload the application tasks from the root directories"), TEMPLATE_BUILD(
												"temp", false,
												"construct all template files at a specified location"), RUN_EMV("run",
														true,
														"run the environment (optional args = -t maxTime -j maxJumps)"), EXECUTE_FEATURE(
																"exe", true,
																"execute a feature from a specified file path (requires -f file argument)"), EXPORT_TO_CSV(
																		"csv", true,
																		"export the trajectory data currently stored in the environment to csv file"), PRINT_MENU(
																				"menu", false,
																				"print the menu out to the console"), LOAD_ENV_SETTINGS(
																						"setting", true,
																						"load environment settings  ");
		;
		// BUILD_CONFIG(
		// "b",
		// "build config");

		public final String index;

		public final String title;

		public boolean guiVisible;

		CoreFeature(String index, boolean gui, String title) {

			this.index = index;
			this.title = title;
			this.guiVisible = gui;
		}

		public static CoreFeature getFromInput(String input) {

			CoreFeature cf = null;
			for (CoreFeature f : CoreFeature.values()) {
				if (input.length() >= f.index.length()) {
					if (input.substring(0, f.index.length()).contains(f.index)) {

						cf = f;
						return cf;
					}
				}
			}
			return cf;
		}

		public static ArrayList<String> getCoreLabels(boolean gui) {

			// ArrayList<String> list = new ArrayList<String>();
			// for (CoreFeature f : CoreFeature.values()) {
			// list.add("[" + f.index + " : " + f.title + "]");
			// }
			// Collections.sort(list);
			// String title = "Environment ->";
			// for (String l : list) {
			// title += " " + l;
			// }
			ArrayList<String> list = new ArrayList<String>();
			for (CoreFeature f : CoreFeature.values()) {
				if (gui) {
					if (f.guiVisible) {
						list.add(f.index);
					}
				} else {
					list.add(f.index);
				}
			}
			Collections.sort(list);
			return list;
		}

		public static String listCore() {

			// ArrayList<String> list = new ArrayList<String>();
			// for (CoreFeature f : CoreFeature.values()) {
			// list.add("[" + f.index + " : " + f.title + "]");
			// }
			// Collections.sort(list);
			// String title = "Environment ->";
			// for (String l : list) {
			// title += " " + l;
			// }
			ArrayList<String> list = new ArrayList<String>();
			for (CoreFeature f : CoreFeature.values()) {
				list.add("[ " + f.index + " ] : " + f.title + "\n");
			}
			Collections.sort(list);

			String title = "";
			for (String l : list) {
				title += "---------------------------------------------------------------------------------------------  \n";
				title += " " + l;
			}
			title += "--------------------------------------------------------------------------------------------- \n ";

			return title;
		}

		public static boolean isCoreIndex(String index_str) {

			for (CoreFeature f : CoreFeature.values()) {
				if (index_str.length() >= f.index.length()) {

					if (index_str.substring(0, f.index.length()).contains(f.index)
							&& index_str.length() == f.index.length()) {
						return true;
					}
				}
			}
			return false;
		}

		public String getCallHandle() {

			// TODO Auto-generated method stub
			return index;
		}

	}

	public void execute(JHEQEnvironment env, String input, JHEQToolbox database) {

		CoreFeature feat = CoreFeature.getFromInput(input);
		System.out.println(feat);
		try {
			CoreArgs args = new CoreArgs(input);
			switch (feat) {
			case ENV_FROM_FILE:
				env.stop();
				JHEQEnvironment e = JHEQEnvironment.loadFromFile(FileBrowser.load());
				env.loadEnvironment(e);
				break;
			case ENV_CLEAR:
				env.stop();
				env.loadEnvironment(new JHEQEnvironment());
				break;
			case ENV_SAVE:
				env.saveToFile(false);
				break;

			case QUIT:
				env.stop();
				System.exit(0);
				break;
			case INTERRUPT_SIM:
				env.stop();
				break;
			case GUI_TOGGLE:
				System.out.println("gui " + database.getDatabase().config.isGuiEnabled());
				boolean enabled = database.getDatabase().config.isGuiEnabled();

				database.database.config.setGuiEnabled(!enabled);
				break;
			case RUN_EMV:
				if (args.timeArg.value != null && args.jumpArg.value != null) {
					env.run(args.timeArg.value, args.jumpArg.value);
				} else {
					env.run();

				}
				break;
			default:
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public CoreFeature performInput(Shared<JHEQEnvironment> env, ParsedInput input, JHEQToolbox database) {

		CoreFeature feat = CoreFeature.getFromInput(input.command);
		try {
			CoreArgs args = new CoreArgs(input.arguments);
			int iterations = 1;
			if (args.multiArg.getValue() != null) {
				iterations = args.multiArg.getValue();
			}
			for (int i = 0; i < iterations; i++) {
				performInput(env, input, feat, database);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return feat;
	}

	private CoreFeature performInput(Shared<JHEQEnvironment> env, ParsedInput input, CoreFeature feat,
			JHEQToolbox database) {

		Console.debug("executing " + feat.title + " with arguments " + input.toString());

		File file = null;
		try {
			CoreArgs args = new CoreArgs(input.arguments);
			if (args.fileArg.getValue() != null) {
				file = args.fileArg.getValue();
			}
			switch (feat) {
			case ENV_FROM_FILE:
				database.environment.getValue().stop();
				if (file == null) {
					file = FileBrowser.load("Select a file to load the environment contents");
				}
				JHEQEnvironment e = JHEQEnvironment.loadFromFile(file);
				if (e != null) {
					env.setValue(e);
				}
				break;

			case ENV_CLEAR:
				env.getValue().stop();
				env.setValue(new JHEQEnvironment());
				break;
			case ENV_SAVE:
				boolean compress = false;
				if (args.compressArg.getValue() != null) {
					compress = args.compressArg.getValue();
				}
				env.getValue().saveToFile(compress);
				break;
			case GUI_TOGGLE:
				boolean enabled = database.getDatabase().config.isGuiEnabled();
				System.out.println("gui " + database.getDatabase().config.isGuiEnabled());
				database.database.config.setGuiEnabled(!enabled);
				database.run();
				break;
			case QUIT:
				env.getValue().stop();
				System.exit(0);
				break;
			case INTERRUPT_SIM:
				env.getValue().stop();
				break;
			case EXECUTE_FEATURE:
				if (file == null) {
					file = (FileBrowser.load());
				}
				JHEQFeature task = JHEQLibrary.loadFeature(file);
				if (task != null) {
					task.perform(database, input.arguments);
				}
				break;
			case ADD_FEATURE:
				if (file == null) {

				}
				JHEQLibrary.addNewFeature(args.packageArg.getValue(), args.fileArg.getValue());
				database.initialize();
				break;
			case RELOAD_FEATURES:
				database.run();
				break;
			case RUN_EMV:
				if (args.timeArg.value != null && args.jumpArg.value != null) {
					env.getValue().run(args.timeArg.value, args.jumpArg.value);
				} else {
					env.getValue().run();

				}
				break;
			case LOAD_ENV_SETTINGS:
				if (file == null) {
					file = FileBrowser.load();
				}
				env.getValue().loadSettings(XMLFileTools.loadContent(EnvironmentSettings.class, file));
				break;
			case EXPORT_TO_CSV:
				if (file == null) {
					file = FileBrowser.save();
				}
				File checked = DataFormat.CSV.getUtilities().appendExtension(file);
				env.getValue().getTrajectories().exportToCSVFile(checked);
				break;
			case PRINT_MENU:
				database.printMenu(true);
				break;
			case TEMPLATE_BUILD:
				if (file != null) {
					JHEQTemplates.createTemplates(file);
				} else {
					JHEQTemplates.createTemplates();
				}
				break;
			default:
				break;
			}

		} catch (Exception err) {
			Console.error("failed to execute core operation " + input.toString(), err);
		}
		return feat;
	}

	public String getCallHandle() {

		// TODO Auto-generated method stub
		return "core";
	}

}
