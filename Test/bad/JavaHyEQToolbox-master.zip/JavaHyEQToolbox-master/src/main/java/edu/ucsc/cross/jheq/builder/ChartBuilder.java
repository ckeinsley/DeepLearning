
package edu.ucsc.cross.jheq.builder;

import java.io.File;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.chart.ChartType;
import edu.ucsc.cross.jheq.chart.ChartUtils;
import edu.ucsc.cross.jheq.chart.RendererConfiguration;
import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.figure.Figure;
import edu.ucsc.cross.jheq.file.FileBrowser;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.function.JHEQOperation;
import edu.ucsc.cross.jheq.trajectory.TrajectorySet;
import edu.ucsc.cross.jheq.worker.DataCollector;

public class ChartBuilder extends JHEQOperation// implements HEQDisplay

{

	public String xAxisVariable;

	public String yAxisVariable;

	public String chartTitle;

	public String xAxisTitle;

	public String yAxisTitle;

	public Boolean displayLegend;

	public ChartType type;

	public String customChartPath;

	public ChartBuilder() {

		xAxisVariable = "Time";

		yAxisVariable = "value";

		chartTitle = "Sub Title";

		xAxisTitle = "xAxis Label";

		yAxisTitle = "yAxis Label";

		displayLegend = true;

		customChartPath = "null";

		type = ChartType.LINE;

		super.setCallHandle(null);
	}

	public static void main(String args[]) {

		XMLFileTools.save(new ChartBuilder(), FileBrowser.save());
	}

	public ChartPanel generate(TrajectorySet traj) {

		return ChartUtils.createPanel(traj, xAxisVariable, yAxisVariable, xAxisTitle, yAxisTitle, chartTitle,
				displayLegend);
	}

	public JFreeChart getCustomChart() {

		JFreeChart chart = null;
		if (customChartPath != null) {
			if (!customChartPath.equals("null")) {
				try {
					chart = XMLFileTools.loadContent(JFreeChart.class, new File(this.customChartPath));
				} catch (Exception badFile) {

				}
			}
		}
		return chart;
	}

	public void getComponent(JHEQEnvironment env, String input, Figure figure, int row, int col,
			RendererConfiguration renderer) {

		DataCollector.getObjectSetListSortedByName(env.getTrajectories());
		ChartPanel panel = ChartUtils.createPanel(env.getTrajectories(), xAxisVariable, yAxisVariable, type, renderer,
				getCustomChart());
		ChartUtils.configureLabels(panel, xAxisTitle, yAxisTitle, chartTitle, displayLegend);
		// ChartPanel fig = ChartUtils.createPanel(env.getTrajectories(), this,
		// renderer);

		figure.add(row, col, panel);
		return;
	}

	@Override
	public void perform(JHEQToolbox application, String input) {

		generate(application.getEnvironment().getTrajectories());

	}

}
