/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * DynamicVariable.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.variable;

import java.lang.reflect.Field;
import java.util.ArrayList;

import com.be3short.obj.access.FieldFinder;

/**
 * A variable that will link with a field of another object and maintain access
 * to the most current value of that field.
 * 
 * Intended Operator: User
 * 
 * @param <X>
 *            the value type of this variable
 * 
 */
public class DynamicVariable<X> implements Variable<X> {

	/**
	 * Field corresponding to the specified value of this variable.
	 */
	private Field field;

	/**
	 * Parent object where the value will be modified
	 */
	private Object source;

	/**
	 * The class of the value that this variable accesses.
	 */
	private Class<X> valueClass;

	/**
	 * Constructor that attempts to find the field to be linked with this variable.
	 * This is not accessible directly since it may not always work, instead the
	 * variable is initialized by the static method initializeVariable to handle
	 * cases when the field isn't located
	 * 
	 * @param <D>
	 *            class type of the parent data source
	 * @param data_source
	 *            parent of the field to be located
	 * 
	 * @param field_name
	 *            name of the field to search for
	 * 
	 * @param state_class
	 *            class of the field value
	 */
	protected <D> DynamicVariable(D data_source, String field_name, Class<X> state_class) {

		source = data_source;
		valueClass = state_class;
		this.field = null;
		try {
			ArrayList<Field> fields = FieldFinder.getObjectFields(data_source, true);
			for (Field field : fields) {
				if (field.getName().equals(field_name)) {
					this.field = field;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Get the current value of the variable if it is available, otherwise return
	 * null.
	 * 
	 * @return value the retrieved value of this variable
	 */
	@Override
	public X getValue() {

		X value = null;
		try {
			Object obj = field.get(source);
			if (field.getType().isInstance(obj)) {
				value = valueClass.cast(obj);
			}
		} catch (Exception badState) {
			System.err.println("could not get state " + field.getName() + " of " + source);
		}
		return value;
	}

	/**
	 * Get the class of the value that this variable accesses.
	 * 
	 * @return valueClass class of the value
	 */
	public Class<X> getValueClass() {

		return valueClass;
	}

	/**
	 * Attempts to construct a dynamic variable and returns null if the variable was
	 * not able to be linked to the field.
	 * 
	 * @param <S>
	 *            class type of the parent data source
	 * @param <T>
	 *            class type of the value that is linked to this variable
	 * @param data_source
	 *            parent of the field to be located
	 * @param field_name
	 *            name of the field to search for
	 * @param state_class
	 *            class of the field value
	 * @return dynamicVariable the dynamic variable if it was able to be created,
	 *         otherwise null
	 */
	public static <S, T> DynamicVariable<T> initializeState(S data_source, String field_name, Class<T> state_class) {

		DynamicVariable<T> dynamicVariable = new DynamicVariable<T>(data_source, field_name, state_class);
		if (dynamicVariable.field == null) {
			dynamicVariable = null;
		}
		return dynamicVariable;
	}

}
