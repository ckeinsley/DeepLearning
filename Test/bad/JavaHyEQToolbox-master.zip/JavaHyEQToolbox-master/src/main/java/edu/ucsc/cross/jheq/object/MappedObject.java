
package edu.ucsc.cross.jheq.object;

import edu.ucsc.cross.jheq.model.HybridSystem;

/**
 * This interface is used to define a function that determines the output y of a
 * given hybrid system
 * 
 * @param <X>
 *            class of the hybrid system state
 * @param <U>class
 *            of the hybrid system input
 * @param <Y>class
 *            of the hybrid system output
 */
public interface MappedObject {

	/**
	 * Method to create the output of type Y for the given system
	 * 
	 * @param system
	 *            system to determine output for
	 * @return output
	 */
	public void evaluate(HybridSystem sys);

}
