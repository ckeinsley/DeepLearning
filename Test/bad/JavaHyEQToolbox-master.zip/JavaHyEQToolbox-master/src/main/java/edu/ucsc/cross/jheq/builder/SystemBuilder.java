
package edu.ucsc.cross.jheq.builder;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.function.JHEQOperation;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.model.FlowMap;
import edu.ucsc.cross.jheq.model.FlowSet;
import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.model.HybridSystemModel;
import edu.ucsc.cross.jheq.model.JumpMap;
import edu.ucsc.cross.jheq.model.JumpSet;
import edu.ucsc.cross.jheq.object.DataStructure;

public class SystemBuilder<Z extends DataStructure> extends JHEQOperation {

	public ObjectBuilder<Z> stateGenerator;

	public ArrayList<ObjectBuilder<?>> variableGenerators;

	private ArrayList<String> globalVariables;

	public ArrayList<String> getGlobalVariables() {

		return globalVariables;
	}

	/**
	 * Externally defined flow map
	 */
	private FlowMap<Z> flowMap;

	/**
	 * Externally defined jump map
	 */
	private JumpMap<Z> jumpMap;

	/**
	 * Externally defined flow set
	 */
	private FlowSet<Z> flowSet;

	/**
	 * Externally defined jump set
	 */
	private JumpSet<Z> jumpSet;

	public Object[] accessKeys;

	public String importFilePath;

	public SystemBuilder() {

		super();
	}

	public SystemBuilder(String file_path) {

		super();

		importFilePath = file_path;
	}

	public SystemBuilder(HybridSystemModel<Z> data, String[] shared_params) {

		super();

		stateGenerator = new ObjectBuilder<Z>(data.getState());
		flowMap = data.getFlowMap();
		jumpMap = data.getJumpMap();
		flowSet = data.getFlowSet();
		jumpSet = data.getJumpSet();
		variableGenerators = new ArrayList<ObjectBuilder<?>>();
		for (Object param : data.variables().getVariables()) {
			if (param != null) {
				variableGenerators.add(new ObjectBuilder<Object>(param));
			} else {
				Console.error("parameter missing for hybrid system " + data);
			}
		}

		globalVariables = new ArrayList<String>(Arrays.asList(shared_params));
		accessKeys = data.properties().getAccessKeys();
	}

	@SuppressWarnings("unchecked")
	public HybridSystem generateSystem(JHEQEnvironment environment, String text) {

		SystemBuilder<Z> gen = this;
		if (importFilePath != null) {
			gen = XMLFileTools.loadContent(SystemBuilder.class, new File(importFilePath));

		}
		HybridSystem hs = HybridSystem.create(gen.stateGenerator.generate(), gen.flowMap, gen.jumpMap, gen.flowSet,
				gen.jumpSet, gen.generateVariables());
		hs.model().properties().setAccessKeys(gen.accessKeys);
		environment.getSystems().add(hs);

		return hs;
	}

	public Object[] generateVariables() {

		ArrayList<Object> params = new ArrayList<Object>();
		for (ObjectBuilder<?> param : variableGenerators) {
			params.add(param.generate());
		}
		for (Object param : globalVariables) {
			params.add(ContentBuilder.globalVariables.get(param));
		}
		return params.toArray(new Object[params.size()]);
	}

	@SuppressWarnings("rawtypes")
	public static SystemBuilder<?> instantiate() {

		return new SystemBuilder();
	}

	@Override
	public void perform(JHEQToolbox application, String input) {

		generateSystem(application.getEnvironment(), input);

	}
}
