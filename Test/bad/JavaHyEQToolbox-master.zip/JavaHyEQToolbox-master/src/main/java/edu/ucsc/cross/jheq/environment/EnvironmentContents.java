/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ SystemSet.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.environment;

import java.util.ArrayList;

import edu.ucsc.cross.jheq.model.HybridSystem;
import edu.ucsc.cross.jheq.model.HybridSystemModel;
import edu.ucsc.cross.jheq.util.CollectionFormat;
import edu.ucsc.cross.jheq.worker.EngineSupervisor;

/**
 * A set of hybrid systems.
 * 
 * Intended Operator: User
 */
public class EnvironmentContents {

	/**
	 * List of all hybrid systems contained within this set.
	 */
	private ArrayList<HybridSystem> systemMap;

	/**
	 * Create new set of hybrid systems.
	 */
	public EnvironmentContents() {

		systemMap = new ArrayList<HybridSystem>();
	}

	/**
	 * Create new set of hybrid systems.
	 * 
	 * @param new_systems
	 *            array of systems to load
	 */
	public EnvironmentContents(HybridSystem... new_systems) {

		add(new_systems);
	}

	/**
	 * Add new hybrid systems to this set.
	 * 
	 * @param new_systems
	 *            list of systems to add
	 */
	public void add(HybridSystem... new_systems) {

		for (HybridSystem sys : new_systems) {
			if (!systemMap.contains(sys)) {
				systemMap.add(sys);

			}
		}
	}

	/**
	 * Remove systems
	 * 
	 * @param content
	 *            system set to add
	 */
	public void add(EnvironmentContents content) {

		add(CollectionFormat.getArray(content.getSystems()));

	}

	/**
	 * Get all of the hybrid systems in this set
	 * 
	 * @return list of hybrid systems
	 */
	public ArrayList<HybridSystem> getSystems() {

		return this.systemMap;
	}

	/**
	 * Remove a hybrid system from this set
	 * 
	 * @param remove_systems
	 *            array of systems to remove
	 */
	public void remove(HybridSystem... remove_systems) {

		for (HybridSystem sys : remove_systems) {
			if (systemMap.contains(sys)) {
				systemMap.remove(sys);
			}
		}

	}

	public boolean contains(Object obj) {

		for (HybridSystem system : getSystems()) {
			HybridSystemModel<?> model = system.model();
			if (model.containsObject(obj)) {
				return true;
			}
			if (obj.equals(model)) {
				return true;
			}
		}
		return false;
	}

	public JHEQEnvironment getEnvironment() {

		return EngineSupervisor.getEnv(this);
	}
}
