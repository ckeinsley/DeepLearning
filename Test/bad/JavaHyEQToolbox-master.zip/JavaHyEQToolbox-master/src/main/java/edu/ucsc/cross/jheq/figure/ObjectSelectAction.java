
package edu.ucsc.cross.jheq.figure;

import java.awt.event.ActionEvent;
import java.util.HashMap;

import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JToggleButton;

import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.variable.Shared;

/**
 * Action for format selection buttons
 * 
 * @author Brendan Short
 *
 */
class ObjectSelectAction<T> extends AbstractAction {

	/**
	 * Serial
	 */
	private static final long serialVersionUID = 2710763100435246769L;

	/**
	 * Button to graphic format map
	 */
	private HashMap<JToggleButton, T> buttonMap;

	/**
	 * Selected button
	 */
	private JToggleButton button;

	/**
	 * Dialog container
	 */
	private JDialog dialog;

	private Shared<T> selected;

	private boolean multiSelect;

	/**
	 * Construct format select action
	 * 
	 * @param dialog
	 *            dialog container
	 * @param format
	 *            format selection
	 * @param map
	 *            button to format map
	 * @param button
	 *            specified button
	 */
	public ObjectSelectAction(JDialog dialog, HashMap<JToggleButton, T> map, JToggleButton button, Shared<T> selected,
			boolean multi_select) {

		putValue(NAME, button.getText()); // bounds properties
		putValue(SHORT_DESCRIPTION, button.getText());
		this.buttonMap = map;
		this.button = button;
		this.dialog = dialog;
		this.selected = selected;
		this.multiSelect = multi_select;
	}

	/**
	 * Action to take when button is pressed
	 */
	@Override
	public void actionPerformed(ActionEvent e) {

		selected.setValue(buttonMap.get(button));
		Console.debug("selection : " + selected.getValue());
		clearNonSelected(button);
		if (dialog != null) {
			dialog.dispose();
		}
	}

	public void clearNonSelected(JToggleButton button) {

		for (JToggleButton but : buttonMap.keySet()) {
			if (!multiSelect) {
				if (!but.equals(button)) {
					but.setSelected(false);
				}
			}
		}
	}
}