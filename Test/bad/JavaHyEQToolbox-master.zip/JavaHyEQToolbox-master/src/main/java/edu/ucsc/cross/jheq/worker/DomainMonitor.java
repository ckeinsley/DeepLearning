/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ DomainMonitor.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.worker;

import org.apache.commons.math3.ode.events.EventHandler;

import edu.ucsc.cross.jheq.specification.JumpStatus;

/**
 * Continuously monitors the system to interrupt the system upon each jump detected. This allows the ODE to function
 * smoothly as the discontinuities are addressed discretely while the solver is paused
 * 
 * Intended Operator: System
 */
public class DomainMonitor implements EventHandler
{

	/**
	 * flag indicating that the environment is approaching a jump, meaning that a jump has been detected by the ode but
	 * the pre-jump value has not been finalized
	 */
	private boolean approachingJump;

	/**
	 * supervisor of the environment that this instance works for
	 */
	private EngineSupervisor manager;

	/**
	 * toggle value that switches sign if an event has occurred since the last check
	 */
	private Double toggleFlag;

	/**
	 * Constructor to link the environment
	 * 
	 * @param manager
	 *            Engine supervisor of this instance
	 */
	public DomainMonitor(EngineSupervisor manager)
	{

		this.manager = manager;
		toggleFlag = 1.0;
		approachingJump = false;
	}

	/**
	 * Response that occurs when event is detected
	 * 
	 * @param t
	 *            current simulation time
	 * @param y
	 *            vector of values received from the integrator
	 * @param increasing
	 *            flag indicating if the value that triggered the event is increasing or decreasing
	 * 
	 */
	@Override
	public EventHandler.Action eventOccurred(double t, double[] y, boolean increasing)
	{

		approachingJump = false;

		if (!manager.getInterruptDetector().isRunning() || manager.getInterruptDetector().thresholdReached())
		{

			return EventHandler.Action.STOP; // continue if jump limit
												// hasn't been reached
		} else
		{
			return EventHandler.Action.RESET_STATE; // otherwise terminate the
		}
	}

	/**
	 * Execute the tasks necessary to handle a jump or jumps
	 * 
	 * @param t
	 *            current simulation time
	 * 
	 * @param y
	 *            vector of values received from the integrator
	 */
	public void executeJumps(double t, double[] y)
	{
		manager.getDataManager().performDataActions(t, y, JumpStatus.JUMP_DETECTED);
		while (manager.getDynamicsEvaluator().isSystemInSet(true) && manager.getInterruptDetector().isRunning())
		{

			// perform data update operations
			// loop while any hybrid system is in the jump set
			// execute all jumps
			manager.getDynamicsEvaluator().evaluateDynamics(true);
			// perform data update operations
			manager.getDataManager().performDataActions(t, y, JumpStatus.JUMP_OCCURRED);
			// if no system is in jump set terminate

		}

	}

	/**
	 * Checks the thresholds to trigger an interrupt when a jump has occurred
	 * 
	 * @param t
	 *            current simulation time
	 * 
	 * @param y
	 *            vector of values received from the integrator
	 */
	@Override
	public double g(double t, double[] y)
	{
		manager.getDataManager().performDataActions(t, y, getCheckJumpStatus());
		return getFlag();
	}

	/**
	 * Get the current jump status
	 * 
	 * @return jump status
	 */
	public JumpStatus getCheckJumpStatus()
	{

		if (approachingJump)
		{
			return JumpStatus.APPROACHING_JUMP;
		} else
		{
			return JumpStatus.NO_JUMP;
		}
	}

	/**
	 * Get the jump approach toggle flag value
	 * 
	 * @return value of approach toggle flag
	 */
	public double getFlag()
	{

		//
		boolean jumpOccurring = manager.getDynamicsEvaluator().isSystemInSet(true);
		approachingJump = (approachingJump || jumpOccurring);

		if (jumpOccurring)
		{
			toggleFlag = -1 * toggleFlag;
		}

		return toggleFlag;
	}

	/**
	 * Initializes the event handler
	 * 
	 * @param t0
	 *            initial time
	 * @param y0
	 *            initial value vector
	 * @param t
	 *            current time
	 */
	@Override
	public void init(double t0, double[] y0, double t)
	{

		approachingJump = false;
	}

	/**
	 * Checks if a jump approach has been flagged
	 * 
	 * @return true if jump approach has been flagged
	 */
	public boolean isApproachingJump()
	{

		return approachingJump;
	}

	/**
	 * Handle a jump event detection by stopping the integrator and evaluating the discrete dynamics
	 * 
	 * @param t
	 *            current simulation time
	 * @param y
	 *            vector of values received from the integrator
	 */
	@Override
	public void resetState(double t, double[] y)
	{

		executeJumps(t, y);
		manager.dynamicsEvaluator.resetPriority();

	}
}
