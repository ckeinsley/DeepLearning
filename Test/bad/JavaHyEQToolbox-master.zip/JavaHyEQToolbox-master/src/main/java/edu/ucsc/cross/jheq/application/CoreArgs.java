
package edu.ucsc.cross.jheq.application;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Pattern;

public class CoreArgs {

	InputArgument<File> fileArg = new InputArgument<File>("-f", File.class);

	InputArgument<Integer> jumpArg = new InputArgument<Integer>("-j", Integer.class);

	InputArgument<Integer> multiArg = new InputArgument<Integer>("-m", Integer.class);

	InputArgument<Double> timeArg = new InputArgument<Double>("-t", Double.class);

	InputArgument<Boolean> compressArg = new InputArgument<Boolean>("-c", Boolean.class);

	InputArgument<String> packageArg = new InputArgument<String>("-p", String.class);

	ArrayList<InputArgument<?>> args;

	private String input;

	public CoreArgs(String input) {

		this.input = input;
		split(this.input);
		args = new ArrayList<InputArgument<?>>(
				Arrays.asList(fileArg, jumpArg, multiArg, timeArg, compressArg, packageArg));
	}

	@SuppressWarnings(
		{ "unchecked", "rawtypes" })
	public void getVal(String incoming_flag, String value) {

		for (InputArgument b : new InputArgument[]
			{ fileArg, multiArg, jumpArg, timeArg, compressArg, packageArg }) {
			if (b.getFlag().equals(incoming_flag)) {
				b.value = b.getValue(b.getValueClass(), value);
			}
		}
	}

	public void split(String in) {

		try {
			String[] s = in.split(Pattern.quote(" "));

			for (int i = 1; i < s.length; i = i + 2) {
				try {
					getVal(s[i], s[i + 1]);
				} catch (Exception badArgs) {

				}

			}

		} catch (

		Exception noArgs) {

		}
	}

	@Override
	public String toString() {

		String report = "input: " + input + "\ncommands:";
		for (InputArgument<?> arg : args) {
			report += arg.getFlag() + " " + arg.getValue();
		}
		return report;

	}
}