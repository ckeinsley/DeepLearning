/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ FileBrowser.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.file;

import java.io.File;

/**
 * A file browser window to load or save files.
 *
 * Intended Operator: User
 */
public class FileBrowser {

	/*
	 * Opex`xx`ns a file browser that allows the selection of a file to be loaded
	 * 
	 * @return true if file is found and accepted by the file chooser
	 */
	public static File load(String prompt) {

		return SwingFileBrowser.file(prompt, false);// SwingFileBrowser.openFileWindow(false);

	}

	/**
	 * Opens a file browser that allows the definition of a file where something
	 * will be saved to.
	 * 
	 * @return True if file creation is a success, null otherwise
	 */
	public static File save(String prompt) {

		return SwingFileBrowser.file(prompt, true);// SwingFileBrowser.openFileWindow(true);
	}

	/**
	 * Opex`xx`ns a file browser that allows the selection of a file to be loaded
	 * 
	 * @return true if file is found and accepted by the file chooser
	 */
	public static File load() {

		return SwingFileBrowser.file("Load File", false);// SwingFileBrowser.openFileWindow(false);

	}

	/**
	 * Opens a file browser that allows the definition of a file where something
	 * will be saved to.
	 * 
	 * @return True if file creation is a success, null otherwise
	 */
	public static File save() {

		return SwingFileBrowser.file("Save File", true);// SwingFileBrowser.openFileWindow(true);
	}

	public static String getRelativeFilePath(File file) {

		String absolutePath = file.getAbsolutePath();
		String workingDir = System.getProperty("user.dir");
		System.out.println(workingDir);
		String relPath = absolutePath.substring(workingDir.length() + 1);
		System.out.println(relPath);
		return relPath;

	}

	public static File directory(String title) {

		return SwingFileBrowser.directory(title, true);// SwingFileBrowser.openFileDialog(chooser);
	}
}
