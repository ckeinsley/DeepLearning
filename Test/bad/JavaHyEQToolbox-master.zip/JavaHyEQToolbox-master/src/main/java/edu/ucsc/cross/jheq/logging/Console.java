/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * Console.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.logging;

import edu.ucsc.cross.jheq.specification.MessageType;
import edu.ucsc.cross.jheq.worker.EngineSupervisor;

/**
 * A global console that prints outputs from the system. Any component can print
 * to the console and log.
 * 
 * Intended Operator: User
 */
public class Console {

	/**
	 * The global console settings
	 */
	private static ConsoleSettings settings = new ConsoleSettings();

	/**
	 * Creates a new console for the specified engine operator
	 * 
	 * @param manage
	 *            Engine operator in charge of this console
	 *
	 */
	public Console(EngineSupervisor manage) {

		ConsoleUtils.linkedEngine = manage;
		ConsoleUtils.nextProgressUpdatePrintTime = 0.0;
		ConsoleUtils.progressUpdatePrintInterval = settings.printStatusInterval;
	}

	/**
	 * Post a message to the debug section of the console
	 * 
	 * @param message
	 *            message to post
	 *
	 */
	public static void debug(String message) {

		ConsoleUtils.print(ConsoleSettings.debugLabel, message, MessageType.DEBUG);
	}

	/**
	 * Post a message to the debug section of the console with a throwable
	 * 
	 * @param message
	 *            message to post
	 * 
	 * @param throwable
	 *            details about the issue that occurred
	 *
	 */
	public static void debug(String message, Throwable throwable) {

		ConsoleUtils.print(ConsoleSettings.debugLabel, message, throwable, MessageType.DEBUG);
	}

	/**
	 * Post a message to the error section of the console
	 * 
	 * @param message
	 *            message to post
	 * 
	 *
	 */
	public static void error(String message) {

		ConsoleUtils.print(ConsoleSettings.errorLabel, message, MessageType.ERROR);
	}

	/**
	 * Post a message to the debug section of the console with a throwable
	 * 
	 * @param message
	 *            message to post
	 * 
	 * @param throwable
	 *            details about the error
	 *
	 */
	public static void error(String message, Throwable throwable) {

		ConsoleUtils.print(ConsoleSettings.errorLabel, message, throwable, MessageType.ERROR);
	}

	/**
	 * Gets the global console settings
	 * 
	 * @return settings the global set of console settings
	 */
	public static ConsoleSettings getSettings() {

		return settings;
	}

	/**
	 * Post a message to the info section of the console
	 * 
	 * @param message
	 *            message to post
	 * 
	 *
	 */
	public static void info(String message) {

		ConsoleUtils.print(ConsoleSettings.infoLabel, message, MessageType.INFO);
	}

	/**
	 * Post a message to the info section of the console
	 * 
	 * @param message
	 *            message to post
	 * 
	 * @param throwable
	 *            details about something that may have occurred
	 */
	public static void info(String message, Throwable throwable) {

		ConsoleUtils.print(ConsoleSettings.infoLabel, message, throwable, MessageType.INFO);
	}

	/**
	 * Sets the global console settings
	 * 
	 * @param settings
	 *            the global set of console settings
	 */
	public static void setSettings(ConsoleSettings settings) {

		Console.settings = settings;
	}

	/**
	 * Post a message to the warning section of the console
	 * 
	 * @param message
	 *            message to post
	 * 
	 *
	 */
	public static void warn(String message) {

		ConsoleUtils.print(ConsoleSettings.warnLabel, message, MessageType.WARN);
	}

	/**
	 * Post a message to the warning section of the console with a throwable
	 * 
	 * @param message
	 *            message to post
	 * 
	 * @param throwable
	 *            details about the warning
	 *
	 */
	public static void warn(String message, Throwable throwable) {

		ConsoleUtils.print(ConsoleSettings.warnLabel, message, throwable, MessageType.WARN);
	}

}
