
package edu.ucsc.cross.jheq.figure;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;
import java.lang.reflect.Field;
import java.util.HashMap;

import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class GraphicFileDialog {

	GraphicFormatSelector<GraphicFormat> formatChooser;

	public static void main(String[] args) {

		new GraphicFileDialog();
	}

	public GraphicFileDialog() {

		EventQueue.invokeLater(new Runnable() {

			@SuppressWarnings("rawtypes")
			@Override
			public void run() {

				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
						| UnsupportedLookAndFeelException ex) {
					ex.printStackTrace();
				}
				HashMap<String, GraphicFormat> formats = GraphicFormat.getFormatMap();

				formatChooser = new GraphicFormatSelector<GraphicFormat>(formats);
				JFileChooser fc = new JFileChooser();
				JPanel cb = formatChooser.getChoicePanel();
				// cb.setPreferredSize(new Dimension(500, 200));

				try {
					JComboBox filterComboBox = (JComboBox) getField("filterComboBox", fc.getUI());
					Container parent = filterComboBox.getParent();
					parent.add(cb);
				} catch (NoSuchFieldException | IllegalArgumentException | IllegalAccessException ex) {
					ex.printStackTrace();
				}

				JComboBox filterComboBox;
				try {
					filterComboBox = (JComboBox) getField("filterComboBox", fc.getUI());
					filterComboBox.getParent().remove(0);
					JPanel bot = new JPanel(new BorderLayout());
					bot.add(new JLabel("Select a graphic format:"), BorderLayout.CENTER);
					bot.add(cb, BorderLayout.SOUTH);

					filterComboBox.getParent().add(bot);
					System.out.println(filterComboBox.getParent().getComponents().length);
					filterComboBox.setVisible(false);

				} catch (NoSuchFieldException | IllegalArgumentException | IllegalAccessException e) {
					e.printStackTrace();
				}
				fc.showSaveDialog(null);
			}

		});
	}

	private Object getField(String name, Object parent)
			throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {

		Class<?> aClass = parent.getClass();
		Field field = aClass.getDeclaredField(name);
		field.setAccessible(true);
		return field.get(parent);
	}

}