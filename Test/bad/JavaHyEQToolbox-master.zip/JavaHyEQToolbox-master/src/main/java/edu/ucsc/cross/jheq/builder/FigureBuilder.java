
package edu.ucsc.cross.jheq.builder;

import java.io.File;

import com.be3short.obj.access.FieldFinder;

import edu.ucsc.cross.jheq.application.JHEQToolbox;
import edu.ucsc.cross.jheq.chart.ChartUtils;
import edu.ucsc.cross.jheq.chart.RendererConfiguration;
import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.figure.Figure;
import edu.ucsc.cross.jheq.figure.GraphicFormat;
import edu.ucsc.cross.jheq.file.FileBrowser;
import edu.ucsc.cross.jheq.file.XMLFileTools;
import edu.ucsc.cross.jheq.function.JHEQFeature;
import edu.ucsc.cross.jheq.function.JHEQOperation;
import edu.ucsc.cross.jheq.function.JHEQTemplate;
import edu.ucsc.cross.jheq.logging.Console;

public class FigureBuilder extends JHEQOperation implements JHEQTemplate {// , HEQDisplay {

	public boolean display;

	public Integer width;

	public Integer height;

	public String mainTitle;

	public JHEQFeature[][] content;

	public GraphicFormat exportFileFormat;

	public RendererConfiguration renderer;

	public String exportFilePath;

	public String customFigurePath;

	public String rendererFilePath;

	public static FigureBuilder test() {

		FigureBuilder config = new FigureBuilder("TEST", 250, 250, new JHEQFeature[][]
			{
					{ new FigureBuilder() } });

		return config;
	}

	public FigureBuilder() {

		this("Title", 500, 500, new JHEQFeature[][]
			{
					{ new ChartBuilder() },
					{ new FigureBuilder(new JHEQFeature[][]
					{
							{ new ChartBuilder(), new ChartBuilder() } }) } },
				true);
		renderer = null;

	}

	public FigureBuilder(JHEQFeature[][] content) {

		this(null, 500, 500, content);
	}

	public FigureBuilder(String title, int width, int height, JHEQFeature[][] content) {

		this(title, 500, 500, content, false);
	}

	public FigureBuilder(String title, int width, int height, JHEQFeature[][] content, boolean renderer_config) {

		super();
		this.mainTitle = title;
		this.width = width;
		this.height = height;
		this.content = content;
		this.rendererFilePath = "null";
		renderer = null;
		loadDefaultSettings(renderer_config);
	}

	public void loadDefaultSettings(boolean renderer_config) {

		exportFileFormat = null;

	}

	public static void main(String args[]) {

		FigureBuilder config = test();

		File output = FileBrowser.save();
		XMLFileTools.save(config, output);
	}

	public void execute(JHEQEnvironment env, String input, JHEQToolbox app) {

		setupRenderer();
		Figure fig = createFigure(app, env, input, renderer);

		// if (this.customFigurePath != null) {
		// fig=
		// }
		// Figure ext = (Figure) XMLFileTools.loadContent(Figure.class, new
		// File(customFigurePath));

		// }//

		displayFig(fig);
		exportFig(fig);

	}

	public void setupRenderer() {

		renderer = new RendererConfiguration();
		if (this.rendererFilePath != null) {
			if (!this.rendererFilePath.equals("null")) {
				try {
					RendererConfiguration loadRenderer = XMLFileTools.loadContent(RendererConfiguration.class,
							new File(this.rendererFilePath));
					renderer = loadRenderer;
				} catch (Exception badRenderer) {
					Console.warn("unable to load custom renderer for figure " + this + " from file path "
							+ this.rendererFilePath, badRenderer);
				}
			}
		}
		ChartUtils.includeVarNameInLabel = renderer.isIncludeVarNameInLabel();
	}

	public Figure createFigure(JHEQToolbox app, JHEQEnvironment env, String input, RendererConfiguration renderer) {

		Figure fig = new Figure(width, height, mainTitle);
		if (this.customFigurePath != null) {
			Figure f = XMLFileTools.loadContent(Figure.class, new File(this.customFigurePath));

			fig = new Figure(f, width, height, mainTitle);
		}
		fig.setSize(width, height);
		fig.getTitle().setText(mainTitle);
		// if (ext_figure != null) {
		// fig = new Figure(ext_figure, height, width, mainTitle);
		// }
		// fig = ext_figure;// new Figure(width, height, mainTitle);

		for (int row = 0; row < content.length; row++) {
			for (int col = 0; col < content[row].length; col++) {

				try {
					JHEQFeature feat = content[row][col];
					display = true;

					if (FieldFinder.containsSuper(feat, ChartBuilder.class)) {
						ChartBuilder chart = (ChartBuilder) feat;
						chart.getComponent(env, input, fig, row, col, renderer);

					} else if (FieldFinder.containsSuper(feat, FigureBuilder.class)) {
						FigureBuilder subFig = (FigureBuilder) feat;
						subFig.display = false;
						subFig.getComponent(app, env, input, fig, row, col, renderer);

					}
				} catch (Exception badDisplay) {
					Console.error("unable to add view to figure " + fig + " using feature " + content[row][col],
							badDisplay);
				}

			}

		}

		return fig;
	}

	public void displayFig(Figure fig) {

		try {
			if (this.exportFilePath == null) {
				// if (display) {
				fig.display();
			}
			// }
		} catch (Exception badGenerate) {
			Console.error("unable to display or export figure " + fig, badGenerate);
		}

	}

	public void exportFig(Figure fig) {

		if (this.exportFilePath != null) {
			if (!this.exportFilePath.equals("null")) {
				try {
					fig.exportToFile(new File(exportFilePath), exportFileFormat);
				} catch (Exception badRenderer) {
					Console.warn("unable to export figure " + this + " from file path " + this.rendererFilePath,
							badRenderer);
				}
			}

		}

	}

	@Override
	public void createTemplate(File file) {

		JHEQFeature[][] contents = new JHEQFeature[][]
			{
					{ new ChartBuilder() } };
		FigureBuilder fig = new FigureBuilder("Main Title", 500, 500, contents, true);
		if (file != null) {
			XMLFileTools.save(fig, new File(file, "/tasks/figureDefinition.xml"));
		}

	}

	public void getComponent(JHEQToolbox app, JHEQEnvironment env, String input, Figure figure, int row, int col,
			RendererConfiguration renderer) {

		Figure fig = createFigure(app, env, input, renderer);
		if (mainTitle == null) {

		}
		figure.add(row, col, fig.getFrame().getContentPane());
		return;
	}

	@Override
	public void perform(JHEQToolbox application, String input) {

		Console.debug("building figure" + input);
		display = true;
		Figure fig = createFigure(application, application.getEnvironment(), input, renderer);
		displayFig(fig);
		exportFig(fig);
	}

}
