/* ===========================================================
 * HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 * ------------------------------------------------
 * ODEInterface.java
 * ------------------------------------------------
 *
 * Original Author:  Brendan Short
 * Contributor(s):   
 *
 * Changes:
 * --------
 * 01-June-2018 : Version 1 (BS);
 *
 */

package edu.ucsc.cross.jheq.worker;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;

/**
 * A Provides the computations and organization necessary to run a simulation.
 * It has been modified to support hybrid systems without requiring
 * pre-specified thresholds to detect discrete events. This is an improvement
 * from having to explicitly define each condition that triggers a jump.
 * 
 * Intended Operator: System
 */
public class EquationMap implements FirstOrderDifferentialEquations {

	/**
	 * Engine supervisor that works with this instance of ODE interface
	 */
	private EngineSupervisor content;

	/**
	 * Constructor for the ODE interface
	 * 
	 * @param content
	 *            engine supervisor
	 */
	public EquationMap(EngineSupervisor content) {

		this.content = content;
	}

	/**
	 * Computes the new derivatives of each hybrid state element using the newly
	 * stored values from vector y
	 * 
	 * @param t
	 *            - current time elapsed
	 * 
	 * @param y
	 *            - vector containing all values being evaluated by the ode
	 * 
	 * @param yDot
	 *            - vector containing all derivative values being evaluated by the
	 *            ode
	 */
	public void computeDerivatives(double t, double[] y, double[] yDot)
			throws MaxCountExceededException, DimensionMismatchException {

		// compute flow maps where applicable
		content.getDynamicsEvaluator().evaluateDynamics(false);
		// load results from flow map computations
		content.getObjectManipulator().updateChangeVector(yDot);

	}

	/**
	 * Get the dimension of the ode vector
	 * 
	 * @return length of the ode vector
	 */
	@Override
	public int getDimension() {

		return content.getObjectManipulator().getSimulatedObjectValueVector().length;
	}
}