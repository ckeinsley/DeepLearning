
/*
 * =========================================================== HSE : The Hybrid Systems Environment
 * ===========================================================
 *
 * MIT License
 * 
 * Copyright (c) 2018 HybridSystemsEnvironment
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
 * Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * 
 * ------------------------------------------------ HybridSys.java ------------------------------------------------
 *
 * Original Author: Brendan Short Contributor(s):
 *
 * Changes: -------- 23-August-2018 : Version 1 (BS);
 * 
 */

package edu.ucsc.cross.jheq.model;

import java.util.ArrayList;

import com.be3short.data.cloning.ObjectCloner;
import com.be3short.obj.access.FieldFinder;

import edu.ucsc.cross.jheq.environment.JHEQEnvironment;
import edu.ucsc.cross.jheq.logging.Console;
import edu.ucsc.cross.jheq.network.Network;
import edu.ucsc.cross.jheq.network.NodeLocator;
import edu.ucsc.cross.jheq.object.DataStructure;
import edu.ucsc.cross.jheq.object.MappedObject;
import edu.ucsc.cross.jheq.object.VariableSet;
import edu.ucsc.cross.jheq.worker.EngineSupervisor;

/**
 * Generalized hybrid system with dynamics given by externally defined mappings
 * and sets.
 * 
 * @author Brendan Short
 *
 * @param <X>
 *            class type of hybrid system state
 */
public class HybridSystemModel<X extends DataStructure> extends DataStructure implements HybridDynamics<X>, HybridSystem

{

	/**
	 * State used to store the derivative values of the state during flows or the
	 * updated state values after a jump.
	 */
	X dynamicState;

	/**
	 * Externally defined flow map
	 */
	protected FlowMap<X> flowMap;

	/**
	 * Externally defined flow set
	 */
	protected FlowSet<X> flowSet;

	/**
	 * Externally defined jump map
	 */
	protected JumpMap<X> jumpMap;

	/**
	 * Externally defined jump set
	 */
	protected JumpSet<X> jumpSet;

	/**
	 * The current state of the system
	 */
	X state;

	private VariableSet variables;

	private boolean autoUpdateMaps;

	/**
	 * Constructor for generalized hybrid system
	 * 
	 * @param <Z>
	 * @param <Q>
	 * @param <Z>
	 * @param <Q>
	 * 
	 * @param <R>
	 * @param <C>
	 * 
	 * @param state
	 *            system state
	 * @param flow_map
	 *            flow map definition
	 * @param jump_map
	 *            jump map definition
	 * @param flow_set
	 *            flow set definition
	 * @param jump_set
	 *            jump set definition
	 * @param parameters
	 *            list of any components (parameters, inputs, networks etc)
	 */
	HybridSystemModel(X state, FlowMap<X> flow_map, JumpMap<X> jump_map, FlowSet<X> flow_set, JumpSet<X> jump_set,
			Object[] params) {

		this(state, flow_map, jump_map, flow_set, jump_set, new VariableSet(params));

	}

	/**
	 * Constructor for generalized hybrid system
	 * 
	 * @param <Z>
	 * @param <Q>
	 * @param <Z>
	 * @param <Q>
	 * 
	 * @param <R>
	 * @param <C>
	 * 
	 * @param state
	 *            system state
	 * @param flow_map
	 *            flow map definition
	 * @param jump_map
	 *            jump map definition
	 * @param flow_set
	 *            flow set definition
	 * @param jump_set
	 *            jump set definition
	 * @param parameters
	 *            list of any components (parameters, inputs, networks etc)
	 */
	HybridSystemModel(X state, FlowMap<X> flow_map, JumpMap<X> jump_map, FlowSet<X> flow_set, JumpSet<X> jump_set,
			VariableSet params) {

		this.state = state;
		this.state.properties().setStoreTrajectory(true);
		autoUpdateMaps = false;
		flowMap = flow_map;
		jumpMap = jump_map;
		flowSet = flow_set;
		jumpSet = jump_set;

		variables = params;

	}

	/**
	 * Computes the flow set
	 */
	@Override
	public boolean C(X x) {

		return flowSet.evaluateC(x, this);
	}

	public boolean C() {

		return C(getState());
	}

	public boolean containsObject(Object child) {

		if (state.equals(child)) {
			return true;
		}

		return variables.contains(child);
	}

	/**
	 * Computes the jump set
	 */
	@Override
	public boolean D(X x) {

		return jumpSet.evaluateD(x, this);
	}

	public boolean D() {

		return D(getState());
	}

	@Override
	public JHEQEnvironment environment() {

		return EngineSupervisor.getEnv(this);
	}

	/**
	 * Computes the flow map
	 */
	@Override
	public void F(X x, X x_dot) {

		flowMap.evaluateF(x, x_dot, this);
	}

	/**
	 * Computes the jump map
	 */
	@Override
	public void G(X x, X x_plus) {

		jumpMap.evaluateG(x, x_plus, this);

	}

	/**
	 * Get the dynamic state component used by the jump and flow maps
	 * 
	 * @param components
	 *            system components to fetch dynamic state from
	 * @return dynamic state
	 * @param <Z>
	 *            specific class of dynamic state
	 * @param <Q>
	 */
	protected X getDynamicState() {

		return dynamicState;
	}

	/**
	 * @return the flowMap
	 */
	public FlowMap<X> getFlowMap() {

		return flowMap;
	}

	/**
	 * @return the flowSet
	 */
	public FlowSet<X> getFlowSet() {

		return flowSet;
	}

	/**
	 * @return the jumpMap
	 */
	public JumpMap<X> getJumpMap() {

		return jumpMap;
	}

	/**
	 * @return the jumpSet
	 */
	public JumpSet<X> getJumpSet() {

		return jumpSet;
	}

	/**
	 * Get the current state of the hybrid system
	 * 
	 * @return the current state of the hybrid system
	 */
	public X getState() {

		return state;
	}

	/**
	 * Initialize the dynamic state component
	 * 
	 * @param components
	 *            system components to initialize the dynamic state for
	 * @param <Z>
	 *            specific class of dynamic state
	 */
	protected void initializeDynamicState() {

		dynamicState = ObjectCloner.deepInstanceClone(getState());
	}

	@Override
	public HybridSystemModel<?> model() {

		return (HybridSystemModel<?>) this;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <Z extends DataStructure> HybridSystemModel<Z> model(Class<Z> state_class) {

		return (HybridSystemModel<Z>) this;
	}

	/**
	 * @param flowMap
	 *            the flowMap to set
	 */
	public void setFlowMap(FlowMap<X> flowMap) {

		this.flowMap = flowMap;
	}

	/**
	 * @param flowSet
	 *            the flowSet to set
	 */
	public void setFlowSet(FlowSet<X> flowSet) {

		this.flowSet = flowSet;
	}

	/**
	 * @param jumpMap
	 *            the jumpMap to set
	 */
	public void setJumpMap(JumpMap<X> jumpMap) {

		this.jumpMap = jumpMap;
	}

	/**
	 * @param jumpSet
	 *            the jumpSet to set
	 */
	public void setJumpSet(JumpSet<X> jumpSet) {

		this.jumpSet = jumpSet;
	}

	@Override
	public Object state() {

		return getState();
	}

	@Override
	public <Z extends DataStructure> Z state(Class<Z> state_class) {

		Z st = null;
		if (state_class.equals(getState().getClass())) {
			st = model(state_class).getState();// (state_class.cast(getState());
		}
		return st;
	}

	@Override
	public VariableSet variables() {

		updateMappings();
		return variables;
	}

	/**
	 * Access the flow set method of a specific hybrid system
	 * 
	 * @param sys
	 *            hybrid system to access.
	 * @param <T>
	 *            specific class of the hybrid system state
	 * @param <P>
	 * @return true if system is in flow set
	 */
	public static <T extends DataStructure> boolean c(HybridSystemModel<T> sys) {

		return sys.C(sys.getState());
	}

	/**
	 * Access the jump set method of a specific hybrid system
	 * 
	 * @param sys
	 *            hybrid system to access.
	 * @param <T>
	 *            specific class of the hybrid system state
	 * @param <P>
	 * @return true if system is in jump set
	 */
	public static <T extends DataStructure> boolean d(HybridSystemModel<T> sys) {

		return sys.D(sys.getState());
	}

	/**
	 * Access the flow map method of a specific hybrid system
	 * 
	 * @param sys
	 *            hybrid system to access.
	 * @param <T>
	 *            specific class of the hybrid system state
	 * @return data structure containing state derivatives.
	 */
	public static <T extends DataStructure> T f(HybridSystemModel<T> sys) {

		if (HybridSystemModel.c(sys)) {
			sys.F(sys.getState(), sys.getDynamicState());
		}
		return sys.getDynamicState();
	}

	/**
	 * Access the jump map method of a specific hybrid system
	 * 
	 * @param sys
	 *            hybrid system to access.
	 * @param <T>
	 *            specific class of the hybrid system state
	 * @param <P>
	 * @param <L>
	 * @return data structure containing updated state values
	 */
	public static <T extends DataStructure> T g(HybridSystemModel<T> sys) {

		if (HybridSystemModel.d(sys)) {
			Console.debug("Jump occurring in " + sys);
			sys.G(sys.getState(), sys.getDynamicState());
		}
		return sys.getDynamicState();
	}

	/**
	 * Access the dynamic variable of a specific hybrid system
	 * 
	 * @param sys
	 *            hybrid system to access.
	 * @param <T>
	 *            specific class of the hybrid system state
	 * @param <P>
	 * @return the dynamic variable
	 */
	public static <T extends DataStructure> T getDynamicState(HybridSystemModel<T> sys) {

		return sys.getDynamicState();
	}

	/**
	 * Initialize the dynamic variable of a specific hybrid system
	 * 
	 * @param sys
	 *            the hybrid system to initialize
	 * @param <T>
	 *            specific class of the hybrid system state
	 * @param <P>
	 */
	public static <T extends DataStructure> void initializeDynamicState(HybridSystemModel<T> sys) {

		sys.initializeDynamicState();
	}

	public void updateMappings() {

		if (this.isAutoUpdateMaps()) {
			ArrayList<Object> maps = new ArrayList<Object>(variables.getVariables());

			for (Object obj : maps) {
				if (FieldFinder.containsSuper(obj, MappedObject.class)) {
					MappedObject mapObj = (MappedObject) obj;
					mapObj.evaluate(this);
				}
			}
		}
		// }
	}

	@Override
	public Network network() {

		return environment().getNetwork();
	}

	@Override
	public NodeLocator connections() {

		return NodeLocator.create(network(), this);
	}

	/**
	 * @return the autoUpdateMaps
	 */
	public boolean isAutoUpdateMaps() {

		return autoUpdateMaps;
	}

	/**
	 * @param autoUpdateMaps
	 *            the autoUpdateMaps to set
	 */
	public void setAutoUpdateMaps(boolean autoUpdateMaps) {

		this.autoUpdateMaps = autoUpdateMaps;
	}
}
