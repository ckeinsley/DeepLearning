
package edu.ucsc.cross.hse.core.figure.test;

import edu.ucsc.cross.jheq.figure.FormatSelector;
import edu.ucsc.cross.jheq.figure.GraphicFormat;
import edu.ucsc.cross.jheq.logging.Console;

/**
 * A non-automated test of the graphic format selector
 * 
 * @author Brendan Short
 *
 */
public class FormatSelectorInteractiveTest {

	/**
	 * Run test
	 * 
	 * @param args
	 *            unused
	 */
	public static void main2(String args[]) {

		Console.getSettings().printDebug = true;
		GraphicFormat selectedFormat = FormatSelector.selectGraphicFormatFromWindow();
		System.out.println("Format selected: " + selectedFormat.getFormatName());
	}

	public static void main(String args[]) {

	}
}
