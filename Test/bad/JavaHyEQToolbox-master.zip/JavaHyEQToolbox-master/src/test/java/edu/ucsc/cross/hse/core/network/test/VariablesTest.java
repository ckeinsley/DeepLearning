
package edu.ucsc.cross.hse.core.network.test;

public class VariablesTest {

	public static void main(String args[]) {

	}

}
