
package edu.ucsc.cross.jheq.core.file.test;

import edu.ucsc.cross.jheq.file.FileBrowser;
import edu.ucsc.cross.jheq.logging.Console;

/**
 * A non-automated test of the graphic format selector
 * 
 * @author Brendan Short
 *
 */
public class FileBrowserInteractiveTest {

	/**
	 * Run test
	 * 
	 * @param args
	 *            unused
	 */
	public static void main(String args[]) {

		Console.getSettings().printDebug = true;
		System.out.println(FileBrowser.getRelativeFilePath(FileBrowser.directory("Select")));
		// System.out.println("Format selected: " + selectedFormat.getFormatName());
	}
}
