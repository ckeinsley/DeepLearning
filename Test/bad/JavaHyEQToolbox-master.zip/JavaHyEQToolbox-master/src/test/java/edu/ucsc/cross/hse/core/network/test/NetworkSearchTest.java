
package edu.ucsc.cross.hse.core.network.test;

import com.be3short.io.xml.XMLParser;

import edu.ucsc.cross.jheq.network.Connection;
import edu.ucsc.cross.jheq.network.Network;
import edu.ucsc.cross.jheq.network.NodeLocator;

public class NetworkSearchTest {

	public static class NodeA {

	}

	public static class NodeB {

	}

	public static void main(String args[]) {

		Network net = new Network(true);
		NodeA a1 = new NodeA();
		// NodeB b1 = new NodeB();
		// NodeA a2 = new NodeA();
		NodeB b2 = new NodeB();

		net.connect(a1, b2);
		NodeLocator ab = NodeLocator.create(net, a1);
		System.out.println(XMLParser.serializeObject(ab.getAllObjects(Connection.INCOMING)));
		System.out.println(XMLParser.serializeObject(ab.getAllObjects(Connection.OUTGOING)));
		System.out.println(XMLParser.serializeObject(ab.getAllObjects(Connection.INCOMING)));
		System.out.println(XMLParser.serializeObject(ab.getAllObjects(Connection.OUTGOING)));

	}

	public static void addByAdjacency() {

		Network net = new Network(true);
		NodeA a1 = new NodeA();
		NodeB b1 = new NodeB();
		NodeA a2 = new NodeA();
		NodeB b2 = new NodeB();
		net.connect(new Object[]
			{ a1, a2, b1, b2 }, new int[][]
			{
					{ 0, 1, 1, 1 },
					{ 0, 0, 0, 0 },
					{ 1, 0, 0, 0 },
					{ 0, 0, 0, 0 } });
		NodeLocator ab = NodeLocator.create(net, a1);
		System.out.println(XMLParser.serializeObject(ab.getAllObjects(Connection.INCOMING)));
		System.out.println(XMLParser.serializeObject(ab.getAllObjects(Connection.OUTGOING)));

	}

}
