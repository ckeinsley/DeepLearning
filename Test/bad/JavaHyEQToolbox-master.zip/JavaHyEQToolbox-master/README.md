# Overview
This documentation describes the Java Hybrid Equations Toolbox  package implemented in Java for the simulation of hybrid dynamical systems.  This package is capable of computing approximations of trajectories of hybrid systems that are defined by differential and difference equations with constraints.  It also performs these computations at a much higher speed than achieved using similar tools.  This environment is suitable for simulating hybrid systems with trajectories that can be Zeno or have multiple jumps at the same time. These hybrid systems can be interconnected and simulated with or without inputs.  It allows connections with external components, allowing for data to extend outside the environment.

This readme does not contain the full documentation on how to use this software package.  Please see the complete documentation at https://github.com/JavaHyEQ/JavaHyEQDocumentation.git  for more information.

# QuickStart

## Installation
This section demonstrates how to use the JavaHyEQ toolbox.

2.1 Prerequisites

1. Java is (SE) installed on your computer

2. Java Developer Kit (JDK) is is installed on your computer

3. Git command line tools installed.

The java SE and JDK installation instructions can be found here https://www.oracle.com/
technetwork/java/javase/downloads/index.html The git command line tools installation in-
structions can be found here https://gist.github.com/derhuerst/1b15ff4652a867391f03
Gradle: add the following items to build.gradle

```
java
    repositories {
        ...
        maven { url "https://jitpack.io" }
    }

 
    dependencies {
    ...
compile 'com.github.JavaHyEQ:JavaHyEQToolbox:v1.0.0
}


ar {
  manifest { 
    attributes "Main-Class": 'edu.ucsc.cross.jheq.core.app.JavaHyEQExecute'
  }  

  from {
    configurations.compile.collect { it.isDirectory() ? it : zipTree(it) }
  }
  from {sourceSets.main.allSource}
   baseName 'JavaHyEQApplication'
}
```

Alternatively, the jar file can be downloaded or assembled from the binaries and included as a project dependency manually. The easiest way by far is to clone or download the template file, which is ready to modify and use right away 

Generic Template: https://github.com/JavaHyEQ/JavaHyEQProject.git



## SETUP
Choose a directory where you would like your projects to be located .  The following sequence of commands will aquire and prepare a project for use.  In this particular instance, I am using git to download the files, and the bouncing ball example application. 

```
eduroam-###-###-###-###:gitdump beshort$ git clone https://github.com/be3short/BouncingBallExample.git
Cloning into 'BouncingBallExample'...
remote: Enumerating objects: 48, done.
remote: Counting objects: 100% (48/48), done.
remote: Compressing objects: 100% (32/32), done.
remote: Total 48 (delta 3), reused 44 (delta 3), pack-reused 0
Unpacking objects: 100% (48/48), done.
eduroam-###-###-###-###:gitdump beshort$ cd BouncingBallExample/jheq/
eduroam-###-###-###-###:jheq beshort$ ./buildLib 
Download https://jitpack.io/com/github/JavaHyEQ/JavaHyEQToolbox/-SNAPSHOT/maven-metadata.xml
Download https://jitpack.io/com/github/be3short/ObjectTools/-SNAPSHOT/maven-metadata.xml
Download https://jitpack.io/com/github/HybridSystemsEnvironment/MathToolbox/-SNAPSHOT/maven-metadata.xml
Download https://jitpack.io/com/github/ronmamo/reflections/-SNAPSHOT/maven-metadata.xml
Download https://jitpack.io/com/github/be3short/IOTools/-SNAPSHOT/maven-metadata.xml

BUILD SUCCESSFUL in 18s
3 actionable tasks: 2 executed, 1 up-to-date

```
That is the expected series of events if everything is setup correctly.  
## Usage Overview
   This section is in an overview of how to operate a \hse project.  The system console is used to interact with the application, this documentation has instructions for a OSX/Linux terminal that may require a different syntax for Windows command prompt.
A. App Root Directory: The root directory of a \hse project application is the jheq directory, which all commands must be run from. Navigate to this directory from the main project directory before doing anything:
   
```
cd jheq/

```

### Build Library : 
The library jar file is compiled by executing the build script from the jheq directory 

```
 ./buildLib
 
 ```
 %The resulting library jar file will be build/libs/JavaHyEQApplication.jar.   Note: The library only needs to be recompiled when a change is made to the source code, but must be compiled before running the application for the first time.}
 
### Running the Application
  The application is launched by executing the run script from the jheq directory. To run the application, navigate to the jheq folder and execute the run script by entering

```
 ./runEnv
```
where the following message indicates if the application is loaded successfully  If this returns the statement "Error: Unable to access jarfile ../build/libs/JavaHyEQApplication.jar", return to Section to build the library and then retry. 
 
```
[09:50:53.830][info] Initializing the JavaHyEQ Toolbox...  [3/123 mB]
 [09:50:56.883][info] JavaHyEQ Toolbox loaded successfully  [304/631 mB]
``` 
 These messages will be followed by a menu with an indexed list of tasks that the application can perform in the following format
 
  ``` 	
  Application Tasks:
 	---------------------------------------------------------------------------------------------  
 	[ 0 ] : task0.xml (FigureDefinition)
 	---------------------------------------------------------------------------------------------  
 	[ 1 ] : task1.xml (ContentGenerator)
 	---------------------------------------------------------------------------------------------  
 	
 	>>>
 ```


### Tasks: 
Each task is loaded from an xml file that defines what will be executed.  See Appendix  of the full documentation for information if you are not familiar with the XML format}  The tasks are listed by path with a suffix containing the task type in parenthesis. The core task types are : 


- ContentDefinition : Creates generator components and main generator task file using a file dialog to specify the directory where to create the generator file, then creates the components in the resource directory using the path of the generator task file.\\
 	
- FigureDefinition :  Generates and displays a figure, which can be saved to a file by pressing control+s to open a file and format dialog
 	
- ContentGenerator:  Generates hybrid systems and global variables based on the configuration files, and the defined set and adjacency matrix

# Resources
To create a new project, the template or one of the examples can be copied and modified.  The template has many components implemented to accomidate as many situations as possible, any unnecessary ones can be deleted.  The full documentation provides a lot more detail if anything seems challenging.

## Core Library
This is the library that must be included in every project that will use the toolbox:

Toolbox Repository:  https://github.com/JavaHyEQ/JavaHyEQToolbox.git
## Template  Library
There is only one template available right now but it  is already configured and contains most of the component files and is a good place for beginners:

Generic Template: https://github.com/JavaHyEQ/JavaHyEQProject.git

## Examples
There are a number of examples that cover a variety of applications, the links are listed below:

BouncingBall: https://github.com/JavaHyEQ/BouncingBall.git

Consensus Network: https://github.com/JavaHyEQ/ConsensusNetwork.git

Stock Evaluator: https://github.com/JavaHyEQ/StockEvaluator.git

Hybrid Inverter: https://github.com/JavaHyEQ/HybridPowerInverter.git

Fireflies: https://github.com/JavaHyEQ/FireflySynchronization.git

Social Nodes: https://github.com/JavaHyEQ/SocialNodes.git

SmartDataModule: https://github.com/JavaHyEQ/SmartDataModule.git

### Step by Step
Steps to install and run
0. connect to internet - this is important
1. open terminal
2. navigate to directory to store example
3. clone example : git clone https://github.com/JavaHyEQ/BouncingBall.git
4. navigate to app directory: cd BouncingBall/jheq . (in all examples jheq is app directory
5. build library : ./buildLib
6. run app: ./runEnv
7. select menu options to run : 1:run:0 (for bouncing ball, I'll put exactly what to enter for each below)
7a. enter menu command to see full menu: menu
8. quit : quit

Here is exactly what to type from the main menu after running the app (./runEnv)
BouncingBall: 1;run;0
Consensus Network: 4;run;1
Stock Evaluator: 1;run;0
Hybrid Inverter: 5;run;1
Fireflies: 2 -m 2;0;run;1
SocialNodes: 3;run;1

For the main data module demo there are 3 modes:
TooSlow: 4;run;0
SlightlySlow: 3;run;0
Fast: 2;run;0

To you can change the run time by adding -t tmax -j jmax args, like the following example that shows the minimal delay in the fast data module
Fast: 2;run -t 2.5 -j 250;0

## Documentation
The user manual is available at \burl{
https://github.com/JavaHyEQ/JavaHyEQDocumentation/blob/master/JavaHyEq_UserManual_v1_0.pdf
}
 

 It covers the main content but it is a work in progress with some features lacking documentation.  Feel free to contact me with questions, and of course feel free to write your own additions.

 
## Contact 
Any questions or feedback is welcome at javahyeq@gmail.com.

## Acknowledgements
Thank you to the Center for Research in Open Source Software (CROSS) for the support and collaboration on this project (https://cross.ucsc.edu/).  Also thank you to Dr. Ricardo Sanfelice, for providing the opportunity to work on this, and for all of his support (https://hybrid.soe.ucsc.edu/).

