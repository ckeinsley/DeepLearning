# Colliding Response

TODO