# AccelerationComponent

TODO
