package de.wolc.spiel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import de.wolc.spiel.locher.SimLocher;
import de.wolc.spiel.papier.Konfetti;

/**
 * Die Spieler Klasse ist die primäre öffentliche API. Die GUI Implementation sollte hiervon eine neue Instanz erstellen
 * und dann die Getter und Setter in dem erzeugen Objekt und deren Unterobjekte verwenden.
 */
public class Spieler implements Serializable {
    /** MUSS um 1 erhöht werden, wenn sich die Eigenschaften der Klasse ändern. */ 
    private static final long serialVersionUID = 2L;
    
    private SimLocher locher;
    private SchreibtischSkin schreibtischSkin;
    private ArrayList<Konfetti> konfetti;

    public Spieler() {
        this.locher = new SimLocher();
        this.schreibtischSkin = SchreibtischSkin.BACKGROUND_BASE;
        this.konfetti = new ArrayList<Konfetti>();
    }

    /**
     * @return the schreibtischSkin
     */
    public SchreibtischSkin getSchreibtischSkin() {
        return this.schreibtischSkin;
    }

    /**
     * @param schreibtischSkin the schreibtischSkin to set
     */
    public void setSchreibtischSkin(SchreibtischSkin schreibtischSkin) {
        this.schreibtischSkin = schreibtischSkin;
    }

    /**
     * Gibt den Locher des Spielers zurück.
     * @return Der Locher.
     */
    public SimLocher getLocher() {
        return this.locher;
    }

    /**
     * Gibt das die Konfettiliste des Spielers zurück. Diese repräsentiert den Punktestand.
     * Hinweis: Nach dem Lochen muss dieser Liste manuell das erzeugte Konfetti hinzugefügt werden (falls gewünscht).
     * @return Die Liste von Konfetti.
     */
    public ArrayList<Konfetti> getKonfetti() {
        return this.konfetti;
    }

    /**
     * Gibt eine HashMap mit allen Konfetti Arten sortiert zurück.
     * @return The HashMap.
     */
    public HashMap<Farbe, ArrayList<Konfetti>> getKonfettiSortiert() {   
        HashMap<Farbe, ArrayList<Konfetti>> hash = new HashMap<>();
        for(Konfetti konfetti : this.getKonfetti()) {
            Farbe farbe = konfetti.getFarbe();
            ArrayList<Konfetti> zahl = hash.get(farbe);
            if (zahl == null) {
                zahl = new ArrayList<>();
                hash.put(farbe, zahl);
            }
            zahl.add(konfetti);
        }
        return hash;
    }

    /**
     * Muss regelmäßig von der GUI aufgerufen werden um der Logik ein "Zeitgefühl" zu verschaffen.
     * Ruft automatisch die "tick" Methode des Lochers auf!
     * @param deltaZeit Die vergangene Zeit in Sekunden. (Kann/sollte auch Kommazahl sein!)
     */
    public void tick(double deltaZeit) {
        locher.tick(deltaZeit);
    }
}
