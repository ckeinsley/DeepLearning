/**
 * Annotations and support classes for use as part of the Java API for Azure Functions.
 */
package com.microsoft.azure.functions.annotation;