/**
 * The root package for the Java API for Azure Functions.
 */
package com.microsoft.azure.functions;