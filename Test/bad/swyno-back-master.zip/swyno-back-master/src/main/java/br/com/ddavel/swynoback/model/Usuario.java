package br.com.ddavel.swynoback.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Usuario implements Serializable {

    @Id
    private Long usuarioId;
    @NotNull
    @NotEmpty
    @Size(min = 1, max = 50)
    private String usuarioNome;
    @NotNull
    @NotEmpty
    @Size(min = 1, max = 50)
    private String usuarioEmail;
    @NotNull
    @NotEmpty
    @Size(min = 6, max = 20)
    private String usuarioSenha;
    @NotNull
    @NotEmpty
    @Size(min = 10, max = 10)
    private String usuarioValidador;
    @NotNull
    private Boolean usuarioConfirmado;

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getUsuarioNome() {
        return usuarioNome;
    }

    public void setUsuarioNome(String usuarioNome) {
        this.usuarioNome = usuarioNome;
    }

    public String getUsuarioEmail() {
        return usuarioEmail;
    }

    public void setUsuarioEmail(String usuarioEmail) {
        this.usuarioEmail = usuarioEmail;
    }

    public String getUsuarioSenha() {
        return usuarioSenha;
    }

    public void setUsuarioSenha(String usuarioSenha) {
        this.usuarioSenha = usuarioSenha;
    }

    public String getUsuarioValidador() {
        return usuarioValidador;
    }

    public void setUsuarioValidador(String usuarioValidador) {
        this.usuarioValidador = usuarioValidador;
    }

    public Boolean getUsuarioConfirmado() {
        return usuarioConfirmado;
    }

    public void setUsuarioConfirmado(Boolean usuarioConfirmado) {
        this.usuarioConfirmado = usuarioConfirmado;
    }
    
    
    
}
