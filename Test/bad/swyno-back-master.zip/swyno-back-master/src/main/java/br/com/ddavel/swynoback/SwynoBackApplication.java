package br.com.ddavel.swynoback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwynoBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwynoBackApplication.class, args);
	}
}
