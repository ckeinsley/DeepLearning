package br.com.ddavel.swynoback.controller;

import br.com.ddavel.swynoback.model.Usuario;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("usuario")
public class UsuarioController {
    
    @GetMapping(path = "/{id}", produces = "application/json")
    public Usuario findByUsuarioId(@PathVariable int id){
        Usuario usuario = new Usuario();
        usuario.setUsuarioId(Long.valueOf("5"));
        usuario.setUsuarioNome("diego davel");
        usuario.setUsuarioEmail("diegodavel@gmail.com");
        usuario.setUsuarioSenha("31624400");
        usuario.setUsuarioValidador("0000000000");
        usuario.setUsuarioConfirmado(true);        
        return usuario;
    }
    
}
