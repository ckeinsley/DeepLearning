package blackjack;

import java.util.*;

import org.junit.Test;

public class HandTest {

	@Test
	public void testNewHand() {
		List<Card> cards = new ArrayList<Card>();
		Hand hand = new Hand(cards);
		//hand.newHand(cards);
	}

}
