Sinks
=====

.. toctree::
   :maxdepth: 4

   Elasticsearch <elasticsearch_sink>
   AWS Elasticsearch Service<awselasticsearch_sink>
   Graphite <graphite_sink>
   InfluxDB <influxdb_sink>
   S3 <s3_sink>
   Kinesis <kinesis_sink>