package lumbermill.internal;

public class JsonParseException extends RuntimeException {

    public JsonParseException(Throwable cause) {
        super(cause);
    }
}
