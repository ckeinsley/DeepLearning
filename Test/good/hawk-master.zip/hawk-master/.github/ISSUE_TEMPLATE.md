Please try to fill all questions below before submitting an issue.

- [ ] On which android versions do you have this issue? :
- [ ] On which phones do you have this issue? :
- [ ] Which hawk version are you using? :
- [ ] Does this issue happen always or is it flaky? :
- [ ] Can you write failing test? :
- [ ] If it is Hawk.put and Hawk.get issue, can you write down which data you were trying to save and get it back?
- [ ] Is the data you are trying to save it huge or small?