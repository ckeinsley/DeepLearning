package me.geometrically.prehistoric.server.block;

public class BlockPinkMagnoliaSapling extends BlockMagnoliaSapling {
    public BlockPinkMagnoliaSapling(String name) {
        super(name);
    }

    @Override
    public String getType() {
        return "pink";
    }
}
