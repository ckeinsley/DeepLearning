package me.geometrically.prehistoric.server.proxy;

import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class ServerProxy implements IProxy{

    @Override
    public void preInit() {

    }
    @Override
    public void init() {

    }
    @Override
    public void postInit() {
    }

}

