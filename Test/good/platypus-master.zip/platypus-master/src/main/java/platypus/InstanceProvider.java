package platypus;

public interface InstanceProvider<T> {
    public T provide();
}
