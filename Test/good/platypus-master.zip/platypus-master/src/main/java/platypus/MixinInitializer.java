package platypus;

public interface MixinInitializer {

    public abstract void initialize(MixinImplementor mixinImplementor);
}