package com.rj.dinosaurs.domain.enumeration;

/**
 * The Diet enumeration.
 */
public enum Diet {
    HERBIVORE, CARNIVORE, OMNIVORE
}
