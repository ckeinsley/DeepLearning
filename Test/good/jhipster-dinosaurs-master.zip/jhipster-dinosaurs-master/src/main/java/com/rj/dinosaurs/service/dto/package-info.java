/**
 * Data Transfer Objects.
 */
package com.rj.dinosaurs.service.dto;
