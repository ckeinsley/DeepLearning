/**
 * View Models used by Spring MVC REST controllers.
 */
package com.rj.dinosaurs.web.rest.vm;
