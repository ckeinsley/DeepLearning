/**
 * JPA domain objects.
 */
package com.rj.dinosaurs.domain;
