export * from './dinosaur.service';
export * from './dinosaur-update.component';
export * from './dinosaur-delete-dialog.component';
export * from './dinosaur-detail.component';
export * from './dinosaur.component';
export * from './dinosaur.route';
