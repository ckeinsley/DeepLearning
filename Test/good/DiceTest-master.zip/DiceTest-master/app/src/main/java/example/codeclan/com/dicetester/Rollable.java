package example.codeclan.com.dicetester;

/**
 * Created by user on 22/06/2017.
 */

public interface Rollable {
    int roll();
}
