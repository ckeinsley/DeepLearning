package android.databinding;

import java.util.ArrayList;

/**
 * Created by john on 8/29/16.
 */
public class ObservableArrayList<T> extends ArrayList<T> {
}
