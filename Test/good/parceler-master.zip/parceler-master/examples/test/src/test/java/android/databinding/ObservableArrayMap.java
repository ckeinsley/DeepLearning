package android.databinding;

import java.util.HashMap;

/**
 * Created by john on 8/29/16.
 */
public class ObservableArrayMap<T, V> extends HashMap<T, V> {
}
