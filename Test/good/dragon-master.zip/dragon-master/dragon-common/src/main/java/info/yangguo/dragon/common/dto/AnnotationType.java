package info.yangguo.dragon.common.dto;

public class AnnotationType {
    public static final String ClientSend = "cs";
    public static final String ClientRecevie = "cr";
    public static final String ServerSend = "ss";
    public static final String ServerReceive = "sr";
    public static final String DubboException = "de";
}
