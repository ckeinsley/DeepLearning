### 介绍

Dapper开源好些年了，该项目是针对Dubbo RPC实现的调用链追踪系统。

该项目主要是为了学习而研发的，在生产跑过一段时间，目前笔者公司的APM已经被[pinpoint](https://github.com/naver/pinpoint)所代替。
