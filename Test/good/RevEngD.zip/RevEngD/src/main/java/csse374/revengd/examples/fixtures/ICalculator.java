package csse374.revengd.examples.fixtures;

public interface ICalculator {
	public double add(double... args);
	public double multiply(double... args);
}
