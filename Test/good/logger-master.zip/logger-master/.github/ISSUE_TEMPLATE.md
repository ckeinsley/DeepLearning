Please try to fill all questions below before submitting an issue.

- Android studio version:
- Android gradle plugin version:
- Logger version:
- Emulator/phone information:
- If possible, please add how did you initialize Logger?
- Is it flaky or does it happen all the time?

