package com.shoeclue.dao;

import com.shoeclue.model.UserOrder;


public interface OrderDao {

    void addOrder(UserOrder userOrder);

}
