package com.pwr.game.gui;

import com.pwr.game.gui.controller.MainFrameController;

public class SpeedingTurtles {

    public static void main(String[] args) {
        new MainFrameController();
    }
}
