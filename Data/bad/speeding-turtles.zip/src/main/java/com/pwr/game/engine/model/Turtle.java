package com.pwr.game.engine.model;

public enum Turtle {

    YELLOW,
    BLUE,
    RED,
    GREEN,
    PURPLE
}
