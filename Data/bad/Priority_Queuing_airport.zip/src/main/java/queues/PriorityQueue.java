package queues;

// Create prioraty queue, to prioratise which passengers can be removed first
// remove the maximum and insert = prioraty queue

public interface PriorityQueue<T extends Comparable<T>> extends IQueue<T> {
    
  }
