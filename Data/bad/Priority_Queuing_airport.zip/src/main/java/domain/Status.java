package domain;

public enum Status {
  Waiting,
  Boarded,
  MissedPlane
  }
