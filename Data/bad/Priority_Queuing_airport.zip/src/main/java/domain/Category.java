package domain;
// setting up passenger constant categories using enum
public enum Category {
  LateToFlight,
  BusinessClass,
  Disabled,
  Family,
  Monkey
  }
