package ua.toe.tac.tic.enums;

public enum Player {
    X,O
}