package interfaces;

public interface ILogger
{
    void Log(String logMessage);
}
