package interfaces;

public interface IFileReader
{
    String ReadDeckFile(String path);
}
