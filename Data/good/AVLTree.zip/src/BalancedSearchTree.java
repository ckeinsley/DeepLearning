/**
 * My implementation of an AVL tree.
 *
 * <p>
 * Bugs: None known
 *
 * @author Hannah Patrick
 */
public class BalancedSearchTree<T extends Comparable<T>> implements BalancedSearchTreeADT<T> {

	// inner node class used to store key items and links to other nodes
	protected class Treenode<K extends Comparable<K>> {
		K key;
		Treenode<K> left;
		Treenode<K> right;

		/**
		 * Constructor: default initialized Treenode has all null values
		 */
		public Treenode() {
			this(null, null, null);
		}

		/**
		 * Constructor: Initializes a Treenode with an inputted key and null children
		 * 
		 * @param item
		 *            to be set to key
		 */
		public Treenode(K item) {
			this(item, null, null);
		}

		/**
		 * Constructor: Initializes a Treenode with a key and left and right children,
		 * based on inputs.
		 * 
		 * @param item
		 *            to be set to key
		 * @param left
		 *            to be set as left child
		 * @param right
		 *            to be set as right child
		 */
		public Treenode(K item, Treenode<K> left, Treenode<K> right) {
			key = item;
			this.left = left;
			this.right = right;
		}

	}

	protected Treenode<T> root;
	protected String inAscending; // used for inAscendingOrder() helper method, so String doesn't
									// clear itself every time

	/**
	 * Constructor: initializes the root to a new Treenode, and initializes the
	 * inAscending string (output string) to empty.
	 */
	public BalancedSearchTree() {
		this.root = new Treenode<T>();
		this.inAscending = "";
	}

	/**
	 * Returns comma separated list of keys in ascending order (calls recursive
	 * helper method).
	 */
	public String inAscendingOrder() {
		if (isEmpty()) {
			return "";
		}
		return inAscendingOrder(root);
	}

	/**
	 * Recursive helper method to generate comma separated list of keys,
	 * <p>
	 * Base case: node is null.
	 * 
	 * @param node
	 * @return comma separated list of keys in ascending order
	 */
	private String inAscendingOrder(BalancedSearchTree<T>.Treenode<T> node) {
		if (node == null) {
			return "";
		}
		inAscendingOrder(node.left);
		inAscending += node.key + ",";
		inAscendingOrder(node.right);
		return inAscending;
	}

	/**
	 * @return true if root is null (meaning there are no keys in the structure)
	 */
	public boolean isEmpty() {
		return root == null || root.key == null;
	}

	/**
	 * Returns the height of this tree (calls recursive helper method).
	 */
	public int height() {
		if (isEmpty()) {
			return 0;
		} else {
			return height(root);
		}
	}

	/**
	 * Recursive helper method that generates the left and right subtree heights of
	 * input node, then returns the maximum one + 1.
	 * <p>
	 * Base case: node is null
	 * 
	 * @param node
	 * @return height of larger subtree + 1
	 */
	private int height(BalancedSearchTree<T>.Treenode<T> node) {
		if (node == null) {
			return 0;
		} else {
			int leftHeight = height(node.left);
			int rightHeight = height(node.right);
			return max(leftHeight, rightHeight) + 1;
		}
	}

	/**
	 * Calculates balance factor for AVL tree. Also handles special cases to prevent
	 * error.
	 * 
	 * @param node
	 * @return height of left node - height of right node (general balance factor
	 *         formula)
	 */
	private int balanceFactor(BalancedSearchTree<T>.Treenode<T> node) {
		// returns 0 if node has no children (node is balanced)
		if (node.left == null && node.right == null) {
			return 0;
			// returns negative height of node right if it doesn't have left
		} else if (node.left == null && node.right != null) {
			return -height(node.right);
			// returns height of node left if it doesn't have right
		} else if (node.right == null && node.left != null) {
			return height(node.left);
		} else {
			return height(node.left) - height(node.right);
		}
	}

	/**
	 * @param value1
	 * @param value2
	 * @return maximum of two inputs
	 */
	private int max(int value1, int value2) {
		if (value1 >= value2) {
			return value1;
		} else {
			return value2;
		}
	}

	/**
	 * Calls recursive helper method to determine if item is in the tree (true if it
	 * is, false if it isn't).
	 */
	public boolean lookup(T item) {
		if (item == null) {
			throw new IllegalArgumentException();
		}
		// if the tree is empty, the item won't be in the tree, so no need to call
		// lookup method
		if (isEmpty()) {
			return false;
		} else {
			return lookup(root, item);
		}
	}

	/**
	 * Recursive helper method to determine if item is in the tree.
	 * 
	 * @param node
	 * @param item
	 *            to be looked up
	 * @return true if item is in the tree, false if it isn't
	 */
	private boolean lookup(BalancedSearchTree<T>.Treenode<T> node, T item) {
		if (item.compareTo(node.key) == 1) {
			return true;
		} else if (item.compareTo(node.key) < 0) {
			lookup(node.left, item);
		} else if (item.compareTo(node.key) > 0) {
			lookup(node.right, item);
		}
		return false;
	}

	/**
	 * Inserts item into AVL tree using recursive helper method.
	 * 
	 * @throws DuplicateKeyException
	 *             if a duplicate key tries to be inserted into the tree
	 * @throws IllegalArgumentException
	 *             if item to be inserted is null
	 */
	public void insert(T item) {
		if (item == null) {
			throw new IllegalArgumentException();
		}
		// sets root to item to be inserted if tree is empty; no need to call insert
		if (isEmpty()) {
			root.key = item;
		} else {
			root = insert(root, item);
		}
	}

	/**
	 * Recursive helper method, recursively searches for place in tree to insert
	 * item.
	 * <p>
	 * Rebalances tree based on node and balance factor.
	 * 
	 * @throws DuplicateKeyException
	 *             if a duplicate key attempts to be inserted into the tree
	 * @param node
	 * @param item
	 *            to be inserted
	 * @return new node when insert found the "spot" for it, and also returns
	 *         various rebalancing results
	 */
	private BalancedSearchTree<T>.Treenode<T> insert(BalancedSearchTree<T>.Treenode<T> node, T item) {
		// if node is null, insert item there
		if (node == null) {
			return new Treenode<T>(item, null, null);
		}

		if (item.compareTo(node.key) < 0) {
			node.left = insert(node.left, item);
		} else if (item.compareTo(node.key) > 0) {
			node.right = insert(node.right, item);
		} else if (lookup(item)) {
			throw new DuplicateKeyException();
		}

		int balance = balanceFactor(node);

		// left tree out of balance
		if (balance > 1 && item.compareTo(node.left.key) < 0) {
			return rightRotation(node);
			// right tree out of balance
		} else if (balance < -1 && item.compareTo(node.right.key) > 0) {
			return leftRotation(node);
			// right tree and left tree out of balance
		} else if (balance > 1 && item.compareTo(node.left.key) > 0) {
			node.left = leftRotation(node.left);
			return rightRotation(node);
			// left tree and right tree out of balance
		} else if (balance < -1 && item.compareTo(node.right.key) < 0) {
			node.right = rightRotation(node.right);
			return leftRotation(node);
		}
		return node;
	}

	/**
	 * Calls recursive helper method to remove item from tree.
	 * <p>
	 * If item is null/not in tree, no exception or error occurs.
	 */
	public void delete(T item) {
		if (item == null) {
			throw new IllegalArgumentException();
		}
		// if tree is empty, don't attempt to run delete method
		if (isEmpty()) {
			return;
		} else {
			root = delete(root, item);
		}
	}

	/**
	 * Recursive helper method that deletes item from tree.
	 * 
	 * @param node
	 * @param item
	 *            to be removed from tree.
	 * @return new value to set the initial value to, which deletes references from
	 *         the tree
	 */
	private BalancedSearchTree<T>.Treenode<T> delete(BalancedSearchTree<T>.Treenode<T> node, T item) {
		if (node == null) {
			return node;
		}
		if (item.compareTo(node.key) < 0) {
			node.left = delete(node.left, item);
		} else if (item.compareTo(node.key) > 0) {
			node.right = delete(node.right, item);
		} else {
			if (node.left == null) {
				return node.right;
			} else if (node.right == null) {
				return node.left;
			} else {
				node.key = leftMost(node.right);
				node.right = delete(node.right, node.key);
			}
		}
		return node;
	}

	/**
	 * Pre-condition: node is not null
	 * 
	 * @param node
	 * @return the key value of the left most node in this subtree or the node's key
	 *         if node does not have a left child
	 */
	private T leftMost(Treenode<T> node) {
		T key = node.key;
		while (node.left != null) {
			key = leftMost(node.left);
		}
		return key;
	}

	/**
	 * Performs left rotation balancing for AVL tree.
	 * 
	 * @param input
	 * @return
	 */
	private Treenode<T> leftRotation(Treenode<T> input) {
		// keeps track of input node's right left subtree, as it will have to be put in
		// a new place
		Treenode<T> inputSub = input.right.left;
		// temporary node, set to input right
		Treenode<T> temp = input.right;
		// sets temp node's left to input node
		temp.left = input;
		// sets input node's right to saved subtree
		input.right = inputSub;
		return temp;
	}

	/**
	 * Performs right rotation balancing for AVL tree.
	 * 
	 * @param input
	 * @return
	 */
	private Treenode<T> rightRotation(Treenode<T> input) {
		// keep track of input node's left right subtree to reassign it
		Treenode<T> inputSub = input.left.right;
		// temporary node, set to input left
		Treenode<T> temp = input.left;
		// temp right is reassigned to input
		temp.right = input;
		// input left is reassigned to the inputSub
		input.left = inputSub;
		return temp;
	}
}
