/**
 * Custom exception type thrown for duplicate keys.
 * <p>
 * 
 * @author Hannah Patrick
 */
@SuppressWarnings("serial")
public class DuplicateKeyException extends RuntimeException {

	/**
	 * Constructor: calls RuntimeException's constructor to initialize.
	 */
	public DuplicateKeyException() {
		super();
	}

	/**
	 * Constructor: If user wants to output a message when the exception is thrown,
	 * will call RuntimeException's constructor to do this.
	 */
	public DuplicateKeyException(String e) {
		super(e);
	}

}
