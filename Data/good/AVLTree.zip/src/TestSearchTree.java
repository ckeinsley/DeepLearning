import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Test class for testing implementation of AVL tree.
 *
 * <p>
 * Bugs: None known
 *
 * @author Hannah Patrick
 */
public class TestSearchTree {

  BalancedSearchTreeADT<String> tree = null;
  String expected = null;
  String actual = null;

  /**
   * Sets the tree to a new, empty tree before the start of each test.
   * 
   * @throws java.lang.Exception
   */
  @Before
  public void setUp() throws Exception {
    tree = new BalancedSearchTree<String>();
  }

  /**
   * Fails if isEmpty() returns false for a newly constructed search tree.
   */
  @Test
  public void test01_isEmpty_on_empty_tree() {
    expected = "true";
    actual = "" + tree.isEmpty();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /**
   * Tests that calling inAscendingOrder() on an empty tree returns "".
   */
  @Test
  public void test02_ascending_order_on_empty_tree() {
    expected = "";
    actual = tree.inAscendingOrder();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /** tests that the height of an empty tree is 0 */
  @Test
  public void test03_height_on_empty_tree() {
    expected = "0";
    actual = "" + tree.height();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /**
   * Tests that calling isEmpty() after an insert returns false.
   */
  @Test
  public void test04_isEmpty_after_one_insert() {
    tree.insert("1");
    expected = "false";
    actual = "" + tree.isEmpty();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /** tests that the ascending order after inserting A item is "A," */
  @Test
  public void test05_ascending_order_after_one_insert() {
    tree.insert("A");
    expected = "A,";
    actual = tree.inAscendingOrder();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /** tests that the height after inserting A is 1 */
  @Test
  public void test06_height_after_one_insert() {
    tree.insert("A");
    expected = "1";
    actual = "" + tree.height();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /** tests that the height after inserting A and deleting it is 0 */
  @Test
  public void test07_height_after_one_insert_and_delete() {
    tree.insert("A");
    tree.delete("A");
    expected = "0";
    actual = "" + tree.height();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /**
   * Tests that many items can be inserted and deleted without any exception being thrown.
   */
  @Test
  public void test08_insert_delete_multiple() {
    try {
      tree.insert("A");
      tree.insert("B");
      tree.insert("C");
      tree.insert("D");
      tree.insert("E");
      tree.delete("A");
      tree.delete("B");
      tree.delete("C");
      tree.delete("D");
      tree.delete("E");
    } catch (Exception e) {
      fail(e.getMessage());
    }
  }

  @Test
  /**
   * Tests that the correct height is returned after multiple inserts.
   */
  public void test09_height_after_multiple_insert() {
    tree.insert("B");
    tree.insert("A");
    tree.insert("C");
    tree.insert("D");
    expected = "3";
    actual = "" + tree.height();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /**
   * Tests that the ascending order after multiple inserts matches the given String.
   */
  @Test
  public void test10_ascending_order_after_multiple_insert() {
    tree.insert("B");
    tree.insert("A");
    tree.insert("C");
    tree.insert("D");
    expected = "A,B,C,D,";
    actual = tree.inAscendingOrder();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /**
   * Tests that trying to delete from an empty tree causes no error.
   */
  @Test
  public void test11_delete_empty() {
    try {
      tree.delete("A");
    } catch (Exception e) {
      fail(e.getMessage());
    }
  }

  /**
   * Tests that deleting a value that is not in the tree causes no error.
   */
  @Test
  public void test12_delete_value_not_in_tree() {
    try {
      tree.insert("B");
      tree.insert("X");
      tree.insert("Y");
      tree.delete("A");
    } catch (NullPointerException e) {
      fail(e.getMessage());
    }
  }

  /**
   * Tests that inserting values (which will cause a rebalancing) don't affect the
   * inAscendingOrder() of the tree.
   */
  @Test
  public void test13_insert_correctness() {
    tree.insert("C");
    tree.insert("B");
    tree.insert("A");
    expected = "A,B,C,";
    actual = tree.inAscendingOrder();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /**
   * Tests that DuplicateKeyException is thrown when a duplicate key is inserted into tree. Fails if
   * the exception is not thrown.
   */
  @Test
  public void test14_duplicate_key() {
    try {
      tree.insert("B");
      tree.insert("X");
      tree.insert("Y");
      tree.insert("Y");
      fail("DuplicateKeyException not thrown.");
    } catch (DuplicateKeyException e) {
    }
  }


  /**
   * Tests that insert function correctly balances inserts and returns correct height. Fails if
   * incorrect height is returned.
   */
  @Test
  public void test15_height_is_balancing() {
    tree.insert("A");
    tree.insert("B");
    tree.insert("C");
    tree.insert("D");
    tree.insert("E");
    tree.insert("F");
    tree.insert("G");
    expected = "3";
    actual = "" + tree.height();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /**
   * Tests that the correct values are deleted from the tree. Fails if the inAscendingOrder() string
   * does not match the provided string.
   */
  @Test
  public void test16_delete_correctness() {
    tree.insert("B");
    tree.insert("A");
    tree.insert("C");
    tree.insert("D");
    tree.delete("D");
    tree.delete("B");
    tree.delete("C");
    expected = "A,";
    actual = tree.inAscendingOrder();
    if (!expected.equals(actual))
      fail("expected: " + expected + " actual: " + actual);
  }

  /**
   * Tests that trying to delete null from the tree throws an IllegalArgumentException. Fails if
   * IllegalArgumentException is not thrown.
   */
  @Test
  public void test17_delete_illegalArgumentException() {
    try {
      tree.delete(null);
      fail("IllegalArgumentException not thrown.");
    } catch (IllegalArgumentException e) {
    }
  }

  /**
   * Tests that trying to insert null into the tree throws an IllegalArgumentException. Fails if
   * IllegalArgumentException is not thrown.
   */
  @Test
  public void test18_insert_illegalArgumentException() {
    try {
      tree.insert(null);
      fail("IllegalArgumentException not thrown.");
    } catch (IllegalArgumentException e) {
    }
  }

  /**
   * Tests that trying to lookup null in the tree throws an IllegalArgumentException. Fails if
   * IllegalArgumentException is not thrown.
   */
  @Test
  public void test19_lookup_illegalArgumentException() {
    try {
      tree.lookup(null);
      fail("IllegalArgumentException not thrown.");
    } catch (IllegalArgumentException e) {
    }
  }

  /**
   * Tests that able to insert tons of items into tree without any type of error. Fails if any
   * exception is thrown.
   */
  @Test
  public void test20_insert_ton() {
    try {
      for (int i = 0; i > 100; i++) {
        tree.insert(i + "");
      }
    } catch (Exception e) {
      fail(e.getMessage());
    }
  }
}

