/**
 * ADT/"Base" for balanced ST implementations.
 * 
 * @author hpatrick
 *
 * @param <T>
 */
public interface BalancedSearchTreeADT<T extends Comparable<T>> {

	public String inAscendingOrder();

	public boolean isEmpty();

	public int height();

	public boolean lookup(T item);

	public void insert(T item);

	public void delete(T item);
}
